// SeedControl - teclado nativo Android em todos os campos de texto
(function () {
    "use strict";
    const tiposSemTecladoTexto = new Set(["file", "checkbox", "radio", "button", "submit", "reset", "color", "range", "date", "datetime-local", "time", "month", "week"]);
    function preparar(campo) {
        if (!campo || campo.disabled || campo.readOnly || campo.dataset.seedNativeKeyboard4004 === "1") return;
        const eInput = campo.tagName === "INPUT";
        const eTexto = eInput || campo.tagName === "TEXTAREA" || campo.isContentEditable;
        if (!eTexto) return;
        const tipo = String(campo.type || "text").toLowerCase();
        if (eInput && tiposSemTecladoTexto.has(tipo)) return;
        if (eInput && ["number", "tel", "search"].includes(tipo)) {
            try { campo.type = "text"; } catch (_) {}
        }
        campo.dataset.seedNativeKeyboard4004 = "1";
        campo.setAttribute("inputmode", "text");
        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("autocapitalize", "sentences");
        campo.setAttribute("spellcheck", "true");
        if (campo.isContentEditable) campo.setAttribute("role", "textbox");
    }
    function varrer() {
        document.querySelectorAll("input, textarea, [contenteditable=true]").forEach(preparar);
    }
    function iniciar() {
        varrer();
        document.addEventListener("focusin", e => preparar(e.target), true);
        new MutationObserver(varrer).observe(document.body, {childList:true, subtree:true});
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, {once:true}); else iniciar();
})();
