// SeedControl - teclado nativo com sugestões do Android
(function () {
    "use strict";
    function preparar(campo) {
        if (!campo || campo.disabled || campo.readOnly || campo.dataset.seedNativeKeyboard4003 === "1") return;
        campo.dataset.seedNativeKeyboard4003 = "1";
        campo.setAttribute("inputmode", "text");
        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("autocapitalize", "sentences");
        campo.setAttribute("spellcheck", "true");
        campo.style.userSelect = "text";
        campo.style.webkitUserSelect = "text";
    }
    function varrer() {
        document.querySelectorAll("input, textarea, [contenteditable=true]").forEach(preparar);
    }
    function iniciar() {
        varrer();
        document.addEventListener("focusin", e => preparar(e.target), true);
        new MutationObserver(varrer).observe(document.body, {childList:true, subtree:true});
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, {once:true}); else iniciar();
})();
