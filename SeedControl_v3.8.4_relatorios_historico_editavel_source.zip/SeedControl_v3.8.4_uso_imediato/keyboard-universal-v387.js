// SeedControl - atributos para o teclado nativo do Android
(function () {
    "use strict";
    function preparar(campo) {
        if (!campo || campo.disabled || campo.readOnly) return;
        if (campo.tagName !== "INPUT" && campo.tagName !== "TEXTAREA") return;
        const tipo = String(campo.type || "text").toLowerCase();
        if (campo.tagName === "INPUT" && ["file", "checkbox", "radio", "button", "submit", "reset", "color", "range", "date", "datetime-local", "time"].includes(tipo)) return;
        if (campo.tagName === "INPUT" && tipo === "number") campo.type = "text";
        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("aria-autocomplete", "both");
        campo.setAttribute("enterkeyhint", "next");
        if (!campo.getAttribute("name") && campo.id) campo.setAttribute("name", campo.id);
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("autocapitalize", "sentences");
        campo.setAttribute("spellcheck", "true");
    }
    function iniciar() {
        document.querySelectorAll("input, textarea").forEach(preparar);
        document.addEventListener("focusin", e => preparar(e.target), true);
        document.addEventListener("contextmenu", e => preparar(e.target), true);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, { once: true }); else iniciar();
})();
