// SeedControl v3.8.6 - botão Voltar retorna à tela inicial
(function () {
    "use strict";
    function inicio() { return /(^|\/)index\.html$/.test(location.pathname) || /\/$/.test(location.pathname); }
    function voltarParaInicio() {
        if (!inicio()) { location.href = "index.html"; return; }
        if (window.Capacitor?.Plugins?.App?.exitApp) window.Capacitor.Plugins.App.exitApp();
    }
    function instalar() {
        const app = window.Capacitor?.Plugins?.App;
        if (!app || window.__seedcontrolBackV386) return;
        window.__seedcontrolBackV386 = true;
        app.addListener("backButton", voltarParaInicio);
    }
    instalar();
    setTimeout(instalar, 0);
})();
