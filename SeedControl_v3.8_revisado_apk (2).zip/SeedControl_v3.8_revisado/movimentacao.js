// ======================================
// SeedControl v3.8
// movimentacao.js
// ======================================

const parametros =
    new URLSearchParams(
        window.location.search
    );


const id =
    Number(
        parametros.get("id")
    );


const registro =
    obterLotePorId(
        id
    );


// ======================================
// FORMATAÇÃO
// ======================================

function formatarNumeroMovimentacao(
    valor,
    casas = 2
) {

    const numero =
        Number(
            valor
        );


    if (
        !Number.isFinite(
            numero
        )
    ) {

        return "0";

    }


    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ======================================
// TEXTO DO MÉTODO
// ======================================

function obterTextoMetodoMovimentacao(
    valor
) {

    const metodo =
        normalizarMetodoPeso(
            valor
        );


    if (
        metodo ===
        "comercial"
    ) {

        return "🌱 Comercial (PMS)";

    }


    return "📦 Estimado";

}


// ======================================
// TEXTO DO PESO POR BAG
// ======================================

function obterTextoPesoBagMovimentacao(
    lote
) {

    if (!lote) {

        return "0 kg";

    }


    const metodo =
        normalizarMetodoPeso(
            lote.metodoPeso
        );


    const peso =
        formatarNumeroMovimentacao(
            lote.pesoBagKg,
            2
        );


    if (
        metodo ===
        "comercial"
    ) {

        return (
            peso +
            " kg — calculado pelo PMS"
        );

    }


    return peso + " kg";

}


// ======================================
// VALIDAR LOTE
// ======================================

if (!registro) {

    alert(
        "Lote não encontrado."
    );


    window.location.href =
        "estoque.html";


} else {


    // ======================================
    // ELEMENTOS DA TELA
    // ======================================

    const txtCultivar =
        document.getElementById(
            "cultivar"
        );


    const txtLote =
        document.getElementById(
            "lote"
        );


    const txtEstoque =
        document.getElementById(
            "estoqueAtual"
        );


    const txtPesoBag =
        document.getElementById(
            "pesoBagAtual"
        );


    const txtKgsMedia =
        document.getElementById(
            "kgsMediaAtual"
        );


    const txtSacas60kg =
        document.getElementById(
            "sacas60kgAtual"
        );


    const txtMetodoPeso =
        document.getElementById(
            "metodoPesoAtual"
        );


    const tipo =
        document.getElementById(
            "tipo"
        );


    const quantidade =
        document.getElementById(
            "quantidade"
        );


    const obs =
        document.getElementById(
            "obs"
        );


    const btnSalvar =
        document.getElementById(
            "salvar"
        );


    // ======================================
    // MOSTRAR DADOS DO LOTE
    // ======================================

    if (txtCultivar) {

        txtCultivar.textContent =
            "🌱 " +
            registro.cultivar;

    }


    if (txtLote) {

        txtLote.textContent =
            "📋 Lote " +
            registro.lote;

    }


    if (txtEstoque) {

        txtEstoque.textContent =
            formatarNumeroMovimentacao(
                registro.bags,
                2
            ) +
            " Bags";

    }


    // ======================================
    // PESO POR BAG
    // ======================================

    if (txtPesoBag) {

        txtPesoBag.textContent =
            obterTextoPesoBagMovimentacao(
                registro
            );

    }


    // ======================================
    // VALORES CALCULADOS PELO DATABASE
    // ======================================

    if (txtKgsMedia) {

        txtKgsMedia.textContent =
            formatarNumeroMovimentacao(
                registro.kgsMedia,
                2
            ) +
            " kg";

    }


    if (txtSacas60kg) {

        txtSacas60kg.textContent =
            formatarNumeroMovimentacao(
                registro.sacas60kg,
                2
            );

    }


    if (txtMetodoPeso) {

        txtMetodoPeso.textContent =
            obterTextoMetodoMovimentacao(
                registro.metodoPeso
            );

    }


    // ======================================
    // SALVAR MOVIMENTAÇÃO
    // ======================================

    if (btnSalvar) {

        btnSalvar.addEventListener(
            "click",
            function () {


                const qtd =
                    Number(
                        quantidade
                            ? quantidade.value
                            : 0
                    );


                const tipoMovimentacao =
                    tipo
                        ? tipo.value
                        : "";


                const observacao =
                    obs
                        ? obs.value
                        : "";


                // ======================================
                // SERVIÇO CENTRAL DO DATABASE
                // ======================================
                //
                // movimentacao.js altera apenas
                // a quantidade de Bags.
                //
                // database.js mantém o peso por Bag
                // salvo no lote e recalcula:
                //
                // - Kg
                // - Sacas de 60 kg
                //
                // ======================================

                const resultado =
                    movimentarLote(
                        id,
                        tipoMovimentacao,
                        qtd,
                        observacao
                    );


                // ======================================
                // RESULTADO
                // ======================================

                if (
                    !resultado.ok
                ) {

                    alert(
                        resultado.mensagem
                    );


                    return;

                }


                alert(
                    resultado.mensagem
                );


                // ======================================
                // VOLTAR PARA CULTIVAR
                // ======================================

                window.location.href =
                    "cultivar.html?cultivar=" +
                    encodeURIComponent(
                        registro.cultivar
                    );

            }
        );

    }

}