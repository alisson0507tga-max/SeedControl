// ==========================================
// SeedControl v3.8
// qrcode.js
// ==========================================

let leitorQrAtivo = null;

let promessaQRCode = null;
let promessaLeitorQRCode = null;

let loteQrAtual = null;


// ==========================================
// ELEMENTOS
// ==========================================

const cardLoteQR =
    document.getElementById(
        "cardLoteQR"
    );

const qrCultivar =
    document.getElementById(
        "qrCultivar"
    );

const qrLote =
    document.getElementById(
        "qrLote"
    );

const qrBags =
    document.getElementById(
        "qrBags"
    );

const qrFazenda =
    document.getElementById(
        "qrFazenda"
    );

const qrGerado =
    document.getElementById(
        "qrGerado"
    );

const codigoQRTexto =
    document.getElementById(
        "codigoQRTexto"
    );

const btnAbrirLoteQR =
    document.getElementById(
        "abrirLoteQR"
    );

const btnIniciarLeitorQR =
    document.getElementById(
        "iniciarLeitorQR"
    );

const btnPararLeitorQR =
    document.getElementById(
        "pararLeitorQR"
    );

const leitorQR =
    document.getElementById(
        "leitorQR"
    );

const statusLeitorQR =
    document.getElementById(
        "statusLeitorQR"
    );

const codigoManualQR =
    document.getElementById(
        "codigoManualQR"
    );

const btnAbrirCodigoManualQR =
    document.getElementById(
        "abrirCodigoManualQR"
    );


// ==========================================
// CONSTANTES
// ==========================================

const PREFIXO_QR_LOTE =
    "SEEDCONTROL-LOTE-";


// ==========================================
// FORMATAÇÃO
// ==========================================

function formatarNumeroQR(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);


    if (
        !Number.isFinite(
            numero
        )
    ) {

        return "0";

    }


    return numero.toLocaleString(
        "pt-BR",
        {

            minimumFractionDigits:
                0,

            maximumFractionDigits:
                casas

        }
    );

}


// ==========================================
// GERAR CÓDIGO DO LOTE
// ==========================================

function gerarCodigoLoteQR(
    lote
) {

    if (
        !lote ||
        lote.id === undefined ||
        lote.id === null
    ) {

        return "";

    }


    return (
        PREFIXO_QR_LOTE +
        String(
            lote.id
        )
    );

}


// ==========================================
// EXTRAIR ID DO QR
// ==========================================

function extrairIdCodigoQR(
    codigo
) {

    const texto =
        String(
            codigo ?? ""
        ).trim();


    if (!texto) {

        return null;

    }


    // ======================================
    // CÓDIGO OFICIAL
    // ======================================

    if (
        texto
            .toUpperCase()
            .startsWith(
                PREFIXO_QR_LOTE
            )
    ) {

        const id =
            texto.substring(
                PREFIXO_QR_LOTE.length
            ).trim();


        return id || null;

    }


    // ======================================
    // ACEITA ID PURO COMO CÓDIGO MANUAL
    // ======================================

    if (
        /^[0-9]+$/.test(
            texto
        )
    ) {

        return texto;

    }


    return null;

}


// ==========================================
// LOCALIZAR LOTE
// ==========================================

function localizarLotePorCodigoQR(
    codigo
) {

    const id =
        extrairIdCodigoQR(
            codigo
        );


    if (!id) {

        return null;

    }


    // ======================================
    // SERVIÇO CENTRAL
    // ======================================

    if (
        typeof obterLotePorId ===
        "function"
    ) {

        const lote =
            obterLotePorId(
                id
            );


        if (lote) {

            return lote;

        }

    }


    // ======================================
    // COMPATIBILIDADE
    // ======================================

    const estoque =
        typeof carregarEstoque ===
        "function"
            ? carregarEstoque()
            : [];


    if (
        !Array.isArray(
            estoque
        )
    ) {

        return null;

    }


    return estoque.find(
        item =>
            String(
                item &&
                item.id
            ) ===
            String(
                id
            )
    ) || null;

}


// ==========================================
// CARREGAR SCRIPT
// ==========================================

function carregarScriptQR(
    url,
    teste
) {

    return new Promise(
        function (
            resolve,
            reject
        ) {

            if (
                typeof teste ===
                    "function" &&
                teste()
            ) {

                resolve();

                return;

            }


            const existente =
                document.querySelector(
                    `script[src="${url}"]`
                );


            if (existente) {

                existente.addEventListener(
                    "load",
                    function () {

                        resolve();

                    },
                    {
                        once: true
                    }
                );


                existente.addEventListener(
                    "error",
                    function () {

                        reject(
                            new Error(
                                "Falha ao carregar biblioteca."
                            )
                        );

                    },
                    {
                        once: true
                    }
                );


                return;

            }


            const script =
                document.createElement(
                    "script"
                );


            script.src =
                url;

            script.async =
                true;


            script.onload =
                function () {

                    resolve();

                };


            script.onerror =
                function () {

                    reject(
                        new Error(
                            "Falha ao carregar biblioteca."
                        )
                    );

                };


            document.head.appendChild(
                script
            );

        }
    );

}


// ==========================================
// BIBLIOTECA GERADOR QR
// ==========================================

function carregarBibliotecaQRCode() {

    if (
        typeof QRCode !==
        "undefined"
    ) {

        return Promise.resolve();

    }


    if (!promessaQRCode) {

        promessaQRCode =
            carregarScriptQR(

                "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js",

                function () {

                    return (
                        typeof QRCode !==
                        "undefined"
                    );

                }

            ).catch(
                function (erro) {

                    promessaQRCode =
                        null;

                    throw erro;

                }
            );

    }


    return promessaQRCode;

}


// ==========================================
// BIBLIOTECA LEITOR QR
// ==========================================

function carregarBibliotecaLeitorQR() {

    if (
        typeof Html5Qrcode !==
        "undefined"
    ) {

        return Promise.resolve();

    }


    if (!promessaLeitorQRCode) {

        promessaLeitorQRCode =
            carregarScriptQR(

                "https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js",

                function () {

                    return (
                        typeof Html5Qrcode !==
                        "undefined"
                    );

                }

            ).catch(
                function (erro) {

                    promessaLeitorQRCode =
                        null;

                    throw erro;

                }
            );

    }


    return promessaLeitorQRCode;

}


// ==========================================
// MOSTRAR DADOS DO LOTE
// ==========================================

function mostrarLoteQR(
    lote
) {

    if (!lote) {

        return;

    }


    loteQrAtual =
        lote;


    const codigo =
        gerarCodigoLoteQR(
            lote
        );


    if (cardLoteQR) {

        cardLoteQR.style.display =
            "block";

    }


    if (qrCultivar) {

        qrCultivar.textContent =
            lote.cultivar ||
            "-";

    }


    if (qrLote) {

        qrLote.textContent =
            lote.lote ??
            "-";

    }


    if (qrBags) {

        qrBags.textContent =
            formatarNumeroQR(
                lote.bags,
                2
            );

    }


    if (qrFazenda) {

        qrFazenda.textContent =
            lote.fazenda ||
            "-";

    }


    if (codigoQRTexto) {

        codigoQRTexto.textContent =
            codigo;

    }


    gerarImagemQRCode(
        codigo
    );


    // ======================================
    // LEVAR PARA O CARD
    // ======================================

    setTimeout(
        function () {

            if (cardLoteQR) {

                cardLoteQR.scrollIntoView(
                    {
                        behavior:
                            "smooth",

                        block:
                            "start"
                    }
                );

            }

        },
        100
    );

}


// ==========================================
// GERAR IMAGEM QR CODE
// ==========================================

async function gerarImagemQRCode(
    codigo
) {

    if (!qrGerado) {

        return;

    }


    qrGerado.innerHTML = `

<p
    style="
        color:#111827;
        text-align:center;
    "
>

⏳ Gerando QR Code...

</p>

`;


    try {

        await carregarBibliotecaQRCode();


        qrGerado.innerHTML =
            "";


        new QRCode(
            qrGerado,
            {

                text:
                    codigo,

                width:
                    220,

                height:
                    220,

                colorDark:
                    "#000000",

                colorLight:
                    "#ffffff",

                correctLevel:
                    QRCode.CorrectLevel.H

            }
        );


    } catch (erro) {

        console.error(
            "Erro ao gerar QR Code:",
            erro
        );


        qrGerado.innerHTML = `

<p
    style="
        color:#b91c1c;
        text-align:center;
        padding:10px;
    "
>

Não foi possível gerar o QR Code.

<br><br>

Verifique a conexão com a internet.

</p>

`;

    }

}


// ==========================================
// PROCESSAR CÓDIGO ENCONTRADO
// ==========================================

async function processarCodigoQR(
    codigo
) {

    const lote =
        localizarLotePorCodigoQR(
            codigo
        );


    if (!lote) {

        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "❌ QR Code não pertence a um lote cadastrado.";

        }


        return false;

    }


    if (statusLeitorQR) {

        statusLeitorQR.textContent =
            "✅ Lote localizado.";

    }


    mostrarLoteQR(
        lote
    );


    return true;

}


// ==========================================
// PARAR CÂMERA
// ==========================================

async function pararLeitorQRCode() {

    if (!leitorQrAtivo) {

        if (leitorQR) {

            leitorQR.style.display =
                "none";

        }


        if (btnPararLeitorQR) {

            btnPararLeitorQR.style.display =
                "none";

        }


        return;

    }


    try {

        const estado =
            leitorQrAtivo.getState
                ? leitorQrAtivo.getState()
                : null;


        if (
            estado === 2 ||
            estado === 3
        ) {

            await leitorQrAtivo.stop();

        }


        try {

            await leitorQrAtivo.clear();

        } catch (erroClear) {

            console.warn(
                "Leitor já estava limpo.",
                erroClear
            );

        }


    } catch (erro) {

        console.warn(
            "Erro ao parar câmera:",
            erro
        );

    }


    leitorQrAtivo =
        null;


    if (leitorQR) {

        leitorQR.style.display =
            "none";

        leitorQR.innerHTML =
            "";

    }


    if (btnPararLeitorQR) {

        btnPararLeitorQR.style.display =
            "none";

    }


    if (btnIniciarLeitorQR) {

        btnIniciarLeitorQR.disabled =
            false;

        btnIniciarLeitorQR.textContent =
            "📷 Iniciar Câmera";

    }


    if (statusLeitorQR) {

        statusLeitorQR.textContent =
            "Câmera desligada.";

    }

}


// ==========================================
// QR LIDO PELA CÂMERA
// ==========================================

async function codigoQRDetectado(
    texto
) {

    const encontrado =
        await processarCodigoQR(
            texto
        );


    if (!encontrado) {

        return;

    }


    await pararLeitorQRCode();


    if (statusLeitorQR) {

        statusLeitorQR.textContent =
            "✅ Lote localizado pelo QR Code.";

    }

}


// ==========================================
// INICIAR CÂMERA
// ==========================================

async function iniciarLeitorQRCode() {

    if (leitorQrAtivo) {

        return;

    }


    try {

        if (btnIniciarLeitorQR) {

            btnIniciarLeitorQR.disabled =
                true;

            btnIniciarLeitorQR.textContent =
                "⏳ Abrindo câmera...";

        }


        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "Carregando leitor QR Code...";

        }


        await carregarBibliotecaLeitorQR();


        if (leitorQR) {

            leitorQR.style.display =
                "block";

        }


        leitorQrAtivo =
            new Html5Qrcode(
                "leitorQR"
            );


        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "Solicitando acesso à câmera...";

        }


        // ======================================
        // PREFERIR CÂMERA TRASEIRA
        // ======================================

        await leitorQrAtivo.start(

            {
                facingMode:
                    "environment"
            },

            {

                fps:
                    10,

                qrbox: function (
                    largura,
                    altura
                ) {

                    const menor =
                        Math.min(
                            largura,
                            altura
                        );


                    const tamanho =
                        Math.floor(
                            Math.min(
                                250,
                                menor * .72
                            )
                        );


                    return {

                        width:
                            tamanho,

                        height:
                            tamanho

                    };

                },

                aspectRatio:
                    1

            },

            codigoQRDetectado,

            function () {

                // Ignora frames sem QR.
                // Isso evita poluir o console.

            }

        );


        if (btnPararLeitorQR) {

            btnPararLeitorQR.style.display =
                "block";

        }


        if (btnIniciarLeitorQR) {

            btnIniciarLeitorQR.textContent =
                "📷 Câmera Ativa";

        }


        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "📷 Aponte a câmera para o QR Code do lote.";

        }


    } catch (erro) {

        console.error(
            "Erro ao iniciar câmera:",
            erro
        );


        leitorQrAtivo =
            null;


        if (leitorQR) {

            leitorQR.style.display =
                "none";

            leitorQR.innerHTML =
                "";

        }


        if (btnPararLeitorQR) {

            btnPararLeitorQR.style.display =
                "none";

        }


        if (btnIniciarLeitorQR) {

            btnIniciarLeitorQR.disabled =
                false;

            btnIniciarLeitorQR.textContent =
                "📷 Iniciar Câmera";

        }


        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "❌ Não foi possível abrir a câmera.";

        }


        alert(
            "Não foi possível abrir a câmera.\n\n" +
            "Teste pelo Chrome e permita o acesso à câmera."
        );

    }

}


// ==========================================
// CÓDIGO MANUAL
// ==========================================

async function localizarCodigoManualQR() {

    if (!codigoManualQR) {

        return;

    }


    const codigo =
        codigoManualQR.value.trim();


    if (!codigo) {

        alert(
            "Digite o código do lote."
        );

        codigoManualQR.focus();

        return;

    }


    const lote =
        localizarLotePorCodigoQR(
            codigo
        );


    if (!lote) {

        alert(
            "Lote não encontrado.\n\n" +
            "Confira o código informado."
        );

        return;

    }


    mostrarLoteQR(
        lote
    );


    codigoManualQR.value =
        gerarCodigoLoteQR(
            lote
        );

}


// ==========================================
// ABRIR LOTE
// ==========================================

function abrirLoteQR() {

    if (
        !loteQrAtual ||
        loteQrAtual.id ===
            undefined ||
        loteQrAtual.id ===
            null
    ) {

        alert(
            "Nenhum lote selecionado."
        );

        return;

    }


    window.location.href =
        "cadastro.html?id=" +
        encodeURIComponent(
            loteQrAtual.id
        );

}


// ==========================================
// CARREGAR LOTE PELA URL
// qrcode.html?id=123
// ==========================================

function carregarLoteDaURL() {

    const parametros =
        new URLSearchParams(
            window.location.search
        );


    const id =
        parametros.get(
            "id"
        );


    if (!id) {

        return;

    }


    let lote =
        null;


    if (
        typeof obterLotePorId ===
        "function"
    ) {

        lote =
            obterLotePorId(
                id
            );

    }


    if (!lote) {

        const estoque =
            obterEstoqueQR();


        lote =
            estoque.find(
                item =>
                    String(
                        item.id
                    ) ===
                    String(
                        id
                    )
            ) || null;

    }


    if (!lote) {

        if (statusLeitorQR) {

            statusLeitorQR.textContent =
                "❌ Lote informado não foi encontrado.";

        }


        return;

    }


    mostrarLoteQR(
        lote
    );

}


// ==========================================
// ESTOQUE AUXILIAR
// ==========================================

function obterEstoqueQR() {

    if (
        typeof carregarEstoque !==
        "function"
    ) {

        return [];

    }


    const estoque =
        carregarEstoque();


    return Array.isArray(
        estoque
    )
        ? estoque
        : [];

}


// ==========================================
// OUVINTES
// ==========================================

function registrarOuvintesQRCode() {

    if (btnIniciarLeitorQR) {

        btnIniciarLeitorQR.addEventListener(
            "click",
            iniciarLeitorQRCode
        );

    }


    if (btnPararLeitorQR) {

        btnPararLeitorQR.addEventListener(
            "click",
            pararLeitorQRCode
        );

    }


    if (btnAbrirCodigoManualQR) {

        btnAbrirCodigoManualQR.addEventListener(
            "click",
            localizarCodigoManualQR
        );

    }


    if (btnAbrirLoteQR) {

        btnAbrirLoteQR.addEventListener(
            "click",
            abrirLoteQR
        );

    }


    if (codigoManualQR) {

        codigoManualQR.addEventListener(
            "keydown",
            function (
                evento
            ) {

                if (
                    evento.key ===
                    "Enter"
                ) {

                    localizarCodigoManualQR();

                }

            }
        );

    }


    // ======================================
    // DESLIGAR CÂMERA AO SAIR
    // ======================================

    window.addEventListener(
        "pagehide",
        function () {

            pararLeitorQRCode();

        }
    );

}


// ==========================================
// INICIAR
// ==========================================

function iniciarQRCode() {

    registrarOuvintesQRCode();

    carregarLoteDaURL();

}


// ==========================================
// INICIALIZAÇÃO
// ==========================================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarQRCode
    );

} else {

    iniciarQRCode();

}