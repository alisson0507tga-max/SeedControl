// ==========================================
// SeedControl v3.8
// service-worker.js
//
// PWA CACHE v11
// ==========================================


const CACHE_NAME =
    "seedcontrol-v3.8-pwa-11";


const ARQUIVOS_PRINCIPAIS = [

    "./",

    "./index.html",

    "./style.css",

    "./manifest.json",

    "./icon-192.png",

    "./icon-512.png",


    // ======================================
    // SERVIÇOS
    // ======================================

    "./database.js",

    "./command-service.js",

    "./ia-service.js",

    "./ia-config.js",

    "./command-ui-bridge.js",


    // ======================================
    // INÍCIO
    // ======================================

    "./app.js",


    // ======================================
    // ESTOQUE
    // ======================================

    "./estoque.html",

    "./estoque.js",


    // ======================================
    // CADASTRO
    // ======================================

    "./cadastro.html",

    "./cadastro.js",


    // ======================================
    // PLANILHA
    // ======================================

    "./planilha.html",

    "./planilha.js",


    // ======================================
    // QR CODE
    // ======================================

    "./qrcode.html",

    "./qrcode.js",


    // ======================================
    // ASSISTENTE
    // ======================================

    "./assistente.html",

    "./assistente.js",


    // ======================================
    // DIAGNÓSTICO
    // ======================================

    "./diagnostico.html",

    "./diagnostico.js",


    // ======================================
    // TESTES DO SISTEMA
    // ======================================

    "./teste-sistema.html",

    "./teste-sistema.js",


    // ======================================
    // RELATÓRIOS
    // ======================================

    "./relatorios.html",

    "./relatorios.js",


    // ======================================
    // HISTÓRICO
    // ======================================

    "./historico.html",

    "./historico.js",


    // ======================================
    // CONFIGURAÇÕES
    // ======================================

    "./configuracoes.html",

    "./configuracoes.js",


    // ======================================
    // CULTIVAR
    // ======================================

    "./cultivar.html",

    "./cultivar.js",


    // ======================================
    // MOVIMENTAÇÃO
    // ======================================

    "./movimentacao.html",

    "./movimentacao.js",


    // ======================================
    // BACKUP
    // ======================================

    "./backup.html",

    "./backup.js",


    // ======================================
    // IMPORTAÇÃO
    // ======================================

    "./importar.html",

    "./importar.js",


    // ======================================
    // EDIÇÃO
    // ======================================

    "./editar.html",

    "./editar.js"

];


// ==========================================
// INSTALAÇÃO
// ==========================================

self.addEventListener(
    "install",
    function (event) {

        event.waitUntil(

            (async function () {

                const cache =
                    await caches.open(
                        CACHE_NAME
                    );


                const resultados =
                    await Promise.allSettled(

                        ARQUIVOS_PRINCIPAIS.map(

                            async function (
                                arquivo
                            ) {

                                try {

                                    const request =
                                        new Request(
                                            arquivo,
                                            {
                                                cache:
                                                    "reload"
                                            }
                                        );


                                    const resposta =
                                        await fetch(
                                            request
                                        );


                                    if (
                                        !resposta.ok
                                    ) {

                                        throw new Error(
                                            "HTTP " +
                                            resposta.status
                                        );

                                    }


                                    await cache.put(

                                        request,

                                        resposta.clone()

                                    );


                                } catch (
                                    erro
                                ) {

                                    console.warn(

                                        "[SeedControl SW] Falha ao armazenar:",

                                        arquivo,

                                        erro

                                    );


                                    throw erro;

                                }

                            }

                        )

                    );


                const sucesso =
                    resultados.filter(
                        item =>
                            item.status ===
                            "fulfilled"
                    ).length;


                console.log(

                    "[SeedControl SW] Cache preparado:",

                    sucesso +
                    "/" +
                    ARQUIVOS_PRINCIPAIS.length

                );


                await self.skipWaiting();

            })()

        );

    }
);


// ==========================================
// ATIVAÇÃO
// ==========================================

self.addEventListener(
    "activate",
    function (event) {

        event.waitUntil(

            (async function () {

                const existentes =
                    await caches.keys();


                await Promise.all(

                    existentes.map(

                        function (
                            nome
                        ) {

                            if (
                                nome !==
                                CACHE_NAME
                            ) {

                                console.log(

                                    "[SeedControl SW] Removendo cache antigo:",

                                    nome

                                );


                                return caches.delete(
                                    nome
                                );

                            }


                            return Promise.resolve();

                        }

                    )

                );


                await self.clients.claim();


                console.log(

                    "[SeedControl SW] Ativo:",

                    CACHE_NAME

                );

            })()

        );

    }
);


// ==========================================
// ATUALIZAR CACHE
// ==========================================

async function atualizarCache(
    request,
    response
) {

    if (!response) {

        return;

    }


    if (
        !response.ok &&
        response.type !==
        "opaque"
    ) {

        return;

    }


    try {

        const cache =
            await caches.open(
                CACHE_NAME
            );


        await cache.put(

            request,

            response.clone()

        );


    } catch (
        erro
    ) {

        console.warn(

            "[SeedControl SW] Erro ao atualizar cache:",

            request.url,

            erro

        );

    }

}


// ==========================================
// NETWORK FIRST
//
// Arquivos do próprio SeedControl.
//
// Sempre tenta buscar a versão nova.
// Se estiver offline, usa o cache.
// ==========================================

async function networkFirst(
    request
) {

    try {

        const resposta =
            await fetch(
                request
            );


        if (
            resposta &&
            resposta.ok
        ) {

            atualizarCache(
                request,
                resposta
            );

        }


        return resposta;


    } catch (
        erro
    ) {

        console.warn(

            "[SeedControl SW] Sem rede. Tentando cache:",

            request.url

        );


        const cache =
            await caches.match(
                request
            );


        if (cache) {

            return cache;

        }


        // ==================================
        // FALLBACK DE NAVEGAÇÃO
        // ==================================

        if (
            request.mode ===
            "navigate"
        ) {

            const index =
                await caches.match(
                    "./index.html"
                );


            if (index) {

                return index;

            }

        }


        throw erro;

    }

}


// ==========================================
// CACHE FIRST
//
// Bibliotecas externas/CDNs.
// ==========================================

async function cacheFirst(
    request
) {

    const cache =
        await caches.match(
            request
        );


    if (cache) {

        return cache;

    }


    const resposta =
        await fetch(
            request
        );


    if (
        resposta &&
        (
            resposta.ok ||
            resposta.type ===
            "opaque"
        )
    ) {

        atualizarCache(
            request,
            resposta
        );

    }


    return resposta;

}


// ==========================================
// FETCH
// ==========================================

self.addEventListener(
    "fetch",
    function (event) {

        const request =
            event.request;


        // ==================================
        // SOMENTE GET
        // ==================================

        if (
            request.method !==
            "GET"
        ) {

            return;

        }


        const url =
            new URL(
                request.url
            );


        // ==================================
        // ARQUIVOS DO SEEDCONTROL
        // ==================================

        if (
            url.origin ===
            self.location.origin
        ) {

            event.respondWith(
                networkFirst(
                    request
                )
            );


            return;

        }


        // ==================================
        // BIBLIOTECAS EXTERNAS
        // ==================================

        event.respondWith(
            cacheFirst(
                request
            )
        );

    }
);


// ==========================================
// MENSAGENS
// ==========================================

self.addEventListener(
    "message",
    function (event) {

        const dados =
            event.data;


        if (!dados) {

            return;

        }


        // ==================================
        // FORÇAR NOVA VERSÃO
        // ==================================

        if (
            dados.tipo ===
            "SKIP_WAITING"
        ) {

            self.skipWaiting();

        }


        // ==================================
        // CONSULTAR VERSÃO
        // ==================================

        if (
            dados.tipo ===
            "GET_VERSION"
        ) {

            if (
                event.source &&
                typeof event.source.postMessage ===
                "function"
            ) {

                event.source.postMessage(
                    {

                        tipo:
                            "SEEDCONTROL_SW_VERSION",

                        versao:
                            CACHE_NAME

                    }
                );

            }

        }

    }
);