// ==========================================
// SeedControl v3.8
// ia-service.js
// ==========================================

(function () {

    "use strict";


    const MODOS = {
        LOCAL: "local",
        EXTERNO: "externo"
    };


    const TIPOS_RESULTADO = {
        TEXTO: "texto",
        INTENCAO: "intencao",
        COMANDO: "comando",
        ERRO: "erro"
    };


    const configuracao = {

        modo: MODOS.LOCAL,

        provedor: null,

        endpoint: "",

        versaoContrato: "1.1"

    };


    // ======================================
    // NORMALIZAR
    // ======================================

    function normalizarTexto(valor) {

        return String(valor ?? "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .trim();

    }


    // ======================================
    // COMMAND SERVICE
    // ======================================

    function commandServiceDisponivel() {

        return !!(
            window.SeedControlCommands &&
            typeof window.SeedControlCommands.preparar === "function" &&
            typeof window.SeedControlCommands.executar === "function"
        );

    }


    // ======================================
    // CAPACIDADES
    // ======================================

    function obterCapacidades() {

        let comandos = null;


        if (
            commandServiceDisponivel() &&
            typeof window.SeedControlCommands.listarAcoes === "function"
        ) {

            try {

                comandos =
                    window.SeedControlCommands.listarAcoes();

            } catch (erro) {

                console.warn(
                    "[SeedControl IA] Erro ao ler comandos:",
                    erro
                );

            }

        }


        return {

            consultas: true,

            commandService:
                commandServiceDisponivel(),

            comandos:
                comandos

        };

    }


    // ======================================
    // CONTEXTO
    // ======================================

    function criarContexto(estoque = []) {

        const registros =
            Array.isArray(estoque)
                ? estoque
                : [];


        let totalBags = 0;
        let totalKg = 0;
        let totalSacas = 0;


        const cultivares =
            new Set();


        const fazendas =
            new Set();


        registros.forEach(function (lote) {

            if (!lote) {
                return;
            }


            totalBags +=
                Number(lote.bags) || 0;


            totalKg +=
                Number(lote.kgsMedia) || 0;


            totalSacas +=
                Number(lote.sacas60kg) || 0;


            if (lote.cultivar) {

                cultivares.add(
                    String(lote.cultivar).trim()
                );

            }


            if (lote.fazenda) {

                fazendas.add(
                    String(lote.fazenda).trim()
                );

            }

        });


        return {

            sistema: "SeedControl",

            versao: "3.8",

            contratoIA:
                configuracao.versaoContrato,

            geradoEm:
                new Date().toISOString(),

            totais: {

                registros:
                    registros.length,

                bags:
                    totalBags,

                kgsMedia:
                    totalKg,

                sacas60kg:
                    totalSacas,

                cultivares:
                    cultivares.size,

                fazendas:
                    fazendas.size

            },

            capacidades:
                obterCapacidades(),

            lotes:
                registros.map(function (lote) {

                    return {

                        id: lote.id,

                        cultivar: lote.cultivar,

                        peneira: lote.peneira,

                        lote: lote.lote,

                        bags:
                            Number(lote.bags) || 0,

                        kgsMedia:
                            Number(lote.kgsMedia) || 0,

                        sacas60kg:
                            Number(lote.sacas60kg) || 0,

                        umidade:
                            Number(lote.umidade) || 0,

                        temperatura:
                            Number(lote.temperatura) || 0,

                        pms:
                            Number(lote.pms) || 0,

                        fazenda: lote.fazenda,

                        talhao: lote.talhao,

                        secagem: lote.secagem,

                        metodoPeso:
                            lote.metodoPeso

                    };

                })

        };

    }


    // ======================================
    // INTENÇÃO VAZIA
    // ======================================

    function criarIntencaoVazia(mensagem) {

        return {

            versao:
                configuracao.versaoContrato,

            origem:
                configuracao.modo,

            mensagemOriginal:
                String(mensagem ?? ""),

            textoNormalizado:
                normalizarTexto(mensagem),

            entendido:
                false,

            tipo:
                "desconhecido",

            acao:
                null,

            parametros: {},

            requerConfirmacao:
                false,

            confianca:
                0,

            resposta:
                null

        };

    }


    // ======================================
    // VALIDAR INTENÇÃO
    // ======================================

    function validarIntencao(intencao) {

        if (
            !intencao ||
            typeof intencao !== "object" ||
            Array.isArray(intencao)
        ) {

            return false;

        }


        if (
            intencao.acao !== undefined &&
            intencao.acao !== null &&
            typeof intencao.acao !== "string"
        ) {

            return false;

        }


        if (
            intencao.parametros !== undefined &&
            (
                !intencao.parametros ||
                typeof intencao.parametros !== "object" ||
                Array.isArray(intencao.parametros)
            )
        ) {

            return false;

        }


        return true;

    }


    // ======================================
    // DETECTAR COMANDO
    // ======================================

    function pareceComando(intencao) {

        if (!validarIntencao(intencao)) {
            return false;
        }


        const acao =
            normalizarTexto(
                intencao.acao ||
                intencao.tipo
            );


        const acoes = [

            "movimentar_lote",

            "movimentar",

            "movimentacao",

            "entrada",

            "saida",

            "dar_entrada",

            "dar_saida",

            "atualizar_lote",

            "alterar_lote",

            "alterar",

            "alterar_pms",

            "alterar_umidade",

            "alterar_temperatura",

            "alterar_fazenda",

            "alterar_talhao",

            "alterar_peneira",

            "alterar_secagem",

            "alterar_peso_bag",

            "atualizar_peso_bag",

            "alterar_peso_por_bag",

            "atualizar_peso_por_bag",

            "alterar_pesobagkg",

            "cadastrar_lote",

            "novo_lote",

            "criar_lote"

        ];


        return acoes.includes(acao);

    }


    // ======================================
    // PREPARAR INTENÇÃO
    // ======================================

    function prepararIntencao(intencao) {

        if (!validarIntencao(intencao)) {

            return {

                ok: false,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                codigo:
                    "INTENCAO_INVALIDA",

                mensagem:
                    "Intenção inválida."

            };

        }


        if (!pareceComando(intencao)) {

            return {

                ok: true,

                tipoResultado:
                    TIPOS_RESULTADO.INTENCAO,

                executavel:
                    false,

                intencao:
                    intencao

            };

        }


        if (!commandServiceDisponivel()) {

            return {

                ok: false,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                codigo:
                    "COMMAND_SERVICE_INDISPONIVEL",

                mensagem:
                    "Executor de comandos indisponível."

            };

        }


        try {

            const preparado =
                window.SeedControlCommands.preparar(
                    intencao
                );


            if (
                !preparado ||
                preparado.ok !== true
            ) {

                return {

                    ok: false,

                    tipoResultado:
                        TIPOS_RESULTADO.COMANDO,

                    codigo:
                        preparado &&
                        preparado.codigo
                            ? preparado.codigo
                            : "COMANDO_INVALIDO",

                    mensagem:
                        preparado &&
                        preparado.mensagem
                            ? preparado.mensagem
                            : "Comando inválido.",

                    intencao:
                        intencao,

                    preparado:
                        preparado || null

                };

            }


            return {

                ok: true,

                tipoResultado:
                    TIPOS_RESULTADO.COMANDO,

                executavel:
                    true,

                requerConfirmacao:
                    preparado.requerConfirmacao === true,

                status:
                    preparado.requerConfirmacao
                        ? "aguardando_confirmacao"
                        : "pronto",

                intencao:
                    intencao,

                preparado:
                    preparado

            };


        } catch (erro) {

            console.error(
                "[SeedControl IA] Erro ao preparar comando:",
                erro
            );


            return {

                ok: false,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                codigo:
                    "ERRO_PREPARAR_COMANDO",

                mensagem:
                    "Erro ao preparar comando."

            };

        }

    }


    // ======================================
    // EXECUTAR INTENÇÃO
    // ======================================

    function executarIntencao(
        intencao,
        opcoes = {}
    ) {

        if (!commandServiceDisponivel()) {

            return {

                ok: false,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Executor de comandos indisponível."

            };

        }


        try {

            const resultado =
                window.SeedControlCommands.executar(

                    intencao,

                    {

                        confirmado:
                            opcoes.confirmado === true

                    }

                );


            return {

                ...resultado,

                tipoResultado:
                    TIPOS_RESULTADO.COMANDO,

                intencao:
                    intencao

            };


        } catch (erro) {

            console.error(
                "[SeedControl IA] Erro ao executar:",
                erro
            );


            return {

                ok: false,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Erro ao executar comando."

            };

        }

    }


    // ======================================
    // PROCESSAMENTO LOCAL
    // ======================================

    async function processarLocal(
        mensagem,
        contexto,
        fallbackLocal
    ) {

        if (
            typeof fallbackLocal !==
            "function"
        ) {

            return {

                ok: false,

                origem: "local",

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Interpretador local indisponível.",

                resultado:
                    null

            };

        }


        try {

            const resultado =
                await fallbackLocal(
                    mensagem,
                    contexto
                );


            return {

                ok: true,

                origem: "local",

                tipoResultado:
                    TIPOS_RESULTADO.TEXTO,

                resultado:
                    resultado

            };


        } catch (erro) {

            console.error(
                "[SeedControl IA] Erro local:",
                erro
            );


            return {

                ok: false,

                origem: "local",

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Erro no interpretador local.",

                resultado:
                    null

            };

        }

    }


    // ======================================
    // IA EXTERNA
    // ======================================

    async function consultarExterno(
        mensagem,
        contexto
    ) {

        if (!configuracao.endpoint) {

            return {

                ok: false,

                origem:
                    "externo",

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Endpoint de IA não configurado."

            };

        }


        try {

            const resposta =
                await fetch(
                    configuracao.endpoint,
                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body:
                            JSON.stringify(
                                {

                                    mensagem:
                                        String(mensagem),

                                    contexto:
                                        contexto,

                                    contrato:
                                        configuracao.versaoContrato

                                }
                            )

                    }
                );


            if (!resposta.ok) {

                throw new Error(
                    "HTTP " +
                    resposta.status
                );

            }


            const dados =
                await resposta.json();


            if (!validarIntencao(dados)) {

                throw new Error(
                    "Resposta da IA inválida."
                );

            }


            return {

                ok: true,

                origem:
                    "externo",

                resultado:
                    dados

            };


        } catch (erro) {

            console.error(
                "[SeedControl IA] Erro externo:",
                erro
            );


            return {

                ok: false,

                origem:
                    "externo",

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Falha ao consultar IA externa."

            };

        }

    }


    // ======================================
    // PROCESSAR RETORNO EXTERNO
    // ======================================

    function tratarResultadoExterno(
        intencao
    ) {

        if (pareceComando(intencao)) {

            const preparado =
                prepararIntencao(
                    intencao
                );


            return {

                ok:
                    preparado.ok,

                origem:
                    "externo",

                tipoResultado:
                    TIPOS_RESULTADO.COMANDO,

                mensagem:
                    preparado.mensagem || null,

                resultado:
                    preparado

            };

        }


        if (
            typeof intencao.resposta ===
            "string" &&
            intencao.resposta.trim()
        ) {

            return {

                ok: true,

                origem:
                    "externo",

                tipoResultado:
                    TIPOS_RESULTADO.TEXTO,

                resultado:
                    intencao.resposta

            };

        }


        return {

            ok: true,

            origem:
                "externo",

            tipoResultado:
                TIPOS_RESULTADO.INTENCAO,

            resultado:
                intencao

        };

    }


    // ======================================
    // PROCESSAR MENSAGEM
    // ======================================

    async function processarMensagem(
        mensagem,
        opcoes = {}
    ) {

        const texto =
            String(
                mensagem ?? ""
            ).trim();


        if (!texto) {

            return {

                ok: false,

                origem:
                    configuracao.modo,

                tipoResultado:
                    TIPOS_RESULTADO.ERRO,

                mensagem:
                    "Mensagem vazia.",

                resultado:
                    null

            };

        }


        const contexto =
            opcoes.contexto ||
            criarContexto([]);


        if (
            configuracao.modo ===
            MODOS.EXTERNO &&
            configuracao.endpoint
        ) {

            const externo =
                await consultarExterno(
                    texto,
                    contexto
                );


            if (externo.ok) {

                return tratarResultadoExterno(
                    externo.resultado
                );

            }

        }


        return processarLocal(

            texto,

            contexto,

            opcoes.fallbackLocal

        );

    }


    // ======================================
    // CONFIGURAÇÃO
    // ======================================

    function definirModo(modo) {

        if (
            modo !== MODOS.LOCAL &&
            modo !== MODOS.EXTERNO
        ) {

            return false;

        }


        configuracao.modo =
            modo;


        return true;

    }


    function configurarProvedor(
        dados = {}
    ) {

        if (
            dados.provedor !==
            undefined
        ) {

            configuracao.provedor =
                dados.provedor;

        }


        if (
            dados.endpoint !==
            undefined
        ) {

            configuracao.endpoint =
                String(
                    dados.endpoint || ""
                ).trim();

        }


        if (
            dados.modo !==
            undefined
        ) {

            definirModo(
                dados.modo
            );

        }


        return obterConfiguracao();

    }


    function obterConfiguracao() {

        return {

            modo:
                configuracao.modo,

            provedor:
                configuracao.provedor,

            endpoint:
                configuracao.endpoint,

            versaoContrato:
                configuracao.versaoContrato

        };

    }


    function obterEstado() {

        return {

            ativo: true,

            modo:
                configuracao.modo,

            provedor:
                configuracao.provedor,

            conectado:
                (
                    configuracao.modo ===
                    MODOS.EXTERNO &&
                    !!configuracao.endpoint
                ),

            fallbackLocal:
                true,

            commandService:
                commandServiceDisponivel(),

            versaoContrato:
                configuracao.versaoContrato

        };

    }


    // ======================================
    // API
    // ======================================

    window.SeedControlIA = {

        MODOS:
            MODOS,

        TIPOS_RESULTADO:
            TIPOS_RESULTADO,

        processarMensagem:
            processarMensagem,

        criarContexto:
            criarContexto,

        criarIntencaoVazia:
            criarIntencaoVazia,

        validarIntencao:
            validarIntencao,

        pareceComando:
            pareceComando,

        prepararIntencao:
            prepararIntencao,

        executarIntencao:
            executarIntencao,

        obterCapacidades:
            obterCapacidades,

        definirModo:
            definirModo,

        configurarProvedor:
            configurarProvedor,

        obterConfiguracao:
            obterConfiguracao,

        obterEstado:
            obterEstado

    };


    // ======================================
    // EVENTO
    // ======================================

    try {

        window.dispatchEvent(

            new CustomEvent(
                "seedcontrol:ia-pronta",
                {
                    detail:
                        obterEstado()
                }
            )

        );

    } catch (erro) {

        console.warn(
            "[SeedControl IA] Evento não enviado:",
            erro
        );

    }


    console.log(
        "[SeedControl] IA Service carregado."
    );


})();