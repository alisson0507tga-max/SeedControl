// ==========================================
// SeedControl v3.8
// assistente.js
// ==========================================

(function () {

    "use strict";


    const mensagens =
        document.getElementById(
            "assistenteMensagens"
        );

    const campoMensagem =
        document.getElementById(
            "mensagemAssistente"
        );

    const btnEnviar =
        document.getElementById(
            "enviarMensagemAssistente"
        );

    const textoStatus =
        document.getElementById(
            "textoStatusAssistente"
        );

    const botoesSugestao =
        document.querySelectorAll(
            ".btn-sugestao-assistente"
        );


    let processando = false;


    // ======================================
    // FORMATAÇÃO
    // ======================================

    function formatarNumeroAssistente(
        valor,
        casas = 2
    ) {

        const numero =
            Number(valor);


        if (
            !Number.isFinite(numero)
        ) {

            return "0";

        }


        return numero.toLocaleString(
            "pt-BR",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: casas
            }
        );

    }


    function normalizarTextoAssistente(
        valor
    ) {

        return String(valor ?? "")
            .normalize("NFD")
            .replace(
                /[\u0300-\u036f]/g,
                ""
            )
            .toLowerCase()
            .trim();

    }


    function escaparRegexAssistente(
        valor
    ) {

        return String(valor)
            .replace(
                /[.*+?^${}()|[\]\\]/g,
                "\\$&"
            );

    }


    // ======================================
    // CHAT
    // ======================================

    function adicionarMensagem(
        remetente,
        conteudo,
        usuario = false
    ) {

        if (!mensagens) {
            return;
        }


        const card =
            document.createElement(
                "div"
            );


        card.className =
            "mensagem-assistente " +
            (
                usuario
                    ? "mensagem-usuario"
                    : "mensagem-ia"
            );


        const cabecalho =
            document.createElement(
                "div"
            );


        cabecalho.className =
            "mensagem-remetente";


        cabecalho.textContent =
            remetente;


        const corpo =
            document.createElement(
                "div"
            );


        corpo.className =
            "mensagem-conteudo";


        corpo.textContent =
            String(
                conteudo ?? ""
            );


        card.appendChild(
            cabecalho
        );


        card.appendChild(
            corpo
        );


        mensagens.appendChild(
            card
        );


        mensagens.scrollTop =
            mensagens.scrollHeight;

    }


    function definirProcessando(
        ativo
    ) {

        processando =
            ativo === true;


        if (btnEnviar) {

            btnEnviar.disabled =
                processando;


            btnEnviar.textContent =
                processando
                    ? "⏳ Aguarde"
                    : "➤ Enviar";

        }


        if (campoMensagem) {

            campoMensagem.disabled =
                processando;

        }

    }


    // ======================================
    // ESTOQUE
    // ======================================

    function obterEstoqueAssistente() {

        if (
            typeof carregarEstoque !==
            "function"
        ) {

            return [];

        }


        const estoque =
            carregarEstoque();


        return Array.isArray(estoque)
            ? estoque
            : [];

    }


    function localizarLotesPorNumero(
        numero
    ) {

        const procurado =
            normalizarTextoAssistente(
                numero
            );


        return obterEstoqueAssistente()
            .filter(
                item =>
                    normalizarTextoAssistente(
                        item.lote
                    ) === procurado
            );

    }


    function extrairNumeroLote(
        texto
    ) {

        const match =
            normalizarTextoAssistente(
                texto
            ).match(
                /\blote\s+([a-z0-9._-]+)/i
            );


        return match
            ? match[1]
            : null;

    }


    // ======================================
    // CONSULTAS LOCAIS
    // ======================================

    function responderConsultaLocal(
        mensagem
    ) {

        const texto =
            normalizarTextoAssistente(
                mensagem
            );


        const estoque =
            obterEstoqueAssistente();


        const resumo =
            typeof resumirEstoque ===
            "function"

                ? resumirEstoque(
                    estoque
                )

                : null;


        // ==================================
        // TOTAL DE BAGS
        // ==================================

        if (
            texto.includes("quantas bags") ||
            texto.includes("quantos bags") ||
            texto.includes("total de bags") ||
            texto.includes("total bags")
        ) {

            const total =
                resumo
                    ? resumo.totalBags
                    : estoque.reduce(
                        (
                            soma,
                            item
                        ) =>
                            soma +
                            (
                                Number(
                                    item.bags
                                ) || 0
                            ),
                        0
                    );


            return (
                "📦 Estoque total: " +
                formatarNumeroAssistente(
                    total
                ) +
                " Bags."
            );

        }


        // ==================================
        // TOTAL KG
        // ==================================

        if (
            texto.includes("total em kg") ||
            texto.includes("quantos kg") ||
            texto.includes("quantos quilos")
        ) {

            return (
                "⚖️ Peso total estimado/comercial: " +
                formatarNumeroAssistente(
                    resumo
                        ? resumo.totalKgsMedia
                        : 0
                ) +
                " kg."
            );

        }


        // ==================================
        // SACAS
        // ==================================

        if (
            texto.includes("quantas sacas") ||
            texto.includes("total de sacas")
        ) {

            return (
                "🌾 Total equivalente: " +
                formatarNumeroAssistente(
                    resumo
                        ? resumo.totalSacas60kg
                        : 0
                ) +
                " sacas de 60 kg."
            );

        }


        // ==================================
        // QUANTIDADE DE LOTES
        // ==================================

        if (
            texto.includes("quantos lotes") ||
            texto.includes("quantidade de lotes")
        ) {

            return (
                "📋 Existem " +
                formatarNumeroAssistente(
                    estoque.length,
                    0
                ) +
                " registro(s) de lote no estoque."
            );

        }


        // ==================================
        // CULTIVARES
        // ==================================

        if (
            texto.includes("quais cultivares") ||
            texto.includes("cultivares cadastradas") ||
            texto === "cultivares"
        ) {

            const cultivares =
                [
                    ...new Set(
                        estoque
                            .map(
                                item =>
                                    String(
                                        item.cultivar ||
                                        ""
                                    ).trim()
                            )
                            .filter(Boolean)
                    )
                ].sort(
                    (
                        a,
                        b
                    ) =>
                        a.localeCompare(
                            b,
                            "pt-BR"
                        )
                );


            if (!cultivares.length) {

                return (
                    "🌱 Nenhuma cultivar cadastrada."
                );

            }


            return (
                "🌱 Cultivares cadastradas (" +
                cultivares.length +
                "):\n\n• " +
                cultivares.join(
                    "\n• "
                )
            );

        }


        // ==================================
        // LOTES CRÍTICOS / BAIXOS
        // ==================================

        if (
            texto.includes("estoque critico") ||
            texto.includes("lotes criticos") ||
            texto.includes("lote critico")
        ) {

            const criticos =
                estoque.filter(
                    lote => {

                        if (
                            typeof obterStatusEstoque !==
                            "function"
                        ) {

                            return false;

                        }


                        return (
                            obterStatusEstoque(
                                lote
                            ).chave ===
                            "critico"
                        );

                    }
                );


            if (!criticos.length) {

                return (
                    "🟢 Nenhum lote está em nível crítico."
                );

            }


            return (
                "🔴 Lotes críticos:\n\n" +
                criticos.map(
                    lote =>
                        "• " +
                        lote.cultivar +
                        " — Lote " +
                        lote.lote +
                        " — " +
                        formatarNumeroAssistente(
                            lote.bags
                        ) +
                        " Bags"
                ).join("\n")
            );

        }


        if (
            texto.includes("estoque baixo") ||
            texto.includes("lotes baixos") ||
            texto.includes("lote baixo")
        ) {

            const baixos =
                estoque.filter(
                    lote => {

                        if (
                            typeof obterStatusEstoque !==
                            "function"
                        ) {

                            return false;

                        }


                        return (
                            obterStatusEstoque(
                                lote
                            ).chave ===
                            "baixo"
                        );

                    }
                );


            if (!baixos.length) {

                return (
                    "🟢 Nenhum lote está em nível baixo."
                );

            }


            return (
                "🟡 Lotes com estoque baixo:\n\n" +
                baixos.map(
                    lote =>
                        "• " +
                        lote.cultivar +
                        " — Lote " +
                        lote.lote +
                        " — " +
                        formatarNumeroAssistente(
                            lote.bags
                        ) +
                        " Bags"
                ).join("\n")
            );

        }


        // ==================================
        // CONSULTA DE LOTE
        // ==================================

        const numeroLote =
            extrairNumeroLote(
                texto
            );


        if (
            numeroLote &&
            (
                texto.includes("onde") ||
                texto.includes("dados") ||
                texto.includes("quanto") ||
                texto.includes("quantas") ||
                texto.includes("qual") ||
                texto.startsWith("lote ")
            )
        ) {

            const encontrados =
                localizarLotesPorNumero(
                    numeroLote
                );


            if (!encontrados.length) {

                return (
                    "❌ Não encontrei o lote " +
                    numeroLote +
                    "."
                );

            }


            if (
                encontrados.length > 1
            ) {

                return (
                    "⚠️ Existe mais de um registro com o lote " +
                    numeroLote +
                    ":\n\n" +
                    encontrados.map(
                        lote =>
                            "• " +
                            lote.cultivar +
                            " — " +
                            (
                                lote.fazenda ||
                                "Fazenda não informada"
                            ) +
                            " — " +
                            formatarNumeroAssistente(
                                lote.bags
                            ) +
                            " Bags"
                    ).join("\n")
                );

            }


            const lote =
                encontrados[0];


            return (
                "🌱 " +
                lote.cultivar +
                "\n📋 Lote: " +
                lote.lote +
                "\n📦 Bags: " +
                formatarNumeroAssistente(
                    lote.bags
                ) +
                "\n⚖️ Peso por Bag: " +
                formatarNumeroAssistente(
                    lote.pesoBagKg
                ) +
                " kg" +
                "\n⚖️ Kg total: " +
                formatarNumeroAssistente(
                    lote.kgsMedia
                ) +
                " kg" +
                "\n🌾 Sacas (60 kg): " +
                formatarNumeroAssistente(
                    lote.sacas60kg
                ) +
                "\n🚜 Fazenda: " +
                (
                    lote.fazenda ||
                    "-"
                ) +
                "\n📍 Talhão: " +
                (
                    lote.talhao ||
                    "-"
                )
            );

        }


        return (
            "Posso consultar estoque, lotes, cultivares, peso em kg, sacas e alertas. " +
            "Também posso preparar entrada, saída e alterações de lote."
        );

    }


    // ======================================
    // INTERPRETAR COMANDO LOCAL
    // ======================================

    function interpretarComandoLocal(
        mensagem
    ) {

        const original =
            String(
                mensagem ?? ""
            ).trim();


        const texto =
            normalizarTextoAssistente(
                original
            );


        const lote =
            extrairNumeroLote(
                texto
            );


        // ==================================
        // ENTRADA / SAÍDA
        // ==================================

        let match =
            texto.match(
                /\b(entrada|saida|retirar|retira|adicionar|adiciona)\b[^0-9]*([0-9]+(?:[.,][0-9]+)?)\s*(?:bags?|bag)?[^\n]*\blote\s+([a-z0-9._-]+)/i
            );


        if (match) {

            const tipoTexto =
                match[1];


            return {

                acao:
                    (
                        tipoTexto === "entrada" ||
                        tipoTexto.startsWith("adicion")
                    )
                        ? "entrada"
                        : "saida",

                parametros: {
                    lote:
                        match[3],
                    quantidade:
                        match[2]
                }

            };

        }


        // ==================================
        // ALTERAÇÕES NUMÉRICAS
        // ==================================

        const alteracoesNumericas = [

            {
                nomes: ["pms"],
                acao: "alterar_pms"
            },

            {
                nomes: ["umidade"],
                acao: "alterar_umidade"
            },

            {
                nomes: ["temperatura"],
                acao: "alterar_temperatura"
            },

            {
                nomes: [
                    "peso do bag",
                    "peso por bag",
                    "peso bag"
                ],
                acao: "alterar_peso_bag"
            }

        ];


        if (lote) {

            for (
                const item of alteracoesNumericas
            ) {

                for (
                    const nome of item.nomes
                ) {

                    const regex =
                        new RegExp(
                            "(?:altera|alterar|atualiza|atualizar)\\s+(?:o\\s+|a\\s+)?" +
                            escaparRegexAssistente(nome) +
                            ".*?\\blote\\s+" +
                            escaparRegexAssistente(lote) +
                            ".*?(?:para|pra)\\s+([0-9]+(?:[.,][0-9]+)?)",
                            "i"
                        );


                    match =
                        texto.match(
                            regex
                        );


                    if (match) {

                        return {

                            acao:
                                item.acao,

                            parametros: {
                                lote:
                                    lote,
                                valor:
                                    match[1]
                            }

                        };

                    }

                }

            }

        }


        // ==================================
        // ALTERAÇÕES DE TEXTO
        // ==================================

        const camposTexto = [

            {
                nome: "fazenda",
                acao: "alterar_fazenda"
            },

            {
                nome: "talhao",
                acao: "alterar_talhao"
            },

            {
                nome: "peneira",
                acao: "alterar_peneira"
            }

        ];


        if (lote) {

            for (
                const item of camposTexto
            ) {

                const regex =
                    new RegExp(
                        "(?:altera|alterar|atualiza|atualizar)\\s+(?:o\\s+|a\\s+)?" +
                        item.nome +
                        ".*?\\blote\\s+" +
                        escaparRegexAssistente(lote) +
                        ".*?(?:para|pra)\\s+(.+)$",
                        "i"
                    );


                const encontrado =
                    original
                        .normalize("NFD")
                        .replace(
                            /[\u0300-\u036f]/g,
                            ""
                        )
                        .match(
                            regex
                        );


                if (
                    encontrado &&
                    encontrado[1]
                ) {

                    return {

                        acao:
                            item.acao,

                        parametros: {
                            lote:
                                lote,
                            valor:
                                encontrado[1]
                                    .replace(
                                        /[.!?]+$/,
                                        ""
                                    )
                                    .trim()
                        }

                    };

                }

            }

        }


        // ==================================
        // SECAGEM
        // ==================================

        if (
            lote &&
            texto.includes("secagem") &&
            (
                texto.includes("altera") ||
                texto.includes("atualiza")
            )
        ) {

            let valor =
                null;


            if (
                texto.includes("nao precisou") ||
                texto.includes("nao secou") ||
                texto.includes("sem secagem")
            ) {

                valor =
                    "nao_precisou";

            } else if (
                texto.includes("secou") ||
                texto.includes("passou pelo secador")
            ) {

                valor =
                    "secou";

            }


            if (valor) {

                return {

                    acao:
                        "alterar_secagem",

                    parametros: {
                        lote:
                            lote,
                        valor:
                            valor
                    }

                };

            }

        }


        return null;

    }


    // ======================================
    // EXECUTAR COMANDO
    // ======================================

    function executarComandoLocal(
        intencao
    ) {

        if (
            !window.SeedControlIA ||
            typeof window.SeedControlIA.prepararIntencao !==
                "function" ||
            typeof window.SeedControlIA.executarIntencao !==
                "function"
        ) {

            return (
                "❌ Serviço de comandos indisponível."
            );

        }


        const pacote =
            window.SeedControlIA
                .prepararIntencao(
                    intencao
                );


        if (
            !pacote ||
            !pacote.ok
        ) {

            return (
                "❌ " +
                (
                    pacote &&
                    pacote.mensagem

                        ? pacote.mensagem

                        : "Não foi possível preparar o comando."
                )
            );

        }


        const preparado =
            pacote.preparado;


        let confirmado =
            true;


        if (
            preparado &&
            preparado.requerConfirmacao ===
                true
        ) {

            if (
                window.SeedControlCommandUI &&
                typeof window.SeedControlCommandUI.confirmar ===
                    "function"
            ) {

                confirmado =
                    window.SeedControlCommandUI
                        .confirmar(
                            preparado
                        );

            } else {

                confirmado =
                    window.confirm(
                        "Confirma esta operação?"
                    );

            }

        }


        if (!confirmado) {

            return (
                "Operação cancelada. Nenhum dado foi alterado."
            );

        }


        const resultado =
            window.SeedControlIA
                .executarIntencao(
                    intencao,
                    {
                        confirmado: true
                    }
                );


        if (
            window.SeedControlCommandUI &&
            typeof window.SeedControlCommandUI.formatarResultado ===
                "function"
        ) {

            return window.SeedControlCommandUI
                .formatarResultado(
                    resultado,
                    preparado
                );

        }


        if (
            resultado &&
            resultado.ok
        ) {

            return (
                "✅ Operação realizada com sucesso."
            );

        }


        return (
            "❌ " +
            (
                resultado &&
                resultado.mensagem

                    ? resultado.mensagem

                    : "Não foi possível concluir a operação."
            )
        );

    }


    // ======================================
    // PROCESSAR MENSAGEM
    // ======================================

    async function processarMensagemAssistente(
        mensagem
    ) {

        const comando =
            interpretarComandoLocal(
                mensagem
            );


        if (comando) {

            return executarComandoLocal(
                comando
            );

        }


        if (
            window.SeedControlIA &&
            typeof window.SeedControlIA.processarMensagem ===
                "function"
        ) {

            const retorno =
                await window.SeedControlIA
                    .processarMensagem(
                        mensagem,
                        {
                            fallbackLocal:
                                responderConsultaLocal
                        }
                    );


            if (
                retorno &&
                retorno.ok &&
                retorno.resultado !==
                    undefined &&
                retorno.resultado !==
                    null
            ) {

                return String(
                    retorno.resultado
                );

            }


            if (
                retorno &&
                retorno.mensagem
            ) {

                return (
                    "❌ " +
                    retorno.mensagem
                );

            }

        }


        return responderConsultaLocal(
            mensagem
        );

    }


    async function enviarMensagem(
        textoForcado = null
    ) {

        if (processando) {
            return;
        }


        const texto =
            String(
                textoForcado !== null
                    ? textoForcado
                    : (
                        campoMensagem
                            ? campoMensagem.value
                            : ""
                    )
            ).trim();


        if (!texto) {

            if (campoMensagem) {
                campoMensagem.focus();
            }

            return;

        }


        adicionarMensagem(
            "Você",
            texto,
            true
        );


        if (campoMensagem) {
            campoMensagem.value = "";
        }


        definirProcessando(
            true
        );


        try {

            const resposta =
                await processarMensagemAssistente(
                    texto
                );


            adicionarMensagem(
                "🤖 SeedControl",
                resposta,
                false
            );


        } catch (erro) {

            console.error(
                "[SeedControl Assistente] Erro:",
                erro
            );


            adicionarMensagem(
                "🤖 SeedControl",
                "❌ Ocorreu um erro ao processar a mensagem.",
                false
            );

        } finally {

            definirProcessando(
                false
            );


            if (campoMensagem) {
                campoMensagem.focus();
            }

        }

    }


    // ======================================
    // OUVINTES
    // ======================================

    function registrarOuvintes() {

        if (btnEnviar) {

            btnEnviar.addEventListener(
                "click",
                function () {
                    enviarMensagem();
                }
            );

        }


        if (campoMensagem) {

            campoMensagem.addEventListener(
                "keydown",
                function (evento) {

                    if (
                        evento.key === "Enter" &&
                        !evento.shiftKey
                    ) {

                        evento.preventDefault();

                        enviarMensagem();

                    }

                }
            );

        }


        botoesSugestao.forEach(
            botao => {

                botao.addEventListener(
                    "click",
                    function () {

                        const pergunta =
                            botao.getAttribute(
                                "data-pergunta"
                            );


                        if (pergunta) {

                            enviarMensagem(
                                pergunta
                            );

                        }

                    }
                );

            }
        );

    }


    // ======================================
    // STATUS
    // ======================================

    function atualizarStatus() {

        if (!textoStatus) {
            return;
        }


        const ia =
            window.SeedControlIA;


        const commands =
            window.SeedControlCommands;


        if (
            ia &&
            commands
        ) {

            const estado =
                typeof ia.obterEstado ===
                "function"

                    ? ia.obterEstado()

                    : null;


            textoStatus.textContent =
                estado &&
                estado.modo === "externo" &&
                estado.conectado

                    ? "Assistente pronto — IA externa + validações locais."

                    : "Assistente pronto — modo local e comandos protegidos por confirmação.";


            return;

        }


        textoStatus.textContent =
            "Assistente parcialmente disponível. Verifique os serviços do sistema.";

    }


    // ======================================
    // INICIAR
    // ======================================

    function iniciar() {

        registrarOuvintes();

        atualizarStatus();

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            iniciar
        );

    } else {

        iniciar();

    }


})();
