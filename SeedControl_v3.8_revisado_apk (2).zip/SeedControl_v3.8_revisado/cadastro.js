// ===============================
// SeedControl v3.8
// Cadastro de Lotes
// ===============================

const btnSalvar =
    document.getElementById("salvar");


const parametrosCadastro =
    new URLSearchParams(
        window.location.search
    );


const idEdicao =
    Number(
        parametrosCadastro.get("id")
    );


const modoEdicao =
    Number.isFinite(idEdicao) &&
    idEdicao > 0;


// ===============================
// ELEMENTOS
// ===============================

const tituloPagina =
    document.querySelector(".topo h1");


const subtituloPagina =
    document.querySelector(".topo p");


const campoDataCadastro =
    document.getElementById(
        "dataCadastro"
    );


const campoIdCadastro =
    document.getElementById(
        "idCadastro"
    );


const campoBags =
    document.getElementById(
        "bags"
    );


const campoPMS =
    document.getElementById(
        "pms"
    );


const campoMetodoPeso =
    document.getElementById(
        "metodoPeso"
    );


const campoPesoBagKg =
    document.getElementById(
        "pesoBagKg"
    );


const grupoPesoBagEstimado =
    document.getElementById(
        "grupoPesoBagEstimado"
    );


const textoMetodoPeso =
    document.getElementById(
        "textoMetodoPeso"
    );


const campoPesoBagCalculado =
    document.getElementById(
        "pesoBagKgCalculado"
    );


const campoKgsMedia =
    document.getElementById(
        "kgsMediaCalculado"
    );


const campoSacas60kg =
    document.getElementById(
        "sacas60kgCalculado"
    );


// ===============================
// ID AUTOMÁTICO
// ===============================

const idNovoLote =
    Date.now();


const idAtual =
    modoEdicao
        ? idEdicao
        : idNovoLote;


// ===============================
// DATA
// ===============================

const dataAtual =
    new Date()
        .toLocaleDateString(
            "pt-BR"
        );


if (campoDataCadastro) {

    campoDataCadastro.textContent =
        dataAtual;

}


if (campoIdCadastro) {

    campoIdCadastro.textContent =
        idAtual;

}


// ===============================
// PESO PADRÃO
// ===============================

function obterPesoPadraoCadastro() {

    return obterPesoEstimadoPadraoBagKg();

}


// ===============================
// SECAGEM
// ===============================

function normalizarSecagemCadastro(
    valor
) {

    if (valor === true) {

        return "secou";

    }


    if (valor === false) {

        return "nao_precisou";

    }


    if (
        valor ===
        "nao_precisou"
    ) {

        return "nao_precisou";

    }


    return "secou";

}


// ===============================
// FORMATAÇÃO
// ===============================

function formatarNumeroCadastro(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);


    if (
        !Number.isFinite(
            numero
        )
    ) {

        return "0";

    }


    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ===============================
// GARANTIR PESO ESTIMADO
// ===============================

function garantirPesoEstimadoCadastro() {

    if (!campoPesoBagKg) {

        return;

    }


    const peso =
        Number(
            campoPesoBagKg.value
        );


    if (
        !Number.isFinite(peso) ||
        peso <= 0
    ) {

        campoPesoBagKg.value =
            obterPesoPadraoCadastro();

    }

}


// ===============================
// TEXTO DO MÉTODO
// ===============================

function atualizarTextoMetodo() {

    if (!campoMetodoPeso) {

        return;

    }


    const metodo =
        normalizarMetodoPeso(
            campoMetodoPeso.value
        );


    if (
        metodo ===
        "comercial"
    ) {

        if (
            grupoPesoBagEstimado
        ) {

            grupoPesoBagEstimado.style.display =
                "none";

        }


        if (
            textoMetodoPeso
        ) {

            textoMetodoPeso.innerHTML =
                "🌱 O peso do Bag será calculado automaticamente pelo <strong>PMS</strong>, considerando 5 milhões de sementes por Bag.";

        }


        if (campoPMS) {

            campoPMS.required =
                true;

        }


    } else {

        if (
            grupoPesoBagEstimado
        ) {

            grupoPesoBagEstimado.style.display =
                "block";

        }


        if (
            textoMetodoPeso
        ) {

            textoMetodoPeso.innerHTML =
                "📦 Informe o <strong>peso médio de cada Bag</strong>. O padrão é 1.050 kg, mas este valor pode ser alterado para este lote.";

        }


        if (campoPMS) {

            campoPMS.required =
                false;

        }

    }

}


// ===============================
// CÁLCULO AUTOMÁTICO
// ===============================

function atualizarCalculoAutomatico() {

    if (
        !campoBags ||
        !campoMetodoPeso
    ) {

        return;

    }


    const bags =
        Number(
            campoBags.value
        ) || 0;


    const pms =
        campoPMS
            ? Number(
                campoPMS.value
            ) || 0
            : 0;


    const metodo =
        normalizarMetodoPeso(
            campoMetodoPeso.value
        );


    const pesoEstimado =
        campoPesoBagKg
            ? Number(
                campoPesoBagKg.value
            )
            : obterPesoPadraoCadastro();


    const calculo =
        calcularPesoESacasLote(

            bags,

            pms,

            metodo,

            pesoEstimado

        );


    if (
        campoPesoBagCalculado
    ) {

        campoPesoBagCalculado.textContent =
            formatarNumeroCadastro(
                calculo.pesoBagKg,
                2
            );

    }


    if (
        campoKgsMedia
    ) {

        campoKgsMedia.textContent =
            formatarNumeroCadastro(
                calculo.kgsMedia,
                2
            );

    }


    if (
        campoSacas60kg
    ) {

        campoSacas60kg.textContent =
            formatarNumeroCadastro(
                calculo.sacas60kg,
                2
            );

    }


    atualizarTextoMetodo();

}


// ===============================
// MODO EDIÇÃO PELO cadastro.html
// ===============================

if (modoEdicao) {

    const registro =
        obterLotePorId(
            idEdicao
        );


    if (!registro) {

        alert(
            "Lote não encontrado."
        );


        window.location.href =
            "estoque.html";


    } else {


        if (tituloPagina) {

            tituloPagina.textContent =
                "✏️ Editar Lote";

        }


        if (subtituloPagina) {

            subtituloPagina.textContent =
                "Atualização de Dados";

        }


        if (campoIdCadastro) {

            campoIdCadastro.textContent =
                registro.id;

        }


        document
            .getElementById("cultivar")
            .value =
                registro.cultivar || "";


        document
            .getElementById("peneira")
            .value =
                registro.peneira || "";


        document
            .getElementById("lote")
            .value =
                registro.lote ?? "";


        document
            .getElementById("bags")
            .value =
                registro.bags ?? "";


        document
            .getElementById("umidade")
            .value =
                registro.umidade ?? "";


        document
            .getElementById("temperatura")
            .value =
                registro.temperatura ?? "";


        document
            .getElementById("pms")
            .value =
                registro.pms ?? "";


        document
            .getElementById("fazenda")
            .value =
                registro.fazenda || "";


        document
            .getElementById("talhao")
            .value =
                registro.talhao || "";


        document
            .getElementById("secagem")
            .value =
                normalizarSecagemCadastro(
                    registro.secagem
                );


        const metodoRegistro =
            normalizarMetodoPeso(
                registro.metodoPeso
            );


        if (campoMetodoPeso) {

            campoMetodoPeso.value =
                metodoRegistro;

        }


        if (campoPesoBagKg) {

            campoPesoBagKg.value =

                metodoRegistro ===
                "estimado"

                    ? (
                        Number(
                            registro.pesoBagKg
                        ) > 0

                            ? registro.pesoBagKg

                            : obterPesoPadraoCadastro()
                    )

                    : obterPesoPadraoCadastro();

        }


        if (btnSalvar) {

            btnSalvar.textContent =
                "💾 Salvar Alterações";

        }


        atualizarCalculoAutomatico();

    }


} else {


    // ===============================
    // NOVO LOTE
    // ===============================

    if (campoMetodoPeso) {

        campoMetodoPeso.value =
            "estimado";

    }


    if (campoPesoBagKg) {

        campoPesoBagKg.value =
            obterPesoPadraoCadastro();

    }


    atualizarCalculoAutomatico();

}


// ===============================
// EVENTOS
// ===============================

if (campoBags) {

    campoBags.addEventListener(
        "input",
        atualizarCalculoAutomatico
    );

}


if (campoPMS) {

    campoPMS.addEventListener(
        "input",
        atualizarCalculoAutomatico
    );

}


if (campoPesoBagKg) {

    campoPesoBagKg.addEventListener(
        "input",
        atualizarCalculoAutomatico
    );

}


if (campoMetodoPeso) {

    campoMetodoPeso.addEventListener(
        "change",
        function () {

            if (
                campoMetodoPeso.value ===
                "estimado"
            ) {

                garantirPesoEstimadoCadastro();

            }


            atualizarCalculoAutomatico();

        }
    );

}


// ===============================
// SALVAR
// ===============================

if (btnSalvar) {

    btnSalvar.addEventListener(
        "click",
        function () {


            const metodo =
                campoMetodoPeso

                    ? normalizarMetodoPeso(
                        campoMetodoPeso.value
                    )

                    : "estimado";


            const bags =
                Number(
                    document
                        .getElementById(
                            "bags"
                        )
                        .value
                );


            const pms =
                Number(
                    document
                        .getElementById(
                            "pms"
                        )
                        .value
                ) || 0;


            const pesoEstimado =
                campoPesoBagKg

                    ? Number(
                        campoPesoBagKg.value
                    )

                    : obterPesoPadraoCadastro();


            const calculo =
                calcularPesoESacasLote(

                    bags,

                    pms,

                    metodo,

                    pesoEstimado

                );


            const novoLote = {

                id:
                    idAtual,


                cultivar:
                    document
                        .getElementById(
                            "cultivar"
                        )
                        .value
                        .trim(),


                peneira:
                    document
                        .getElementById(
                            "peneira"
                        )
                        .value
                        .trim(),


                lote:
                    Number(
                        document
                            .getElementById(
                                "lote"
                            )
                            .value
                    ),


                bags:
                    bags,


                umidade:
                    Number(
                        document
                            .getElementById(
                                "umidade"
                            )
                            .value
                    ) || 0,


                temperatura:
                    Number(
                        document
                            .getElementById(
                                "temperatura"
                            )
                            .value
                    ) || 0,


                pms:
                    pms,


                pesoBagKg:
                    calculo.pesoBagKg,


                fazenda:
                    document
                        .getElementById(
                            "fazenda"
                        )
                        .value
                        .trim(),


                talhao:
                    document
                        .getElementById(
                            "talhao"
                        )
                        .value
                        .trim(),


                secagem:
                    document
                        .getElementById(
                            "secagem"
                        )
                        .value,


                metodoPeso:
                    metodo

            };


            const resultado =
                modoEdicao

                    ? atualizarLote(
                        idEdicao,
                        novoLote
                    )

                    : cadastrarLote(
                        novoLote
                    );


            if (!resultado.ok) {

                alert(
                    resultado.mensagem
                );


                return;

            }


            alert(
                resultado.mensagem
            );


            window.location.href =
                "estoque.html";

        }
    );

}