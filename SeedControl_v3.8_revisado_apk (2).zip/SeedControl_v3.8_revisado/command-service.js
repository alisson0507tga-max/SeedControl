// ==========================================
// SeedControl v3.8
// command-service.js
//
// EXECUTOR CENTRAL DE COMANDOS
// ==========================================

(function () {

    "use strict";


    // ======================================
    // CONFIGURAÇÃO
    // ======================================

    const VERSAO =
        "1.1";


    // ======================================
    // AÇÕES
    // ======================================

    const ACOES = {

        MOVIMENTAR_LOTE:
            "movimentar_lote",

        ATUALIZAR_LOTE:
            "atualizar_lote",

        CADASTRAR_LOTE:
            "cadastrar_lote"

    };


    // ======================================
    // CAMPOS EDITÁVEIS
    // ======================================

    const CAMPOS_EDITAVEIS =
        new Set([

            "pms",
            "umidade",
            "temperatura",
            "fazenda",
            "talhao",
            "peneira",
            "secagem",
            "pesoBagKg"

        ]);


    // ======================================
    // CAMPOS DO CADASTRO
    // ======================================

    const CAMPOS_CADASTRO = [

        "cultivar",
        "peneira",
        "lote",
        "bags",
        "umidade",
        "temperatura",
        "metodoPeso",
        "pms",
        "pesoBagKg",
        "fazenda",
        "talhao",
        "secagem"

    ];


    // ======================================
    // TEXTO
    // ======================================

    function normalizarTextoComando(
        valor
    ) {

        return String(
            valor ?? ""
        )
            .normalize("NFD")
            .replace(
                /[\u0300-\u036f]/g,
                ""
            )
            .toLowerCase()
            .trim();

    }


    // ======================================
    // CAMPO EDITÁVEL
    // ======================================

    function normalizarCampoEditavelComando(
        valor
    ) {

        const texto =
            normalizarTextoComando(
                valor
            );


        const compacto =
            texto.replace(
                /[^a-z0-9]/g,
                ""
            );


        if (
            [
                "pesobagkg",
                "pesobag",
                "pesoporbag",
                "pesoporbagkg"
            ].includes(
                compacto
            )
        ) {

            return "pesoBagKg";

        }


        return texto;

    }


    // ======================================
    // NÚMERO
    // ======================================

    function converterNumeroComando(
        valor
    ) {

        if (
            typeof valor ===
            "number"
        ) {

            return Number.isFinite(valor)
                ? valor
                : null;

        }


        let texto =
            String(
                valor ?? ""
            )
                .trim()
                .replace(
                    /\s/g,
                    ""
                );


        if (!texto) {

            return null;

        }


        texto =
            texto.replace(
                /[^0-9,.\-]/g,
                ""
            );


        if (!texto) {

            return null;

        }


        if (
            texto.includes(",")
        ) {

            texto =
                texto
                    .replace(
                        /\./g,
                        ""
                    )
                    .replace(
                        ",",
                        "."
                    );

        }


        const numero =
            Number(
                texto
            );


        return Number.isFinite(numero)
            ? numero
            : null;

    }


    // ======================================
    // FORMATAR NÚMERO
    // ======================================

    function formatarNumeroComando(
        valor,
        casas = 2
    ) {

        const numero =
            Number(
                valor
            );


        if (
            !Number.isFinite(
                numero
            )
        ) {

            return "0";

        }


        return numero.toLocaleString(
            "pt-BR",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: casas
            }
        );

    }


    // ======================================
    // ESTOQUE
    // ======================================

    function carregarEstoqueComando() {

        if (
            typeof carregarEstoque !==
            "function"
        ) {

            return [];

        }


        const estoque =
            carregarEstoque();


        return Array.isArray(estoque)
            ? estoque
            : [];

    }


    // ======================================
    // LOTE POR ID
    // ======================================

    function obterLotePorIdComando(
        id
    ) {

        if (
            typeof obterLotePorId ===
            "function"
        ) {

            return obterLotePorId(
                id
            );

        }


        return carregarEstoqueComando()
            .find(
                lote =>
                    Number(lote.id) ===
                    Number(id)
            ) || null;

    }


    // ======================================
    // RESULTADO DO DATABASE
    // ======================================

    function normalizarResultadoServico(
        resultado
    ) {

        if (
            resultado === true
        ) {

            return {
                ok: true
            };

        }


        if (
            resultado === false ||
            resultado === null ||
            resultado === undefined
        ) {

            return {

                ok: false,

                mensagem:
                    "A operação não foi concluída."

            };

        }


        if (
            typeof resultado ===
            "object"
        ) {

            if (
                typeof resultado.ok ===
                "boolean"
            ) {

                return resultado;

            }


            return {

                ok: true,

                resultado:
                    resultado

            };

        }


        return {

            ok: false,

            mensagem:
                "Resposta inválida do serviço."

        };

    }


    // ======================================
    // TIPO MOVIMENTAÇÃO
    // ======================================

    function normalizarTipoMovimentacao(
        valor
    ) {

        const texto =
            normalizarTextoComando(
                valor
            );


        if (
            texto === "entrada" ||
            texto === "entrar" ||
            texto === "adicionar"
        ) {

            return "entrada";

        }


        if (
            texto === "saida" ||
            texto === "sair" ||
            texto === "retirar"
        ) {

            return "saida";

        }


        return null;

    }


    // ======================================
    // SECAGEM
    // ======================================

    function normalizarSecagemComando(
        valor
    ) {

        if (
            typeof normalizarSecagem ===
            "function"
        ) {

            return normalizarSecagem(
                valor
            );

        }


        if (valor === true) {

            return "secou";

        }


        if (valor === false) {

            return "nao_precisou";

        }


        const texto =
            normalizarTextoComando(
                valor
            );


        if (
            texto === "secou" ||
            texto.includes(
                "passou pelo secador"
            )
        ) {

            return "secou";

        }


        if (
            texto.includes(
                "nao precisou"
            ) ||
            texto.includes(
                "nao secou"
            ) ||
            texto.includes(
                "sem secagem"
            )
        ) {

            return "nao_precisou";

        }


        return null;

    }


    // ======================================
    // MÉTODO PESO
    // ======================================

    function normalizarMetodoPesoComando(
        valor
    ) {

        if (
            typeof normalizarMetodoPeso ===
            "function"
        ) {

            return normalizarMetodoPeso(
                valor
            );

        }


        const texto =
            normalizarTextoComando(
                valor
            );


        if (
            texto === "comercial" ||
            texto === "pms"
        ) {

            return "comercial";

        }


        return "estimado";

    }


    // ======================================
    // AÇÃO
    // ======================================

    function normalizarAcao(
        intencao
    ) {

        const acaoOriginal =
            normalizarTextoComando(

                intencao &&
                (
                    intencao.acao ||
                    intencao.tipo
                )

            );


        const parametros = {

            ...(
                intencao &&
                intencao.parametros &&
                typeof intencao.parametros ===
                    "object"

                    ? intencao.parametros

                    : {}
            )

        };


        // MOVIMENTAÇÃO

        if (
            [
                "movimentar_lote",
                "movimentar",
                "movimentacao",
                "movimentar_estoque"
            ].includes(
                acaoOriginal
            )
        ) {

            return {
                acao:
                    ACOES.MOVIMENTAR_LOTE,
                parametros
            };

        }


        // ENTRADA

        if (
            [
                "entrada",
                "dar_entrada",
                "entrada_lote",
                "entrada_estoque"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.MOVIMENTAR_LOTE,

                parametros: {
                    ...parametros,
                    tipo:
                        "entrada"
                }

            };

        }


        // SAÍDA

        if (
            [
                "saida",
                "dar_saida",
                "saida_lote",
                "saida_estoque"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.MOVIMENTAR_LOTE,

                parametros: {
                    ...parametros,
                    tipo:
                        "saida"
                }

            };

        }


        // ATUALIZAR

        if (
            [
                "atualizar_lote",
                "alterar_lote",
                "editar_lote",
                "alterar"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros:
                    parametros

            };

        }


        // PMS

        if (
            [
                "alterar_pms",
                "atualizar_pms"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "pms"
                }

            };

        }


        // UMIDADE

        if (
            [
                "alterar_umidade",
                "atualizar_umidade"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "umidade"
                }

            };

        }


        // TEMPERATURA

        if (
            [
                "alterar_temperatura",
                "atualizar_temperatura"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "temperatura"
                }

            };

        }


        // FAZENDA

        if (
            acaoOriginal ===
            "alterar_fazenda"
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "fazenda"
                }

            };

        }


        // TALHÃO

        if (
            acaoOriginal ===
            "alterar_talhao"
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "talhao"
                }

            };

        }


        // PENEIRA

        if (
            acaoOriginal ===
            "alterar_peneira"
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "peneira"
                }

            };

        }


        // SECAGEM

        if (
            acaoOriginal ===
            "alterar_secagem"
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "secagem"
                }

            };

        }


        // PESO POR BAG

        if (
            [
                "alterar_peso_bag",
                "atualizar_peso_bag",
                "alterar_peso_por_bag",
                "atualizar_peso_por_bag",
                "alterar_pesobagkg"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                parametros: {
                    ...parametros,
                    campo:
                        "pesoBagKg"
                }

            };

        }


        // CADASTRO

        if (
            [
                "cadastrar_lote",
                "novo_lote",
                "criar_lote",
                "cadastro_lote"
            ].includes(
                acaoOriginal
            )
        ) {

            return {

                acao:
                    ACOES.CADASTRAR_LOTE,

                parametros:
                    parametros

            };

        }


        return {

            acao:
                null,

            parametros:
                parametros

        };

    }


    // ======================================
    // LOCALIZAR LOTE
    // ======================================

    function localizarLoteParaComando(
        parametros = {}
    ) {

        if (
            parametros.id !== undefined &&
            parametros.id !== null
        ) {

            const lote =
                obterLotePorIdComando(
                    parametros.id
                );


            if (!lote) {

                return {

                    ok: false,

                    codigo:
                        "LOTE_NAO_ENCONTRADO",

                    mensagem:
                        "Lote não encontrado."

                };

            }


            return {
                ok: true,
                lote
            };

        }


        const numeroLote =
            parametros.lote ??
            parametros.numeroLote ??
            parametros.numero_lote;


        if (
            numeroLote === undefined ||
            numeroLote === null ||
            String(numeroLote).trim() === ""
        ) {

            return {

                ok: false,

                codigo:
                    "LOTE_NAO_INFORMADO",

                mensagem:
                    "O número do lote não foi informado."

            };

        }


        const procurado =
            normalizarTextoComando(
                numeroLote
            );


        let encontrados =
            carregarEstoqueComando()
                .filter(
                    lote =>
                        normalizarTextoComando(
                            lote.lote
                        ) === procurado
                );


        if (
            encontrados.length > 1 &&
            parametros.cultivar
        ) {

            const cultivar =
                normalizarTextoComando(
                    parametros.cultivar
                );


            encontrados =
                encontrados.filter(
                    lote =>
                        normalizarTextoComando(
                            lote.cultivar
                        ) === cultivar
                );

        }


        if (
            encontrados.length > 1 &&
            parametros.fazenda
        ) {

            const fazenda =
                normalizarTextoComando(
                    parametros.fazenda
                );


            encontrados =
                encontrados.filter(
                    lote =>
                        normalizarTextoComando(
                            lote.fazenda
                        ) === fazenda
                );

        }


        if (
            encontrados.length === 0
        ) {

            return {

                ok: false,

                codigo:
                    "LOTE_NAO_ENCONTRADO",

                mensagem:
                    "Não encontrei o lote " +
                    numeroLote +
                    "."

            };

        }


        if (
            encontrados.length > 1
        ) {

            return {

                ok: false,

                codigo:
                    "LOTE_AMBIGUO",

                mensagem:
                    "Existe mais de um registro com o lote " +
                    numeroLote +
                    ".",

                lotes:
                    encontrados.map(
                        lote => ({

                            id:
                                lote.id,

                            lote:
                                lote.lote,

                            cultivar:
                                lote.cultivar,

                            fazenda:
                                lote.fazenda,

                            bags:
                                lote.bags

                        })
                    )

            };

        }


        return {
            ok: true,
            lote:
                encontrados[0]
        };

    }


    // ======================================
    // MOVIMENTAÇÃO
    // ======================================

    function prepararMovimentacao(
        parametros
    ) {

        const tipo =
            normalizarTipoMovimentacao(
                parametros.tipo
            );


        if (!tipo) {

            return {

                ok: false,

                codigo:
                    "TIPO_MOVIMENTACAO_INVALIDO",

                mensagem:
                    "Informe se a movimentação é entrada ou saída."

            };

        }


        const quantidade =
            converterNumeroComando(

                parametros.quantidade ??
                parametros.bags

            );


        if (
            quantidade === null ||
            quantidade <= 0
        ) {

            return {

                ok: false,

                codigo:
                    "QUANTIDADE_INVALIDA",

                mensagem:
                    "A quantidade de Bags precisa ser maior que zero."

            };

        }


        const localizacao =
            localizarLoteParaComando(
                parametros
            );


        if (!localizacao.ok) {

            return localizacao;

        }


        const lote =
            localizacao.lote;


        const nomeOperacao =
            tipo === "entrada"
                ? "ENTRADA"
                : "SAÍDA";


        return {

            ok: true,

            executavel: true,

            acao:
                ACOES.MOVIMENTAR_LOTE,

            requerConfirmacao:
                true,

            comando: {

                idLote:
                    lote.id,

                tipo:
                    tipo,

                quantidade:
                    quantidade,

                observacao:
                    parametros.observacao ||
                    "Movimentação realizada pelo Command Service"

            },

            lote: {

                id:
                    lote.id,

                lote:
                    lote.lote,

                cultivar:
                    lote.cultivar,

                fazenda:
                    lote.fazenda,

                bags:
                    Number(
                        lote.bags
                    ) || 0,

                pesoBagKg:
                    Number(
                        lote.pesoBagKg
                    ) || 0

            },

            confirmacao: {

                titulo:
                    "CONFIRMAR " +
                    nomeOperacao,

                mensagem:

                    "Cultivar: " +
                    lote.cultivar +

                    "\nLote: " +
                    lote.lote +

                    "\nFazenda: " +
                    (
                        lote.fazenda ||
                        "-"
                    ) +

                    "\n\nEstoque atual: " +
                    formatarNumeroComando(
                        lote.bags
                    ) +
                    " Bags" +

                    "\nPeso por Bag: " +
                    formatarNumeroComando(
                        lote.pesoBagKg
                    ) +
                    " kg" +

                    "\n" +
                    nomeOperacao +
                    ": " +
                    formatarNumeroComando(
                        quantidade
                    ) +
                    " Bags"

            }

        };

    }


    // ======================================
    // FORMATAR CAMPO
    // ======================================

    function formatarValorCampo(
        campo,
        valor
    ) {

        if (
            campo === "pms"
        ) {

            return (
                formatarNumeroComando(
                    valor
                ) +
                " g"
            );

        }


        if (
            campo === "umidade"
        ) {

            return (
                formatarNumeroComando(
                    valor
                ) +
                "%"
            );

        }


        if (
            campo === "temperatura"
        ) {

            return (
                formatarNumeroComando(
                    valor
                ) +
                " °C"
            );

        }


        if (
            campo === "pesoBagKg"
        ) {

            return (
                formatarNumeroComando(
                    valor
                ) +
                " kg/Bag"
            );

        }


        if (
            campo === "secagem"
        ) {

            return (
                normalizarSecagemComando(
                    valor
                ) === "secou"

                    ? "Secou"

                    : "Não precisou secar"
            );

        }


        return (
            String(
                valor ?? ""
            ).trim() ||
            "-"
        );

    }


    // ======================================
    // ATUALIZAÇÃO
    // ======================================

    function prepararAtualizacao(
        parametros
    ) {

        const campo =
            normalizarCampoEditavelComando(
                parametros.campo
            );


        if (
            !CAMPOS_EDITAVEIS.has(
                campo
            )
        ) {

            return {

                ok: false,

                codigo:
                    "CAMPO_NAO_PERMITIDO",

                mensagem:
                    "O campo “" +
                    campo +
                    "” não pode ser alterado por este serviço."

            };

        }


        const localizacao =
            localizarLoteParaComando(
                parametros
            );


        if (!localizacao.ok) {

            return localizacao;

        }


        const lote =
            localizacao.lote;


        let novoValor =
            parametros.valor ??
            parametros.novoValor ??
            parametros.novo_valor;


        // ==================================
        // NUMÉRICOS
        // ==================================

        if (
            campo === "pms" ||
            campo === "umidade" ||
            campo === "temperatura" ||
            campo === "pesoBagKg"
        ) {

            novoValor =
                converterNumeroComando(
                    novoValor
                );


            if (
                novoValor === null
            ) {

                return {

                    ok: false,

                    codigo:
                        "VALOR_INVALIDO",

                    mensagem:
                        "O novo valor informado é inválido."

                };

            }

        }


        // PMS

        if (
            campo === "pms" &&
            novoValor <= 0
        ) {

            return {

                ok: false,

                codigo:
                    "PMS_INVALIDO",

                mensagem:
                    "O PMS precisa ser maior que zero."

            };

        }


        // PESO POR BAG

        if (
            campo === "pesoBagKg"
        ) {

            if (
                novoValor <= 0
            ) {

                return {

                    ok: false,

                    codigo:
                        "PESO_BAG_INVALIDO",

                    mensagem:
                        "O peso por Bag precisa ser maior que zero."

                };

            }


            if (
                normalizarMetodoPesoComando(
                    lote.metodoPeso
                ) !== "estimado"
            ) {

                return {

                    ok: false,

                    codigo:
                        "PESO_BAG_COMERCIAL_AUTOMATICO",

                    mensagem:
                        "No método Comercial, o peso do Bag é calculado automaticamente pelo PMS."

                };

            }

        }


        // SECAGEM

        if (
            campo === "secagem"
        ) {

            novoValor =
                normalizarSecagemComando(
                    novoValor
                );


            if (!novoValor) {

                return {

                    ok: false,

                    codigo:
                        "SECAGEM_INVALIDA",

                    mensagem:
                        "Informe “Secou” ou “Não precisou secar”."

                };

            }

        }


        // TEXTO

        if (
            campo === "fazenda" ||
            campo === "talhao" ||
            campo === "peneira"
        ) {

            novoValor =
                String(
                    novoValor ?? ""
                ).trim();


            if (
                campo !== "talhao" &&
                !novoValor
            ) {

                return {

                    ok: false,

                    codigo:
                        "VALOR_VAZIO",

                    mensagem:
                        "O novo valor não pode ficar vazio."

                };

            }

        }


        const valorAtual =
            lote[campo];


        return {

            ok: true,

            executavel: true,

            acao:
                ACOES.ATUALIZAR_LOTE,

            requerConfirmacao:
                true,

            comando: {

                idLote:
                    lote.id,

                campo:
                    campo,

                valor:
                    novoValor

            },

            lote: {

                id:
                    lote.id,

                lote:
                    lote.lote,

                cultivar:
                    lote.cultivar,

                fazenda:
                    lote.fazenda

            },

            alteracao: {

                campo:
                    campo,

                valorAtual:
                    valorAtual,

                novoValor:
                    novoValor

            },

            confirmacao: {

                titulo:
                    "CONFIRMAR ALTERAÇÃO",

                mensagem:

                    "Cultivar: " +
                    lote.cultivar +

                    "\nLote: " +
                    lote.lote +

                    "\nFazenda: " +
                    (
                        lote.fazenda ||
                        "-"
                    ) +

                    "\n\nCampo: " +
                    campo +

                    "\nValor atual: " +
                    formatarValorCampo(
                        campo,
                        valorAtual
                    ) +

                    "\nNovo valor: " +
                    formatarValorCampo(
                        campo,
                        novoValor
                    )

            }

        };

    }


    // ======================================
    // CADASTRO
    // ======================================

    function prepararCadastro(
        parametros
    ) {

        const fonteDados =

            parametros.dados &&
            typeof parametros.dados ===
            "object"

                ? parametros.dados

                : parametros;


        const metodoPeso =
            normalizarMetodoPesoComando(
                fonteDados.metodoPeso
            );


        const pesoBruto =

            fonteDados.pesoBagKg ??

            fonteDados.pesoBag ??

            fonteDados.pesoPorBag ??

            fonteDados.peso_por_bag;


        let pesoBagKg =
            converterNumeroComando(
                pesoBruto
            );


        // ==================================
        // PESO PADRÃO DO ESTIMADO
        // ==================================

        if (
            metodoPeso === "estimado" &&
            (
                pesoBruto === undefined ||
                pesoBruto === null ||
                String(pesoBruto).trim() === ""
            )
        ) {

            pesoBagKg =

                typeof obterPesoEstimadoPadraoBagKg ===
                "function"

                    ? obterPesoEstimadoPadraoBagKg()

                    : 1050;

        }


        const dados = {

            cultivar:
                fonteDados.cultivar,

            peneira:
                fonteDados.peneira,

            lote:
                fonteDados.lote,

            bags:
                converterNumeroComando(
                    fonteDados.bags
                ),

            umidade:
                converterNumeroComando(
                    fonteDados.umidade
                ),

            temperatura:
                converterNumeroComando(
                    fonteDados.temperatura
                ),

            metodoPeso:
                metodoPeso,

            pms:
                converterNumeroComando(
                    fonteDados.pms
                ),

            pesoBagKg:
                pesoBagKg,

            fazenda:
                fonteDados.fazenda,

            talhao:
                fonteDados.talhao ?? "",

            secagem:
                normalizarSecagemComando(
                    fonteDados.secagem
                )

        };


        // ==================================
        // FALTANTES
        // ==================================

        const faltantes = [];


        CAMPOS_CADASTRO.forEach(
            campo => {

                // O talhão é opcional.
                if (
                    campo === "talhao"
                ) {

                    return;

                }


                // Peso estimado pode usar 1050.
                if (
                    campo === "pesoBagKg"
                ) {

                    return;

                }


                // PMS só é obrigatório
                // no método Comercial.
                if (
                    campo === "pms" &&
                    dados.metodoPeso ===
                        "estimado"
                ) {

                    return;

                }


                const valor =
                    dados[campo];


                if (
                    valor === null ||
                    valor === undefined ||
                    (
                        typeof valor ===
                        "string" &&
                        !valor.trim()
                    )
                ) {

                    faltantes.push(
                        campo
                    );

                }

            }
        );


        if (
            faltantes.length
        ) {

            return {

                ok: false,

                codigo:
                    "DADOS_CADASTRO_INCOMPLETOS",

                mensagem:
                    "Ainda faltam dados para cadastrar o lote.",

                camposFaltando:
                    faltantes

            };

        }


        if (
            Number(
                dados.bags
            ) <= 0
        ) {

            return {

                ok: false,

                codigo:
                    "BAGS_INVALIDO",

                mensagem:
                    "A quantidade de Bags precisa ser maior que zero."

            };

        }


        // ==================================
        // ESTIMADO
        // ==================================

        if (
            dados.metodoPeso ===
                "estimado" &&
            (
                dados.pesoBagKg === null ||
                dados.pesoBagKg <= 0
            )
        ) {

            return {

                ok: false,

                codigo:
                    "PESO_BAG_INVALIDO",

                mensagem:
                    "O peso por Bag precisa ser maior que zero."

            };

        }


        // ==================================
        // COMERCIAL
        // ==================================

        if (
            dados.metodoPeso ===
                "comercial" &&
            (
                dados.pms === null ||
                dados.pms <= 0
            )
        ) {

            return {

                ok: false,

                codigo:
                    "PMS_COMERCIAL_INVALIDO",

                mensagem:
                    "No método Comercial, o PMS precisa ser maior que zero."

            };

        }


        // ==================================
        // CÁLCULO
        // ==================================

        let calculo =
            null;


        if (
            typeof calcularPesoESacasLote ===
            "function"
        ) {

            calculo =
                calcularPesoESacasLote(

                    dados.bags,

                    dados.pms,

                    dados.metodoPeso,

                    dados.pesoBagKg

                );

        }


        let mensagemConfirmacao =

            "Cultivar: " +
            dados.cultivar +

            "\nPeneira: " +
            dados.peneira +

            "\nLote: " +
            dados.lote +

            "\nBags: " +
            formatarNumeroComando(
                dados.bags
            ) +

            "\nUmidade: " +
            formatarNumeroComando(
                dados.umidade
            ) +
            "%" +

            "\nTemperatura: " +
            formatarNumeroComando(
                dados.temperatura
            ) +
            " °C" +

            "\nPMS: " +
            formatarNumeroComando(
                dados.pms
            ) +
            " g" +

            "\nMétodo: " +
            (
                dados.metodoPeso ===
                    "comercial"

                    ? "Comercial (PMS)"

                    : "Estimado"
            ) +

            "\nFazenda: " +
            dados.fazenda +

            "\nTalhão: " +
            (
                dados.talhao ||
                "-"
            ) +

            "\nSecagem: " +
            (
                dados.secagem ===
                    "secou"

                    ? "Secou"

                    : "Não precisou secar"
            );


        if (calculo) {

            mensagemConfirmacao +=

                "\n\nPeso por Bag: " +
                formatarNumeroComando(
                    calculo.pesoBagKg
                ) +
                " kg" +

                "\nKg (Média): " +
                formatarNumeroComando(
                    calculo.kgsMedia
                ) +
                " kg" +

                "\nSacas (60 kg): " +
                formatarNumeroComando(
                    calculo.sacas60kg
                );

        }


        return {

            ok: true,

            executavel: true,

            acao:
                ACOES.CADASTRAR_LOTE,

            requerConfirmacao:
                true,

            comando: {
                dados:
                    dados
            },

            confirmacao: {

                titulo:
                    "CONFIRMAR CADASTRO",

                mensagem:
                    mensagemConfirmacao

            }

        };

    }


    // ======================================
    // PREPARAR
    // ======================================

    function prepararComando(
        intencao
    ) {

        if (
            !intencao ||
            typeof intencao !==
            "object"
        ) {

            return {

                ok: false,

                codigo:
                    "INTENCAO_INVALIDA",

                mensagem:
                    "Intenção inválida."

            };

        }


        const normalizada =
            normalizarAcao(
                intencao
            );


        if (
            !normalizada.acao
        ) {

            return {

                ok: false,

                codigo:
                    "ACAO_NAO_SUPORTADA",

                mensagem:
                    "A ação solicitada ainda não é suportada."

            };

        }


        switch (
            normalizada.acao
        ) {

            case ACOES.MOVIMENTAR_LOTE:

                return prepararMovimentacao(
                    normalizada.parametros
                );


            case ACOES.ATUALIZAR_LOTE:

                return prepararAtualizacao(
                    normalizada.parametros
                );


            case ACOES.CADASTRAR_LOTE:

                return prepararCadastro(
                    normalizada.parametros
                );


            default:

                return {

                    ok: false,

                    codigo:
                        "ACAO_NAO_SUPORTADA",

                    mensagem:
                        "Ação não suportada."

                };

        }

    }


    // ======================================
    // EXECUTAR MOVIMENTAÇÃO
    // ======================================

    function executarMovimentacao(
        preparado
    ) {

        if (
            typeof movimentarLote !==
            "function"
        ) {

            return {

                ok: false,

                codigo:
                    "SERVICO_INDISPONIVEL",

                mensagem:
                    "O serviço de movimentação não está disponível."

            };

        }


        const comando =
            preparado.comando;


        const resultado =
            normalizarResultadoServico(

                movimentarLote(

                    comando.idLote,

                    comando.tipo,

                    comando.quantidade,

                    comando.observacao

                )

            );


        if (!resultado.ok) {

            return resultado;

        }


        return {

            ok: true,

            executado: true,

            acao:
                ACOES.MOVIMENTAR_LOTE,

            tipo:
                comando.tipo,

            quantidade:
                comando.quantidade,

            lote:
                obterLotePorIdComando(
                    comando.idLote
                )

        };

    }


    // ======================================
    // EXECUTAR ATUALIZAÇÃO
    // ======================================

    function executarAtualizacao(
        preparado
    ) {

        if (
            typeof atualizarLote !==
            "function"
        ) {

            return {

                ok: false,

                codigo:
                    "SERVICO_INDISPONIVEL",

                mensagem:
                    "O serviço de atualização não está disponível."

            };

        }


        const comando =
            preparado.comando;


        const lote =
            obterLotePorIdComando(
                comando.idLote
            );


        if (!lote) {

            return {

                ok: false,

                codigo:
                    "LOTE_NAO_ENCONTRADO",

                mensagem:
                    "O lote não existe mais."

            };

        }


        const novosDados = {

            ...lote,

            [comando.campo]:
                comando.valor

        };


        const resultado =
            normalizarResultadoServico(

                atualizarLote(

                    lote.id,

                    novosDados

                )

            );


        if (!resultado.ok) {

            return resultado;

        }


        return {

            ok: true,

            executado: true,

            acao:
                ACOES.ATUALIZAR_LOTE,

            campo:
                comando.campo,

            valor:
                comando.valor,

            lote:
                obterLotePorIdComando(
                    lote.id
                )

        };

    }


    // ======================================
    // EXECUTAR CADASTRO
    // ======================================

    function executarCadastro(
        preparado
    ) {

        if (
            typeof cadastrarLote !==
            "function"
        ) {

            return {

                ok: false,

                codigo:
                    "SERVICO_INDISPONIVEL",

                mensagem:
                    "O serviço de cadastro não está disponível."

            };

        }


        const dados =
            preparado
                .comando
                .dados;


        const resultado =
            normalizarResultadoServico(

                cadastrarLote(
                    dados
                )

            );


        if (!resultado.ok) {

            return resultado;

        }


        return {

            ok: true,

            executado: true,

            acao:
                ACOES.CADASTRAR_LOTE,

            dados:
                dados,

            resultadoServico:
                resultado

        };

    }


    // ======================================
    // EXECUTAR
    // ======================================

    function executarComando(
        intencao,
        opcoes = {}
    ) {

        const preparado =
            prepararComando(
                intencao
            );


        if (!preparado.ok) {

            return preparado;

        }


        const confirmado =
            opcoes.confirmado ===
            true;


        if (
            preparado.requerConfirmacao &&
            !confirmado
        ) {

            return {

                ...preparado,

                executado:
                    false,

                status:
                    "aguardando_confirmacao"

            };

        }


        let resultado;


        switch (
            preparado.acao
        ) {

            case ACOES.MOVIMENTAR_LOTE:

                resultado =
                    executarMovimentacao(
                        preparado
                    );

                break;


            case ACOES.ATUALIZAR_LOTE:

                resultado =
                    executarAtualizacao(
                        preparado
                    );

                break;


            case ACOES.CADASTRAR_LOTE:

                resultado =
                    executarCadastro(
                        preparado
                    );

                break;


            default:

                resultado = {

                    ok: false,

                    codigo:
                        "ACAO_NAO_SUPORTADA",

                    mensagem:
                        "Ação não suportada."

                };

        }


        if (
            resultado &&
            resultado.ok
        ) {

            emitirEventoComandoExecutado({

                acao:
                    preparado.acao,

                resultado:
                    resultado

            });

        }


        return resultado;

    }


    // ======================================
    // EVENTO
    // ======================================

    function emitirEventoComandoExecutado(
        detalhe
    ) {

        try {

            if (
                typeof window !==
                "undefined" &&
                typeof window.dispatchEvent ===
                "function"
            ) {

                window.dispatchEvent(

                    new CustomEvent(
                        "seedcontrol:comando-executado",
                        {
                            detail:
                                detalhe
                        }
                    )

                );

            }

        } catch (erro) {

            console.warn(

                "Erro ao emitir evento do Command Service:",

                erro

            );

        }

    }


    // ======================================
    // AÇÕES SUPORTADAS
    // ======================================

    function listarAcoesSuportadas() {

        return {

            movimentacao: {

                acao:
                    ACOES.MOVIMENTAR_LOTE,

                tipos: [
                    "entrada",
                    "saida"
                ]

            },

            atualizacao: {

                acao:
                    ACOES.ATUALIZAR_LOTE,

                campos:
                    Array.from(
                        CAMPOS_EDITAVEIS
                    )

            },

            cadastro: {

                acao:
                    ACOES.CADASTRAR_LOTE,

                campos:
                    [
                        ...CAMPOS_CADASTRO
                    ]

            }

        };

    }


    // ======================================
    // ESTADO
    // ======================================

    function obterEstado() {

        return {

            ativo:
                true,

            versao:
                VERSAO,

            databaseDisponivel: {

                estoque:
                    typeof carregarEstoque ===
                    "function",

                movimentacao:
                    typeof movimentarLote ===
                    "function",

                atualizacao:
                    typeof atualizarLote ===
                    "function",

                cadastro:
                    typeof cadastrarLote ===
                    "function"

            },

            acoes:
                listarAcoesSuportadas()

        };

    }


    // ======================================
    // API
    // ======================================

    window.SeedControlCommands = {

        VERSAO:
            VERSAO,

        ACOES:
            ACOES,

        preparar:
            prepararComando,

        executar:
            executarComando,

        localizarLote:
            localizarLoteParaComando,

        listarAcoes:
            listarAcoesSuportadas,

        obterEstado:
            obterEstado

    };


    // ======================================
    // PRONTO
    // ======================================

    window.dispatchEvent(

        new CustomEvent(
            "seedcontrol:command-service-pronto",
            {
                detail:
                    obterEstado()
            }
        )

    );


})();