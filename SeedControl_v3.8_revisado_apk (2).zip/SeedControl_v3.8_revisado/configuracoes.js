// ===============================
// SeedControl v3.8
// configuracoes.js
// ===============================

const btnBackup =
    document.getElementById("backup");

const btnRestaurar =
    document.getElementById("restaurar");

const btnLimpar =
    document.getElementById("limpar");

const btnSobre =
    document.getElementById("sobre");

let ouvintesConfiguracoesRegistrados = false;


// ===============================
// PAINEL ESTOQUE INTELIGENTE
// ===============================

function criarPainelEstoqueInteligente() {

    const container =
        document.querySelector(".container");

    const menu =
        document.querySelector(".menu");

    if (
        !container ||
        document.getElementById(
            "painelEstoqueInteligente"
        )
    ) {
        return;
    }


    const card =
        document.createElement("div");

    card.className = "card";

    card.id =
        "painelEstoqueInteligente";


    card.innerHTML = `

        <h2>
            📈 Controle Inteligente de Estoque
        </h2>

        <p>
            Configure os limites usados para
            classificar cada lote como
            Normal, Baixo ou Crítico.
        </p>


        <label for="limiteBaixo">
            🟡 Limite para Estoque Baixo
        </label>

        <input
            type="number"
            id="limiteBaixo"
            min="1"
            step="1"
            inputmode="numeric"
            placeholder="Ex.: 30"
            style="
                width:100%;
                box-sizing:border-box;
                margin:8px 0 14px;
                padding:12px;
                border-radius:10px;
                border:1px solid #ccc;
            "
        >


        <label for="limiteCritico">
            🔴 Limite para Estoque Crítico
        </label>

        <input
            type="number"
            id="limiteCritico"
            min="0"
            step="1"
            inputmode="numeric"
            placeholder="Ex.: 10"
            style="
                width:100%;
                box-sizing:border-box;
                margin:8px 0 14px;
                padding:12px;
                border-radius:10px;
                border:1px solid #ccc;
            "
        >


        <button
            id="salvarLimitesEstoque"
            type="button"
        >
            💾 Salvar Limites
        </button>


        <p
            id="statusLimitesEstoque"
            style="
                margin-top:12px;
                font-weight:bold;
            "
        ></p>

    `;


    container.insertBefore(
        card,
        menu || null
    );

}


// ===============================
// PREENCHER LIMITES
// ===============================

function preencherLimitesEstoque() {

    const inputBaixo =
        document.getElementById(
            "limiteBaixo"
        );

    const inputCritico =
        document.getElementById(
            "limiteCritico"
        );

    const status =
        document.getElementById(
            "statusLimitesEstoque"
        );


    if (
        !inputBaixo ||
        !inputCritico
    ) {
        return;
    }


    const limites =
        obterLimitesEstoque();


    inputBaixo.value =
        limites.limiteBaixo;

    inputCritico.value =
        limites.limiteCritico;


    if (status) {

        status.textContent =
            "Atual: estoque baixo até " +
            limites.limiteBaixo +
            " bags e crítico até " +
            limites.limiteCritico +
            " bags.";

    }

}


// ===============================
// SALVAR LIMITES
// ===============================

function salvarLimitesDoFormulario() {

    const inputBaixo =
        document.getElementById(
            "limiteBaixo"
        );

    const inputCritico =
        document.getElementById(
            "limiteCritico"
        );

    const status =
        document.getElementById(
            "statusLimitesEstoque"
        );


    if (
        !inputBaixo ||
        !inputCritico
    ) {
        return;
    }


    const limiteBaixo =
        Number(
            inputBaixo.value
        );

    const limiteCritico =
        Number(
            inputCritico.value
        );


    // ===============================
    // VALIDAÇÕES
    // ===============================

    if (
        !Number.isFinite(
            limiteBaixo
        ) ||
        limiteBaixo <= 0
    ) {

        alert(
            "Informe um limite de estoque baixo válido."
        );

        inputBaixo.focus();

        return;

    }


    if (
        !Number.isFinite(
            limiteCritico
        ) ||
        limiteCritico < 0
    ) {

        alert(
            "Informe um limite de estoque crítico válido."
        );

        inputCritico.focus();

        return;

    }


    if (
        limiteCritico >=
        limiteBaixo
    ) {

        alert(
            "O limite crítico deve ser menor que o limite baixo."
        );

        inputCritico.focus();

        return;

    }


    // ===============================
    // SERVIÇO CENTRAL
    // ===============================

    const resultado =
        salvarLimitesEstoque({

            limiteBaixo:
                limiteBaixo,

            limiteCritico:
                limiteCritico

        });


    if (!resultado.ok) {

        alert(
            resultado.mensagem ||
            "Não foi possível salvar os limites."
        );

        return;

    }


    // ===============================
    // ATUALIZA CAMPOS
    // ===============================

    inputBaixo.value =
        resultado.limites.limiteBaixo;

    inputCritico.value =
        resultado.limites.limiteCritico;


    if (status) {

        status.textContent =
            "✅ Limites salvos: baixo até " +
            resultado.limites.limiteBaixo +
            " bags e crítico até " +
            resultado.limites.limiteCritico +
            " bags.";

    }


    alert(
        resultado.mensagem
    );

}


// ===============================
// BACKUP
// ===============================

function abrirBackup() {

    window.location.href =
        "backup.html";

}


// ===============================
// LIMPAR BANCO
// ===============================

function apagarTodosDados() {

    const confirmar =
        confirm(

            "Deseja apagar todos os dados do SeedControl?\n\n" +

            "Esta ação removerá:\n" +
            "• Estoque\n" +
            "• Histórico\n" +
            "• Configurações\n\n" +

            "Faça um backup antes se quiser preservar os dados.\n\n" +

            "Esta ação não pode ser desfeita."

        );


    if (!confirmar) {
        return;
    }


    const segundaConfirmacao =
        confirm(

            "Confirma novamente que deseja apagar TODOS os dados?"

        );


    if (!segundaConfirmacao) {
        return;
    }


    try {

        const resultado =
            limparBanco();


        if (!resultado.ok) {

            alert(
                resultado.mensagem
            );

            return;

        }


        alert(
            resultado.mensagem
        );


        window.location.href =
            "index.html";


    } catch (erro) {

        console.error(
            "Erro ao limpar SeedControl:",
            erro
        );

        alert(
            "Não foi possível apagar os dados."
        );

    }

}


// ===============================
// SOBRE
// ===============================

function mostrarSobre() {

    alert(

`🌱 SeedControl

Versão 3.8

Sistema de controle e gerenciamento
de sementes e lotes.

Recursos atuais:

• Controle de estoque
• Cadastro de lotes
• Entrada e saída
• Histórico
• Relatórios
• Exportação PDF
• Exportação Excel
• Backup e restauração
• Controle inteligente de estoque
• Alertas Normal, Baixo e Crítico

SeedControl v3.8`

    );

}


// ===============================
// OUVINTES
// ===============================

function registrarOuvintesConfiguracoes() {

    if (
        ouvintesConfiguracoesRegistrados
    ) {
        return;
    }


    ouvintesConfiguracoesRegistrados =
        true;


    // ===============================
    // LIMITES
    // ===============================

    const btnSalvarLimites =
        document.getElementById(
            "salvarLimitesEstoque"
        );


    if (btnSalvarLimites) {

        btnSalvarLimites.addEventListener(
            "click",
            salvarLimitesDoFormulario
        );

    }


    // ===============================
    // BACKUP
    // ===============================

    if (btnBackup) {

        btnBackup.addEventListener(
            "click",
            abrirBackup
        );

    }


    // ===============================
    // RESTAURAR
    // ===============================

    if (btnRestaurar) {

        btnRestaurar.addEventListener(
            "click",
            abrirBackup
        );

    }


    // ===============================
    // LIMPAR
    // ===============================

    if (btnLimpar) {

        btnLimpar.addEventListener(
            "click",
            apagarTodosDados
        );

    }


    // ===============================
    // SOBRE
    // ===============================

    if (btnSobre) {

        btnSobre.addEventListener(
            "click",
            mostrarSobre
        );

    }


    // ===============================
    // EVENTO INTERNO
    // ===============================

    window.addEventListener(
        "seedcontrol:atualizado",
        function (evento) {

            if (
                evento &&
                evento.detail &&
                evento.detail.tipo ===
                    "configuracoes"
            ) {

                preencherLimitesEstoque();

            }

        }
    );


    // ===============================
    // ALTERAÇÃO EM OUTRA ABA
    // ===============================

    window.addEventListener(
        "storage",
        function (evento) {

            if (
                !evento ||
                evento.key ===
                    "configuracoes"
            ) {

                preencherLimitesEstoque();

            }

        }
    );


    // ===============================
    // VOLTA PARA A PÁGINA
    // ===============================

    window.addEventListener(
        "focus",
        preencherLimitesEstoque
    );

}


// ===============================
// INICIAR
// ===============================

function iniciarConfiguracoes() {

    criarPainelEstoqueInteligente();

    preencherLimitesEstoque();

    registrarOuvintesConfiguracoes();

}


// ===============================
// INICIALIZAÇÃO
// ===============================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarConfiguracoes
    );

} else {

    iniciarConfiguracoes();

}