// ===============================
// SeedControl v3.8
// relatorios.js
// ===============================

let ouvintesRegistrados = false;
let graficoCultivar = null;
let frameGrafico = null;


// ===============================
// INICIAR
// ===============================

function iniciarRelatorios() {

    atualizarRelatorios();

    if (ouvintesRegistrados) return;

    ouvintesRegistrados = true;

    const botaoPDF =
        document.getElementById("exportarPDF");

    const botaoExcel =
        document.getElementById("exportarExcel");

    const filtroCultivar =
        document.getElementById("filtroCultivar");

    const filtroFazenda =
        document.getElementById("filtroFazenda");


    if (botaoPDF) {
        botaoPDF.addEventListener(
            "click",
            exportarPDF
        );
    }

    if (botaoExcel) {
        botaoExcel.addEventListener(
            "click",
            exportarExcel
        );
    }

    if (filtroCultivar) {
        filtroCultivar.addEventListener(
            "change",
            atualizarRelatorios
        );
    }

    if (filtroFazenda) {
        filtroFazenda.addEventListener(
            "change",
            atualizarRelatorios
        );
    }


    window.addEventListener(
        "seedcontrol:atualizado",
        atualizarRelatorios
    );

    window.addEventListener(
        "storage",
        atualizarRelatorios
    );

    window.addEventListener(
        "focus",
        atualizarRelatorios
    );


    document.addEventListener(
        "visibilitychange",
        function () {

            if (!document.hidden) {
                atualizarRelatorios();
            }

        }
    );

}


// ===============================
// ESTOQUE
// ===============================

function obterEstoqueBase() {

    const dados =
        carregarEstoque();

    return Array.isArray(dados)
        ? dados
        : [];

}


// ===============================
// FORMATAÇÃO
// ===============================

function formatarNumeroRelatorio(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);

    if (!Number.isFinite(numero)) {
        return "0";
    }

    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ===============================
// SECAGEM
// ===============================

function obterTextoSecagemRelatorio(valor) {

    const situacao =
        normalizarSecagem(valor);

    if (situacao === "secou") {
        return "Secou";
    }

    return "Não precisou secar";

}


// ===============================
// MÉTODO DO PESO
// ===============================

function obterTextoMetodoPesoRelatorio(
    valor
) {

    const metodo =
        normalizarMetodoPeso(valor);

    if (metodo === "comercial") {
        return "Comercial (PMS)";
    }

    return "Estimado";

}


// ===============================
// FILTROS
// ===============================

function obterFiltrosAtivos() {

    const filtroCultivar =
        document.getElementById(
            "filtroCultivar"
        );

    const filtroFazenda =
        document.getElementById(
            "filtroFazenda"
        );

    return {

        cultivar:
            filtroCultivar
                ? filtroCultivar.value
                : "",

        fazenda:
            filtroFazenda
                ? filtroFazenda.value
                : ""

    };

}


function aplicarFiltros(
    estoque,
    filtros
) {

    const cultivarSelecionada =
        normalizarTexto(
            filtros.cultivar
        );

    const fazendaSelecionada =
        normalizarTexto(
            filtros.fazenda
        );


    return (
        Array.isArray(estoque)
            ? estoque
            : []
    ).filter(item => {

        if (
            !item ||
            !item.cultivar
        ) {
            return false;
        }


        if (
            cultivarSelecionada &&
            normalizarTexto(
                item.cultivar
            ) !== cultivarSelecionada
        ) {
            return false;
        }


        if (
            fazendaSelecionada &&
            normalizarTexto(
                item.fazenda
            ) !== fazendaSelecionada
        ) {
            return false;
        }


        return true;

    });

}


// ===============================
// OPÇÕES DOS FILTROS
// ===============================

function atualizarOpcoesFiltros(
    estoque
) {

    const selectCultivar =
        document.getElementById(
            "filtroCultivar"
        );

    const selectFazenda =
        document.getElementById(
            "filtroFazenda"
        );


    if (
        !selectCultivar &&
        !selectFazenda
    ) {
        return;
    }


    const valorCultivarAtual =
        selectCultivar
            ? selectCultivar.value
            : "";

    const valorFazendaAtual =
        selectFazenda
            ? selectFazenda.value
            : "";


    const base =
        Array.isArray(estoque)
            ? estoque
            : [];


    const cultivares =
        [
            ...new Set(

                base
                    .filter(
                        item =>
                            item &&
                            item.cultivar
                    )
                    .map(
                        item =>
                            String(
                                item.cultivar
                            ).trim()
                    )
                    .filter(Boolean)

            )
        ].sort(
            (a, b) =>
                a.localeCompare(
                    b,
                    "pt-BR",
                    {
                        sensitivity:
                            "base"
                    }
                )
        );


    const fazendas =
        [
            ...new Set(

                base
                    .filter(
                        item =>
                            item &&
                            item.fazenda
                    )
                    .map(
                        item =>
                            String(
                                item.fazenda
                            ).trim()
                    )
                    .filter(Boolean)

            )
        ].sort(
            (a, b) =>
                a.localeCompare(
                    b,
                    "pt-BR",
                    {
                        sensitivity:
                            "base"
                    }
                )
        );


    // ===============================
    // CULTIVARES
    // ===============================

    if (selectCultivar) {

        selectCultivar.innerHTML = "";

        const opcaoTodas =
            document.createElement(
                "option"
            );

        opcaoTodas.value = "";

        opcaoTodas.textContent =
            "Todas";

        selectCultivar.appendChild(
            opcaoTodas
        );


        cultivares.forEach(
            cultivar => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    cultivar;

                option.textContent =
                    cultivar;

                selectCultivar.appendChild(
                    option
                );

            }
        );


        selectCultivar.value =
            cultivares.includes(
                valorCultivarAtual
            ) ||
            valorCultivarAtual === ""
                ? valorCultivarAtual
                : "";

    }


    // ===============================
    // FAZENDAS
    // ===============================

    if (selectFazenda) {

        selectFazenda.innerHTML = "";

        const opcaoTodas =
            document.createElement(
                "option"
            );

        opcaoTodas.value = "";

        opcaoTodas.textContent =
            "Todas";

        selectFazenda.appendChild(
            opcaoTodas
        );


        fazendas.forEach(
            fazenda => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    fazenda;

                option.textContent =
                    fazenda;

                selectFazenda.appendChild(
                    option
                );

            }
        );


        selectFazenda.value =
            fazendas.includes(
                valorFazendaAtual
            ) ||
            valorFazendaAtual === ""
                ? valorFazendaAtual
                : "";

    }

}


// ===============================
// RESUMOS
// ===============================

function calcularResumoRelatorio(
    estoque
) {

    return resumirEstoque(
        estoque
    );

}


function calcularResumoInteligente(
    estoque
) {

    return obterResumoEstoqueInteligente(
        estoque
    );

}


// ===============================
// CAMPOS
// ===============================

function atualizarCampo(
    id,
    valor
) {

    const elemento =
        document.getElementById(id);

    if (elemento) {
        elemento.textContent =
            valor;
    }

}


// ===============================
// GRÁFICO
// ===============================

function prepararCanvasGrafico() {

    const canvas =
        document.getElementById(
            "graficoCultivar"
        );

    if (!canvas) {
        return null;
    }


    canvas.style.display =
        "block";

    canvas.style.width =
        "100%";

    canvas.style.height =
        "320px";

    canvas.style.maxHeight =
        "320px";

    canvas.height =
        320;


    if (canvas.parentElement) {

        canvas.parentElement.style.minHeight =
            "360px";

    }


    return canvas;

}


function atualizarGraficoCultivar(
    resumo
) {

    if (frameGrafico) {

        cancelAnimationFrame(
            frameGrafico
        );

        frameGrafico = null;

    }


    frameGrafico =
        requestAnimationFrame(
            function () {

                requestAnimationFrame(
                    function () {

                        const canvas =
                            prepararCanvasGrafico();

                        if (
                            !canvas ||
                            typeof Chart ===
                                "undefined"
                        ) {
                            return;
                        }


                        const entradas =
                            Object.entries(
                                resumo.bagsPorCultivar ||
                                {}
                            ).sort(
                                (a, b) =>
                                    b[1] -
                                        a[1] ||
                                    a[0].localeCompare(
                                        b[0],
                                        "pt-BR",
                                        {
                                            sensitivity:
                                                "base"
                                        }
                                    )
                            );


                        const labels =
                            entradas.length
                                ? entradas.map(
                                    item =>
                                        item[0]
                                )
                                : [
                                    "Sem dados"
                                ];


                        const valores =
                            entradas.length
                                ? entradas.map(
                                    item =>
                                        item[1]
                                )
                                : [0];


                        if (graficoCultivar) {

                            graficoCultivar.destroy();

                            graficoCultivar =
                                null;

                        }


                        const contexto =
                            canvas.getContext(
                                "2d"
                            );

                        if (!contexto) {
                            return;
                        }


                        graficoCultivar =
                            new Chart(
                                contexto,
                                {

                                    type:
                                        "bar",

                                    data: {

                                        labels:
                                            labels,

                                        datasets: [
                                            {

                                                label:
                                                    "Bags",

                                                data:
                                                    valores,

                                                borderWidth:
                                                    1

                                            }
                                        ]

                                    },

                                    options: {

                                        responsive:
                                            true,

                                        maintainAspectRatio:
                                            false,

                                        resizeDelay:
                                            0,

                                        animation:
                                            false,

                                        plugins: {

                                            legend: {
                                                display:
                                                    false
                                            },

                                            tooltip: {

                                                callbacks: {

                                                    label:
                                                        function (
                                                            context
                                                        ) {

                                                            return (
                                                                " " +
                                                                context.parsed.y +
                                                                " Bags"
                                                            );

                                                        }

                                                }

                                            }

                                        },

                                        scales: {

                                            y: {
                                                beginAtZero:
                                                    true
                                            }

                                        }

                                    }

                                }
                            );

                    }
                );

            }
        );

}


// ===============================
// PAINEL INTELIGENTE
// ===============================

function atualizarPainelInteligente(
    resumoInteligente
) {

    const contagem = {

        normal:
            resumoInteligente.normal,

        baixo:
            resumoInteligente.baixo,

        critico:
            resumoInteligente.critico

    };


    window.__seedResumoInteligente =
        resumoInteligente;

    window.__seedAlertasEstoque =
        contagem;

}


// ===============================
// ATUALIZAR RELATÓRIOS
// ===============================

function atualizarRelatorios() {

    const estoqueBase =
        obterEstoqueBase();


    atualizarOpcoesFiltros(
        estoqueBase
    );


    const filtros =
        obterFiltrosAtivos();


    const estoqueFiltrado =
        aplicarFiltros(
            estoqueBase,
            filtros
        );


    const resumo =
        calcularResumoRelatorio(
            estoqueFiltrado
        );


    const resumoInteligente =
        calcularResumoInteligente(
            estoqueFiltrado
        );


    atualizarCampo(
        "totalBags",
        formatarNumeroRelatorio(
            resumo.totalBags,
            2
        ) +
        " Bags"
    );


    // Estes dois campos são opcionais.
    // Se existirem no relatorios.html,
    // serão preenchidos automaticamente.

    atualizarCampo(
        "totalKgsMedia",
        formatarNumeroRelatorio(
            resumo.totalKgsMedia,
            2
        ) +
        " kg"
    );


    atualizarCampo(
        "totalSacas60kg",
        formatarNumeroRelatorio(
            resumo.totalSacas60kg,
            2
        )
    );


    atualizarCampo(
        "totalCultivares",
        resumo.totalCultivares
    );


    atualizarCampo(
        "totalLotes",
        resumo.totalLotesDistintos
    );


    atualizarCampo(
        "totalFazendas",
        resumo.totalFazendas
    );


    atualizarCampo(
        "mediaUmidade",

        resumo.totalRegistros
            ? resumo.mediaUmidade.toFixed(
                1
            ) + "%"
            : "0%"
    );


    atualizarCampo(
        "mediaTemperatura",

        resumo.totalRegistros
            ? resumo.mediaTemperatura.toFixed(
                1
            ) + "°C"
            : "0°C"
    );


    atualizarCampo(
        "mediaPMS",

        resumo.totalRegistros
            ? resumo.mediaPMS.toFixed(
                2
            ) + " g"
            : "0 g"
    );


    atualizarPainelInteligente(
        resumoInteligente
    );


    atualizarGraficoCultivar(
        resumo
    );


    window.__seedRelatorio = {

        totalBags:
            resumo.totalBags,

        totalKgsMedia:
            resumo.totalKgsMedia,

        totalSacas60kg:
            resumo.totalSacas60kg,

        totalRegistros:
            resumo.totalRegistros,

        mediaUmidade:
            resumo.totalRegistros
                ? resumo.mediaUmidade.toFixed(
                    1
                )
                : "0",

        mediaTemperatura:
            resumo.totalRegistros
                ? resumo.mediaTemperatura.toFixed(
                    1
                )
                : "0",

        mediaPMS:
            resumo.totalRegistros
                ? resumo.mediaPMS.toFixed(
                    2
                )
                : "0",

        cultivares:
            resumo.totalCultivares,

        lotes:
            resumo.totalLotesDistintos,

        fazendas:
            resumo.totalFazendas,

        filtros:
            filtros,

        registrosFiltrados:
            estoqueFiltrado,

        bagsPorCultivar:
            resumo.bagsPorCultivar,

        estoqueInteligente:
            resumoInteligente

    };

}


// ===============================
// RESUMO ATUAL
// ===============================

function obterResumoAtual() {

    if (!window.__seedRelatorio) {

        atualizarRelatorios();

    }

    return window.__seedRelatorio;

}


// ===============================
// EXPORTAR PDF
// ===============================

function exportarPDF() {

    if (
        !window.jspdf ||
        !window.jspdf.jsPDF
    ) {

        alert(
            "Biblioteca PDF não carregada."
        );

        return;

    }


    const {
        jsPDF
    } =
        window.jspdf;


    const pdf =
        new jsPDF();


    const resumo =
        obterResumoAtual();


    const filtros =
        resumo.filtros;


    const registros =
        Array.isArray(
            resumo.registrosFiltrados
        )
            ? resumo.registrosFiltrados
            : [];


    const inteligente =
        resumo.estoqueInteligente;


    // ===============================
    // CABEÇALHO
    // ===============================

    pdf.setFontSize(18);

    pdf.text(
        "Relatório SeedControl",
        20,
        20
    );


    pdf.setFontSize(11);

    pdf.text(
        "Data: " +
        new Date()
            .toLocaleString(
                "pt-BR"
            ),
        20,
        30
    );


    // ===============================
    // FILTROS
    // ===============================

    pdf.setFontSize(12);

    pdf.text(
        "Filtros aplicados:",
        20,
        42
    );


    pdf.setFontSize(11);

    pdf.text(
        "Cultivar: " +
        (
            filtros.cultivar ||
            "Todas"
        ),
        20,
        50
    );


    pdf.text(
        "Fazenda: " +
        (
            filtros.fazenda ||
            "Todas"
        ),
        20,
        58
    );


    // ===============================
    // RESUMO
    // ===============================

    pdf.setFontSize(12);

    pdf.text(
        "Resumo:",
        20,
        72
    );


    pdf.setFontSize(11);


    pdf.text(
        "Total Bags: " +
        formatarNumeroRelatorio(
            resumo.totalBags,
            2
        ),
        20,
        80
    );


    pdf.text(
        "Kgs (Média): " +
        formatarNumeroRelatorio(
            resumo.totalKgsMedia,
            2
        ) +
        " kg",
        20,
        88
    );


    pdf.text(
        "Sacas (60 kg): " +
        formatarNumeroRelatorio(
            resumo.totalSacas60kg,
            2
        ),
        20,
        96
    );


    pdf.text(
        "Cultivares: " +
        resumo.cultivares,
        20,
        104
    );


    pdf.text(
        "Lotes: " +
        resumo.lotes,
        20,
        112
    );


    pdf.text(
        "Fazendas: " +
        resumo.fazendas,
        20,
        120
    );


    pdf.text(
        "Umidade Média: " +
        resumo.mediaUmidade +
        "%",
        20,
        128
    );


    pdf.text(
        "Temperatura Média: " +
        resumo.mediaTemperatura +
        " °C",
        20,
        136
    );


    pdf.text(
        "PMS Médio: " +
        resumo.mediaPMS +
        " g",
        20,
        144
    );


    // ===============================
    // ESTOQUE INTELIGENTE
    // ===============================

    pdf.setFontSize(12);

    pdf.text(
        "Controle Inteligente de Estoque:",
        20,
        158
    );


    pdf.setFontSize(11);


    pdf.text(
        "Normal: " +
        inteligente.normal,
        20,
        166
    );


    pdf.text(
        "Baixo: " +
        inteligente.baixo,
        20,
        174
    );


    pdf.text(
        "Crítico: " +
        inteligente.critico,
        20,
        182
    );


    pdf.text(
        "Limites: baixo em " +
        inteligente.limites.limiteBaixo +
        " / crítico em " +
        inteligente.limites.limiteCritico,
        20,
        190
    );


    // ===============================
    // BAGS POR CULTIVAR
    // ===============================

    let y = 206;


    pdf.setFontSize(12);

    pdf.text(
        "Bags por Cultivar:",
        20,
        y
    );

    y += 8;


    const linhas =
        Object.entries(
            resumo.bagsPorCultivar ||
            {}
        ).sort(
            (a, b) =>
                b[1] -
                    a[1] ||
                a[0].localeCompare(
                    b[0],
                    "pt-BR",
                    {
                        sensitivity:
                            "base"
                    }
                )
        );


    if (!linhas.length) {

        pdf.setFontSize(11);

        pdf.text(
            "Sem dados para o filtro atual.",
            20,
            y
        );

    } else {

        linhas.forEach(
            function (
                [cultivar, bags]
            ) {

                if (y > 275) {

                    pdf.addPage();

                    y = 20;

                }


                pdf.setFontSize(11);

                pdf.text(
                    cultivar +
                    ": " +
                    formatarNumeroRelatorio(
                        bags,
                        2
                    ) +
                    " Bags",
                    20,
                    y
                );

                y += 7;

            }
        );

    }


    // ===============================
    // REGISTROS
    // ===============================

    if (registros.length) {

        if (y > 250) {

            pdf.addPage();

            y = 20;

        }


        y += 5;


        pdf.setFontSize(12);

        pdf.text(
            "Registros filtrados:",
            20,
            y
        );

        y += 8;


        registros.forEach(
            function (item) {

                const status =
                    obterStatusEstoque(
                        item
                    );


                const secagem =
                    obterTextoSecagemRelatorio(
                        item.secagem
                    );


                const metodoPeso =
                    obterTextoMetodoPesoRelatorio(
                        item.metodoPeso
                    );


                const linha =

                    "Cultivar " +
                    (
                        item.cultivar ||
                        "-"
                    ) +

                    " | Lote " +
                    (
                        item.lote ||
                        "-"
                    ) +

                    " | Bags " +
                    formatarNumeroRelatorio(
                        item.bags,
                        2
                    ) +

                    " | Kg " +
                    formatarNumeroRelatorio(
                        item.kgsMedia,
                        2
                    ) +

                    " | Sacas " +
                    formatarNumeroRelatorio(
                        item.sacas60kg,
                        2
                    ) +

                    " | Método " +
                    metodoPeso +

                    " | PMS " +
                    formatarNumeroRelatorio(
                        item.pms,
                        2
                    ) +

                    " | Fazenda " +
                    (
                        item.fazenda ||
                        "-"
                    ) +

                    " | Secagem " +
                    secagem +

                    " | Status " +
                    status.nivel;


                const linhasPDF =
                    pdf.splitTextToSize(
                        linha,
                        170
                    );


                const alturaNecessaria =
                    linhasPDF.length *
                    6;


                if (
                    y +
                    alturaNecessaria >
                    280
                ) {

                    pdf.addPage();

                    y = 20;

                }


                pdf.setFontSize(9);

                pdf.text(
                    linhasPDF,
                    20,
                    y
                );


                y +=
                    alturaNecessaria +
                    2;

            }
        );

    }


    // ===============================
    // SALVAR
    // ===============================

    pdf.save(
        "Relatorio_SeedControl.pdf"
    );

}


// ===============================
// EXPORTAR EXCEL
// ===============================

function exportarExcel() {

    if (
        typeof XLSX ===
        "undefined"
    ) {

        alert(
            "Biblioteca XLSX não carregada."
        );

        return;

    }


    const resumo =
        obterResumoAtual();


    const filtros =
        resumo.filtros;


    const registros =
        Array.isArray(
            resumo.registrosFiltrados
        )
            ? resumo.registrosFiltrados
            : [];


    const inteligente =
        resumo.estoqueInteligente;


    const workbook =
        XLSX.utils.book_new();


    // ===============================
    // RESUMO
    // ===============================

    const sheetResumoDados = [

        {
            Campo:
                "Data",

            Valor:
                new Date()
                    .toLocaleString(
                        "pt-BR"
                    )
        },

        {
            Campo:
                "Filtro Cultivar",

            Valor:
                filtros.cultivar ||
                "Todas"
        },

        {
            Campo:
                "Filtro Fazenda",

            Valor:
                filtros.fazenda ||
                "Todas"
        },

        {
            Campo:
                "Total Bags",

            Valor:
                resumo.totalBags
        },

        {
            Campo:
                "Kgs (MÉDIA)",

            Valor:
                resumo.totalKgsMedia
        },

        {
            Campo:
                "Sacas (60 kg)",

            Valor:
                resumo.totalSacas60kg
        },

        {
            Campo:
                "Cultivares",

            Valor:
                resumo.cultivares
        },

        {
            Campo:
                "Lotes",

            Valor:
                resumo.lotes
        },

        {
            Campo:
                "Fazendas",

            Valor:
                resumo.fazendas
        },

        {
            Campo:
                "Média Umidade",

            Valor:
                resumo.mediaUmidade
        },

        {
            Campo:
                "Média Temperatura",

            Valor:
                resumo.mediaTemperatura
        },

        {
            Campo:
                "Média PMS",

            Valor:
                resumo.mediaPMS
        },

        {
            Campo:
                "Normal",

            Valor:
                inteligente.normal
        },

        {
            Campo:
                "Baixo",

            Valor:
                inteligente.baixo
        },

        {
            Campo:
                "Crítico",

            Valor:
                inteligente.critico
        },

        {
            Campo:
                "Limite Baixo",

            Valor:
                inteligente.limites
                    .limiteBaixo
        },

        {
            Campo:
                "Limite Crítico",

            Valor:
                inteligente.limites
                    .limiteCritico
        }

    ];


    const sheetResumo =
        XLSX.utils.json_to_sheet(
            sheetResumoDados
        );


    // ===============================
    // ESTOQUE
    // ===============================

    const sheetRegistrosDados =
        registros.map(
            function (item) {

                const status =
                    obterStatusEstoque(
                        item
                    );


                return {

                    CULTIVAR:
                        item.cultivar ||
                        "",

                    PENEIRA:
                        item.peneira ||
                        "",

                    LOTE:
                        item.lote ||
                        "",

                    BAGS:
                        Number(
                            item.bags
                        ) || 0,

                    "KGS (MÉDIA)":
                        Number(
                            item.kgsMedia
                        ) || 0,

                    "SACAS (60 KG)":
                        Number(
                            item.sacas60kg
                        ) || 0,

                    "MÉTODO DO PESO":
                        obterTextoMetodoPesoRelatorio(
                            item.metodoPeso
                        ),

                    UMIDADE:
                        Number(
                            item.umidade
                        ) || 0,

                    TEMPERATURA:
                        Number(
                            item.temperatura
                        ) || 0,

                    PMS:
                        Number(
                            item.pms
                        ) || 0,

                    FAZENDA:
                        item.fazenda ||
                        "",

                    TALHAO:
                        item.talhao ||
                        "",

                    SECAGEM:
                        obterTextoSecagemRelatorio(
                            item.secagem
                        ),

                    STATUS:
                        status.nivel

                };

            }
        );


    const sheetRegistros =
        XLSX.utils.json_to_sheet(
            sheetRegistrosDados
        );


    // ===============================
    // POR CULTIVAR
    // ===============================

    const sheetCultivarDados =
        Object.entries(
            resumo.bagsPorCultivar ||
            {}
        )
            .sort(
                (a, b) =>
                    b[1] -
                        a[1] ||
                    a[0].localeCompare(
                        b[0],
                        "pt-BR",
                        {
                            sensitivity:
                                "base"
                        }
                    )
            )
            .map(
                ([cultivar, bags]) => ({

                    CULTIVAR:
                        cultivar,

                    BAGS:
                        bags

                })
            );


    const sheetCultivar =
        XLSX.utils.json_to_sheet(
            sheetCultivarDados
        );


    // ===============================
    // ESTOQUE INTELIGENTE
    // ===============================

    const sheetInteligenteDados = [

        {
            Campo:
                "Normal",

            Valor:
                inteligente.normal
        },

        {
            Campo:
                "Baixo",

            Valor:
                inteligente.baixo
        },

        {
            Campo:
                "Crítico",

            Valor:
                inteligente.critico
        },

        {
            Campo:
                "Limite Baixo",

            Valor:
                inteligente.limites
                    .limiteBaixo
        },

        {
            Campo:
                "Limite Crítico",

            Valor:
                inteligente.limites
                    .limiteCritico
        }

    ];


    const sheetInteligente =
        XLSX.utils.json_to_sheet(
            sheetInteligenteDados
        );


    // ===============================
    // MONTAR ARQUIVO
    // ===============================

    XLSX.utils.book_append_sheet(
        workbook,
        sheetResumo,
        "Resumo"
    );


    XLSX.utils.book_append_sheet(
        workbook,
        sheetInteligente,
        "Inteligente"
    );


    XLSX.utils.book_append_sheet(
        workbook,
        sheetRegistros,
        "Estoque"
    );


    XLSX.utils.book_append_sheet(
        workbook,
        sheetCultivar,
        "Por Cultivar"
    );


    XLSX.writeFile(
        workbook,
        "Relatorio_SeedControl.xlsx"
    );

}


// ===============================
// INICIALIZAÇÃO
// ===============================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarRelatorios
    );

} else {

    iniciarRelatorios();

}