// ===============================
// SeedControl v3.8
// backup.js
// ===============================

const btnBackup =
    document.getElementById(
        "btnBackup"
    );

const btnRestaurar =
    document.getElementById(
        "btnRestaurar"
    );

const arquivoBackup =
    document.getElementById(
        "arquivoBackup"
    );

const btnLimpar =
    document.getElementById(
        "btnLimpar"
    );


// ===============================
// OUVINTES
// ===============================

if (btnBackup) {

    btnBackup.addEventListener(
        "click",
        fazerBackup
    );

}


if (btnRestaurar) {

    btnRestaurar.addEventListener(
        "click",
        restaurarArquivoBackup
    );

}


if (btnLimpar) {

    btnLimpar.addEventListener(
        "click",
        limparTudo
    );

}


// ===============================
// NORMALIZAR BACKUP
//
// Aceita:
//
// 1. Backup normal do SeedControl
// 2. Backup antigo
// 3. Backup de emergência
//    criado pelo Diagnóstico
// ===============================

function normalizarArquivoBackup(
    dados
) {

    if (
        !dados ||
        typeof dados !== "object" ||
        Array.isArray(dados)
    ) {

        return null;

    }


    // ===============================
    // BACKUP DE EMERGÊNCIA
    // ===============================

    if (
        dados.seedControlBackup === true &&
        dados.dados &&
        typeof dados.dados === "object"
    ) {

        return {

            versao:
                dados.versao ||
                "emergencia",

            data:
                dados.criadoEm ||
                "",

            estoque:
                Array.isArray(
                    dados.dados.estoque
                )
                    ? dados.dados.estoque
                    : [],

            historico:
                Array.isArray(
                    dados.dados.historico
                )
                    ? dados.dados.historico
                    : [],

            configuracoes:
                (
                    dados.dados.configuracoes &&
                    typeof dados.dados.configuracoes ===
                        "object" &&
                    !Array.isArray(
                        dados.dados.configuracoes
                    )
                )
                    ? dados.dados.configuracoes
                    : {}

        };

    }


    // ===============================
    // BACKUP NORMAL / ANTIGO
    // ===============================

    if (
        !Array.isArray(
            dados.estoque
        )
    ) {

        return null;

    }


    if (
        dados.historico !== undefined &&
        !Array.isArray(
            dados.historico
        )
    ) {

        return null;

    }


    return {

        versao:
            dados.versao ||
            "antigo",

        data:
            dados.data ||
            "",

        estoque:
            dados.estoque,

        historico:
            Array.isArray(
                dados.historico
            )
                ? dados.historico
                : [],

        configuracoes:
            (
                dados.configuracoes &&
                typeof dados.configuracoes ===
                    "object" &&
                !Array.isArray(
                    dados.configuracoes
                )
            )
                ? dados.configuracoes
                : {}

    };

}


// ===============================
// GERAR BACKUP
// ===============================

function fazerBackup() {

    try {

        // ===============================
        // SERVIÇO CENTRAL
        // ===============================

        const dados =
            gerarBackup();


        if (
            !dados ||
            !Array.isArray(
                dados.estoque
            ) ||
            !Array.isArray(
                dados.historico
            )
        ) {

            throw new Error(
                "Estrutura de backup inválida."
            );

        }


        const agora =
            new Date();


        // ===============================
        // CRIAR ARQUIVO
        // ===============================

        const blob =
            new Blob(

                [
                    JSON.stringify(
                        dados,
                        null,
                        2
                    )
                ],

                {
                    type:
                        "application/json;charset=utf-8"
                }

            );


        const url =
            URL.createObjectURL(
                blob
            );


        const link =
            document.createElement(
                "a"
            );


        // ===============================
        // DATA DO ARQUIVO
        // ===============================

        const dataArquivo = [

            agora.getFullYear(),

            String(
                agora.getMonth() + 1
            ).padStart(
                2,
                "0"
            ),

            String(
                agora.getDate()
            ).padStart(
                2,
                "0"
            )

        ].join("-");


        const horaArquivo = [

            String(
                agora.getHours()
            ).padStart(
                2,
                "0"
            ),

            String(
                agora.getMinutes()
            ).padStart(
                2,
                "0"
            ),

            String(
                agora.getSeconds()
            ).padStart(
                2,
                "0"
            )

        ].join("-");


        // ===============================
        // DOWNLOAD
        // ===============================

        link.href =
            url;


        link.download =
            "SeedControl_Backup_" +
            dataArquivo +
            "_" +
            horaArquivo +
            ".json";


        document.body.appendChild(
            link
        );


        link.click();


        document.body.removeChild(
            link
        );


        setTimeout(
            function () {

                URL.revokeObjectURL(
                    url
                );

            },
            1000
        );


        alert(

            "Backup criado com sucesso!\n\n" +

            "Lotes: " +
            dados.estoque.length +

            "\nHistórico: " +
            dados.historico.length +

            "\n\nGuarde este arquivo em local seguro."

        );


    } catch (erro) {

        console.error(
            "Erro ao gerar backup:",
            erro
        );


        alert(
            "Não foi possível gerar o backup."
        );

    }

}


// ===============================
// RESTAURAR BACKUP
// ===============================

function restaurarArquivoBackup() {

    if (
        !arquivoBackup ||
        !arquivoBackup.files ||
        !arquivoBackup.files.length
    ) {

        alert(
            "Selecione um arquivo de backup."
        );

        return;

    }


    const arquivo =
        arquivoBackup.files[0];


    // ===============================
    // VALIDAR EXTENSÃO
    // ===============================

    const nomeArquivo =
        String(
            arquivo.name ||
            ""
        ).toLowerCase();


    if (
        nomeArquivo &&
        !nomeArquivo.endsWith(
            ".json"
        )
    ) {

        alert(
            "Selecione um arquivo de backup .json."
        );

        return;

    }


    const leitor =
        new FileReader();


    leitor.onload =
        function (evento) {

            try {

                const dadosLidos =
                    JSON.parse(
                        evento.target.result
                    );


                // ===============================
                // NORMALIZAR
                // ===============================

                const dados =
                    normalizarArquivoBackup(
                        dadosLidos
                    );


                if (!dados) {

                    alert(
                        "Este arquivo não é um backup válido do SeedControl."
                    );

                    return;

                }


                // ===============================
                // INFORMAÇÕES
                // ===============================

                const totalEstoque =
                    dados.estoque.length;


                const totalHistorico =
                    dados.historico.length;


                const totalConfiguracoes =
                    Object.keys(
                        dados.configuracoes
                    ).length;


                // ===============================
                // CONFIRMAÇÃO
                // ===============================

                const confirmar =
                    confirm(

                        "Restaurar este backup?\n\n" +

                        "Versão: " +
                        dados.versao +

                        "\nEstoque: " +
                        totalEstoque +
                        " lote(s)" +

                        "\nHistórico: " +
                        totalHistorico +
                        " registro(s)" +

                        "\nConfigurações: " +
                        (
                            totalConfiguracoes > 0
                                ? "Sim"
                                : "Não"
                        ) +

                        "\n\n" +

                        "ATENÇÃO:\n" +
                        "Os dados atuais serão substituídos."

                    );


                if (!confirmar) {

                    return;

                }


                // ===============================
                // SEGUNDA CONFIRMAÇÃO
                // ===============================

                const confirmarSubstituicao =
                    confirm(

                        "Confirma a restauração?\n\n" +

                        "Recomendação: mantenha um backup dos dados atuais antes de continuar."

                    );


                if (!confirmarSubstituicao) {

                    return;

                }


                // ===============================
                // SERVIÇO CENTRAL
                // ===============================

                const resultado =
                    restaurarBackup(
                        dados
                    );


                if (
                    !resultado ||
                    !resultado.ok
                ) {

                    alert(

                        resultado &&
                        resultado.mensagem

                            ? resultado.mensagem

                            : "Não foi possível restaurar o backup."

                    );

                    return;

                }


                // ===============================
                // CONFIRMAÇÃO FINAL
                // ===============================

                alert(

                    "Backup restaurado com sucesso!\n\n" +

                    totalEstoque +
                    " lote(s) restaurado(s)."

                );


                // ===============================
                // LIMPAR INPUT
                // ===============================

                arquivoBackup.value =
                    "";


                // ===============================
                // VOLTAR PARA INÍCIO
                // ===============================

                window.location.href =
                    "index.html";


            } catch (erro) {

                console.error(
                    "Erro ao restaurar backup:",
                    erro
                );


                alert(
                    "Arquivo de backup inválido ou corrompido."
                );

            }

        };


    leitor.onerror =
        function () {

            alert(
                "Não foi possível ler o arquivo de backup."
            );

        };


    leitor.readAsText(
        arquivo
    );

}


// ===============================
// LIMPAR TODOS OS DADOS
// ===============================

function limparTudo() {

    const confirmar =
        confirm(

            "Deseja apagar todos os dados do SeedControl?\n\n" +

            "Esta ação removerá:\n" +
            "• Estoque\n" +
            "• Histórico\n" +
            "• Configurações\n\n" +

            "Faça um backup antes de continuar.\n\n" +

            "Esta ação não pode ser desfeita."

        );


    if (!confirmar) {

        return;

    }


    const segundaConfirmacao =
        confirm(

            "Confirma que deseja apagar TODOS os dados?"

        );


    if (!segundaConfirmacao) {

        return;

    }


    try {

        const resultado =
            limparBanco();


        if (
            !resultado ||
            !resultado.ok
        ) {

            alert(

                resultado &&
                resultado.mensagem

                    ? resultado.mensagem

                    : "Não foi possível apagar os dados."

            );

            return;

        }


        alert(
            resultado.mensagem
        );


        window.location.href =
            "index.html";


    } catch (erro) {

        console.error(
            "Erro ao apagar dados:",
            erro
        );


        alert(
            "Não foi possível apagar os dados."
        );

    }

}