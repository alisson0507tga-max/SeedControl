// ==========================================
// SeedControl v3.8
// ia-config.js
//
// CONFIGURAÇÃO DA IA
//
// IMPORTANTE:
// NUNCA colocar API KEY aqui.
// ==========================================

(function () {

    "use strict";


    // ======================================
    // ENDPOINT DO SEU BACKEND
    //
    // DEIXE VAZIO POR ENQUANTO.
    //
    // Quando o backend estiver publicado,
    // coloque apenas a URL dele aqui.
    //
    // Exemplo:
    //
    // https://meu-servidor.com/api/seedcontrol-ai
    // ======================================

    const ENDPOINT_IA = "";


    // ======================================
    // PROVEDOR
    // ======================================

    const PROVEDOR =
        "openai";


    // ======================================
    // MODO AUTOMÁTICO
    //
    // Sem endpoint:
    // local
    //
    // Com endpoint:
    // externo
    // ======================================

    const MODO =
        ENDPOINT_IA

            ? "externo"

            : "local";


    // ======================================
    // CONFIGURAÇÃO PÚBLICA
    // ======================================

    window.SeedControlIAConfig = {

        provedor:
            PROVEDOR,

        endpoint:
            ENDPOINT_IA,

        modo:
            MODO

    };


    // ======================================
    // APLICAR NO ia-service.js
    // ======================================

    if (
        window.SeedControlIA &&
        typeof window
            .SeedControlIA
            .configurarProvedor ===
            "function"
    ) {

        window
            .SeedControlIA
            .configurarProvedor(
                {

                    provedor:
                        PROVEDOR,

                    endpoint:
                        ENDPOINT_IA,

                    modo:
                        MODO

                }
            );

    }


    console.log(

        "[SeedControl] IA:",

        MODO === "externo"

            ? "modo externo"

            : "modo local"

    );


})();