// ===============================
// SeedControl v3.8
// estoque.js
// ===============================

let frameLista = null;
let ouvintesRegistrados = false;

const lista = document.getElementById("lista");
const pesquisa = document.getElementById("pesquisa");
const ordenacao = document.getElementById("ordenacao");

const comparadorTexto = new Intl.Collator("pt-BR", {
    sensitivity: "base",
    numeric: true
});


// ===============================
// SEGURANÇA HTML
// ===============================

function escaparHtml(valor) {

    return String(valor ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

}


// ===============================
// FORMATAÇÃO DE NÚMEROS
// ===============================

function formatarNumeroEstoque(
    valor,
    casas = 2
) {

    const numero = Number(valor);

    if (!Number.isFinite(numero)) {
        return "0";
    }

    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ===============================
// TEXTO DO MÉTODO
// ===============================

function obterTextoMetodoPeso(
    metodoPeso
) {

    const metodo =
        normalizarMetodoPeso(
            metodoPeso
        );


    if (metodo === "comercial") {

        return "🌱 Comercial (PMS)";

    }


    return "📦 Estimado";

}


// ===============================
// DETALHE DO PESO DO BAG
// ===============================

function obterDetalhePesoBagEstoque(
    item
) {

    const metodo =
        normalizarMetodoPeso(
            item.metodoPeso
        );


    const peso =
        formatarNumeroEstoque(
            item.pesoBagKg,
            2
        );


    if (
        metodo ===
        "comercial"
    ) {

        return (
            peso +
            " kg — calculado pelo PMS"
        );

    }


    return peso + " kg";

}


// ===============================
// FILTRAR E ORDENAR
// ===============================

function obterRegistrosFiltrados() {

    const estoque =
        carregarEstoque();


    const termo =
        normalizarTexto(
            pesquisa
                ? pesquisa.value
                : ""
        );


    const criterioOrdenacao =
        ordenacao
            ? ordenacao.value
            : "data_desc";


    const filtrados =
        estoque.filter(item => {

            if (!item) {
                return false;
            }


            if (!termo) {
                return true;
            }


            return [

                item.cultivar,
                item.lote,
                item.fazenda,
                item.talhao,
                item.peneira,
                item.bags,
                item.pesoBagKg,
                item.kgsMedia,
                item.pms

            ].some(
                campo =>
                    normalizarTexto(
                        campo
                    ).includes(
                        termo
                    )
            );

        });


    filtrados.sort(
        (a, b) => {

            switch (
                criterioOrdenacao
            ) {

                case "cultivar_asc":

                    return comparadorTexto.compare(
                        a.cultivar || "",
                        b.cultivar || ""
                    );


                case "fazenda_asc":

                    return comparadorTexto.compare(
                        a.fazenda || "",
                        b.fazenda || ""
                    );


                case "lote_asc":

                    return (
                        Number(a.lote) -
                        Number(b.lote)
                    );


                case "bags_desc":

                    return (
                        Number(b.bags) -
                        Number(a.bags)
                    );


                case "data_desc":
                default:

                    return (
                        Number(b.id) -
                        Number(a.id)
                    );

            }

        }
    );


    return filtrados;

}


// ===============================
// RENDERIZAR ESTOQUE
// ===============================

function renderizarLista() {

    frameLista = null;


    if (!lista) {
        return;
    }


    const registros =
        obterRegistrosFiltrados();


    const resumo =
        obterResumoEstoqueInteligente(
            registros
        );


    window.__seedEstoqueInteligente =
        resumo;


    // ===============================
    // CAMPOS DO RESUMO
    // ===============================

    const totalBags =
        document.getElementById(
            "totalBags"
        );


    const totalKgsMedia =
        document.getElementById(
            "totalKgsMedia"
        );


    const totalSacas60kg =
        document.getElementById(
            "totalSacas60kg"
        );


    const totalLotes =
        document.getElementById(
            "totalLotes"
        );


    // ===============================
    // TOTAL DE BAGS
    // ===============================

    if (totalBags) {

        totalBags.textContent =
            formatarNumeroEstoque(
                resumo.totalBags,
                2
            );

    }


    // ===============================
    // TOTAL EM KG
    // ===============================

    if (totalKgsMedia) {

        totalKgsMedia.textContent =
            formatarNumeroEstoque(
                resumo.totalKgsMedia,
                2
            );

    }


    // ===============================
    // TOTAL EM SACAS
    // ===============================

    if (totalSacas60kg) {

        totalSacas60kg.textContent =
            formatarNumeroEstoque(
                resumo.totalSacas60kg,
                2
            );

    }


    // ===============================
    // TOTAL DE LOTES
    // ===============================

    if (totalLotes) {

        totalLotes.textContent =
            resumo.totalRegistros;

    }


    // ===============================
    // SEM REGISTROS
    // ===============================

    if (!registros.length) {

        lista.innerHTML = `

        <div class="card">

            <h2>
                ⚠️ Nenhum registro encontrado.
            </h2>

            <p>
                Experimente alterar a pesquisa.
            </p>

        </div>

        `;

        return;

    }


    // ===============================
    // CARDS
    // ===============================

    lista.innerHTML =
        registros.map(
            item => {

                const status =
                    obterStatusEstoque(
                        item
                    );


                const metodoPeso =
                    obterTextoMetodoPeso(
                        item.metodoPeso
                    );


                const pesoBag =
                    obterDetalhePesoBagEstoque(
                        item
                    );


                const kgsMedia =
                    formatarNumeroEstoque(
                        item.kgsMedia,
                        2
                    );


                const sacas60kg =
                    formatarNumeroEstoque(
                        item.sacas60kg,
                        2
                    );


                const secagem =
                    item.secagem === "secou" ||
                    item.secagem === true

                        ? "✅ Secou"

                        : "ℹ️ Não precisou secar";


                return `

<div
    class="card card-registro"
    style="
        border-left:8px solid ${status.cor};
    "
>

<h2>
    🌱 ${escaparHtml(item.cultivar)}
</h2>


<p>

<span
    style="
        display:inline-block;
        padding:4px 10px;
        border-radius:20px;
        background:${status.cor}22;
        color:${status.cor};
        font-weight:bold;
    "
>

${status.texto}

</span>

</p>


<p>
    <strong>📦 Bags:</strong>
    ${formatarNumeroEstoque(item.bags, 2)}
</p>


<p>
    <strong>⚖️ Peso por Bag:</strong>
    ${pesoBag}
</p>


<p>
    <strong>⚖️ Kg (Média):</strong>
    ${kgsMedia} kg
</p>


<p>
    <strong>🌾 Sacas (60 kg):</strong>
    ${sacas60kg}
</p>


<p>
    <strong>⚙️ Método do Peso:</strong>
    ${metodoPeso}
</p>


<p>
    <strong>📋 Lote:</strong>
    ${escaparHtml(item.lote)}
</p>


<p>
    <strong>🚜 Fazenda:</strong>
    ${escaparHtml(item.fazenda)}
</p>


<p>
    <strong>🌡️ Temperatura:</strong>
    ${formatarNumeroEstoque(item.temperatura, 2)} °C
</p>


<p>
    <strong>💧 Umidade:</strong>
    ${formatarNumeroEstoque(item.umidade, 2)}%
</p>


<p>
    <strong>⚖️ PMS:</strong>
    ${formatarNumeroEstoque(item.pms, 2)} g
</p>


<p>
    <strong>🌾 Peneira:</strong>
    ${escaparHtml(item.peneira)}
</p>


<p>
    <strong>📍 Talhão:</strong>
    ${escaparHtml(item.talhao || "-")}
</p>


<p>
    <strong>🌬️ Secagem:</strong>
    ${secagem}
</p>


<div class="acoes-registro">


<button
    type="button"
    class="btn-editar"
    data-action="editar"
    data-id="${item.id}"
>
    ✏️ Editar
</button>


<button
    type="button"
    class="btn-qr"
    data-action="qrcode"
    data-id="${item.id}"
    style="
        background:#7c3aed;
    "
>
    📷 QR Code
</button>


<button
    type="button"
    class="btn-excluir"
    data-action="excluir"
    data-id="${item.id}"
>
    🗑️ Excluir
</button>


</div>

</div>

`;

            }
        ).join("");

}


// ===============================
// AGENDAR RENDERIZAÇÃO
// ===============================

function agendarRenderizacao() {

    if (frameLista) {

        cancelAnimationFrame(
            frameLista
        );

    }


    frameLista =
        requestAnimationFrame(
            renderizarLista
        );

}


// ===============================
// CLIQUES DOS CARDS
// ===============================

function tratarCliqueLista(
    evento
) {

    const botao =
        evento.target.closest(
            "button[data-action]"
        );


    if (botao) {

        evento.stopPropagation();


        const id =
            Number(
                botao.dataset.id
            );


        if (!id) {
            return;
        }


        // ===============================
        // EDITAR
        // ===============================

        if (
            botao.dataset.action ===
            "editar"
        ) {

            window.location.href =
                "cadastro.html?id=" +
                encodeURIComponent(
                    id
                );

            return;

        }


        // ===============================
        // QR CODE
        // ===============================

        if (
            botao.dataset.action ===
            "qrcode"
        ) {

            window.location.href =
                "qrcode.html?id=" +
                encodeURIComponent(
                    id
                );

            return;

        }


        // ===============================
        // EXCLUIR
        // ===============================

        if (
            botao.dataset.action ===
            "excluir"
        ) {

            const registro =
                obterLotePorId(
                    id
                );


            if (!registro) {

                alert(
                    "Lote não encontrado."
                );

                return;

            }


            const confirmar =
                confirm(

                    "Deseja excluir este lote?\n\n" +

                    "Cultivar: " +
                    registro.cultivar +

                    "\nLote: " +
                    registro.lote +

                    "\nBags: " +
                    registro.bags

                );


            if (!confirmar) {
                return;
            }


            const resultado =
                excluirLote(
                    id
                );


            if (!resultado.ok) {

                alert(
                    resultado.mensagem
                );

                return;

            }


            alert(
                resultado.mensagem
            );


            agendarRenderizacao();

            return;

        }

    }


    // ===============================
    // ABRIR CULTIVAR
    // ===============================

    const card =
        evento.target.closest(
            ".card-registro"
        );


    if (!card) {
        return;
    }


    const botaoEditar =
        card.querySelector(
            ".btn-editar"
        );


    if (!botaoEditar) {
        return;
    }


    const id =
        Number(
            botaoEditar.dataset.id
        );


    const registro =
        obterLotePorId(
            id
        );


    if (!registro) {
        return;
    }


    window.location.href =
        "cultivar.html?cultivar=" +
        encodeURIComponent(
            registro.cultivar
        );

}


// ===============================
// OUVINTES
// ===============================

function registrarOuvintes() {

    if (
        ouvintesRegistrados
    ) {
        return;
    }


    ouvintesRegistrados =
        true;


    if (pesquisa) {

        pesquisa.addEventListener(
            "input",
            agendarRenderizacao
        );

    }


    if (ordenacao) {

        ordenacao.addEventListener(
            "change",
            renderizarLista
        );

    }


    if (lista) {

        lista.addEventListener(
            "click",
            tratarCliqueLista
        );

    }


    window.addEventListener(
        "seedcontrol:atualizado",
        renderizarLista
    );


    window.addEventListener(
        "storage",
        renderizarLista
    );


    window.addEventListener(
        "focus",
        renderizarLista
    );


    document.addEventListener(
        "visibilitychange",
        function () {

            if (!document.hidden) {

                renderizarLista();

            }

        }
    );

}


// ===============================
// INICIAR
// ===============================

function iniciarEstoque() {

    renderizarLista();

    registrarOuvintes();

}


// ===============================
// INICIALIZAÇÃO
// ===============================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarEstoque
    );

} else {

    iniciarEstoque();

}