// ==========================================
// SeedControl v3.8
// importar.js
// ==========================================

const inputArquivo =
    document.getElementById("arquivo");

const btnImportar =
    document.getElementById("btnImportar");


// ==========================================
// NORMALIZAR TEXTO
// ==========================================

function normalizarTextoImportacao(valor) {

    return String(valor ?? "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();

}


// ==========================================
// NORMALIZAR CABEÇALHO
// ==========================================

function normalizarCabecalhoImportacao(
    valor
) {

    return normalizarTextoImportacao(
        valor
    ).replace(
        /[^a-z0-9]/g,
        ""
    );

}


// ==========================================
// OBTER VALOR POR POSSÍVEIS CABEÇALHOS
// ==========================================

function obterValorColunaImportacao(
    item,
    nomes
) {

    if (
        !item ||
        typeof item !== "object"
    ) {

        return undefined;

    }


    const procurados =
        nomes.map(
            normalizarCabecalhoImportacao
        );


    const chaves =
        Object.keys(
            item
        );


    for (
        const chave of chaves
    ) {

        const normalizada =
            normalizarCabecalhoImportacao(
                chave
            );


        if (
            procurados.includes(
                normalizada
            )
        ) {

            return item[chave];

        }

    }


    return undefined;

}


// ==========================================
// CONVERTER NÚMERO
// ==========================================

function converterNumeroImportacao(
    valor
) {

    if (
        typeof valor === "number"
    ) {

        return Number.isFinite(valor)
            ? valor
            : 0;

    }


    let texto =
        String(
            valor ?? ""
        )
            .trim()
            .replace(/\s/g, "");


    if (!texto) {

        return 0;

    }


    // Remove unidades e textos.
    texto =
        texto.replace(
            /[^0-9,.\-]/g,
            ""
        );


    if (!texto) {

        return 0;

    }


    // Ex.: 1.050,50
    if (
        texto.includes(".") &&
        texto.includes(",")
    ) {

        if (
            texto.lastIndexOf(",") >
            texto.lastIndexOf(".")
        ) {

            texto =
                texto
                    .replace(/\./g, "")
                    .replace(",", ".");

        } else {

            texto =
                texto.replace(
                    /,/g,
                    ""
                );

        }

    }

    // Ex.: 900,5
    else if (
        texto.includes(",")
    ) {

        texto =
            texto.replace(
                ",",
                "."
            );

    }

    // Ex.: 1.050
    // Interpreta como milhar.
    else if (
        /^-?\d{1,3}(\.\d{3})+$/.test(
            texto
        )
    ) {

        texto =
            texto.replace(
                /\./g,
                ""
            );

    }


    const numero =
        Number(
            texto
        );


    return Number.isFinite(numero)
        ? numero
        : 0;

}


// ==========================================
// SECAGEM
// ==========================================

function interpretarSecagemImportacao(
    valor
) {

    if (valor === true) {

        return "secou";

    }


    if (valor === false) {

        return "nao_precisou";

    }


    const texto =
        normalizarTextoImportacao(
            valor
        );


    if (
        texto === "secou" ||
        texto === "sim" ||
        texto === "s" ||
        texto === "ok" ||
        texto === "✅" ||
        texto === "concluida" ||
        texto === "seco" ||
        texto === "1"
    ) {

        return "secou";

    }


    return "nao_precisou";

}


// ==========================================
// VALOR DA COLUNA MÉTODO
// ==========================================

function obterValorMetodoImportacao(
    item
) {

    return obterValorColunaImportacao(

        item,

        [
            "MÉTODO DO PESO",
            "METODO DO PESO",
            "MÉTODO PESO",
            "METODO PESO",
            "METODO_PESO",
            "METODOPESO",
            "metodoPeso",
            "MÉTODO",
            "METODO",
            "MÉTODO / PESO BAG",
            "METODO / PESO BAG",
            "MÉTODO / PESO POR BAG",
            "METODO / PESO POR BAG"
        ]

    );

}


// ==========================================
// MÉTODO DO PESO
// ==========================================

function interpretarMetodoPesoImportacao(
    item
) {

    const valorMetodo =
        obterValorMetodoImportacao(
            item
        );


    if (
        valorMetodo === undefined ||
        valorMetodo === null ||
        String(valorMetodo).trim() === ""
    ) {

        return "estimado";

    }


    const texto =
        normalizarTextoImportacao(
            valorMetodo
        );


    if (
        texto.includes("comercial") ||
        texto.includes("pms")
    ) {

        return normalizarMetodoPeso(
            "comercial"
        );

    }


    return normalizarMetodoPeso(
        "estimado"
    );

}


// ==========================================
// PESO PADRÃO
// ==========================================

function obterPesoPadraoImportacao() {

    if (
        typeof obterPesoEstimadoPadraoBagKg ===
        "function"
    ) {

        return obterPesoEstimadoPadraoBagKg();

    }


    return 1050;

}


// ==========================================
// PESO POR BAG
// ==========================================

function interpretarPesoBagImportacao(
    item,
    metodo
) {

    // ======================================
    // COLUNA PRÓPRIA
    // ======================================

    const valorDireto =
        obterValorColunaImportacao(

            item,

            [
                "PESO POR BAG",
                "PESO POR BAG KG",
                "PESO POR BAG (KG)",
                "PESO BAG",
                "PESO BAG KG",
                "PESO BAG (KG)",
                "KG/BAG",
                "KG POR BAG",
                "PESOBAGKG",
                "pesoBagKg"
            ]

        );


    if (
        valorDireto !== undefined &&
        valorDireto !== null &&
        String(valorDireto).trim() !== ""
    ) {

        const peso =
            converterNumeroImportacao(
                valorDireto
            );


        if (peso > 0) {

            return peso;

        }

    }


    // ======================================
    // MÉTODO / PESO BAG
    //
    // Ex.:
    // Estimado — 900 kg/Bag
    // Comercial (PMS) — 1.000 kg/Bag
    // ======================================

    const valorMetodo =
        String(
            obterValorMetodoImportacao(
                item
            ) ?? ""
        );


    const encontrouPeso =
        valorMetodo.match(

            /(-?\d[\d.,]*)\s*kg/i

        );


    if (
        encontrouPeso &&
        encontrouPeso[1]
    ) {

        const peso =
            converterNumeroImportacao(
                encontrouPeso[1]
            );


        if (peso > 0) {

            return peso;

        }

    }


    // ======================================
    // PLANILHA ANTIGA
    // ======================================

    if (
        metodo === "estimado"
    ) {

        return obterPesoPadraoImportacao();

    }


    // Comercial será calculado pelo PMS.
    return 0;

}


// ==========================================
// ENCONTRAR LINHA DO CABEÇALHO
// ==========================================

function linhaPareceCabecalho(
    linha
) {

    if (
        !Array.isArray(
            linha
        )
    ) {

        return false;

    }


    const campos =
        linha.map(
            normalizarCabecalhoImportacao
        );


    const possuiCultivar =
        campos.includes(
            "cultivar"
        );


    const possuiLote =
        campos.includes("lote") ||
        campos.includes("lotes");


    const possuiBags =
        campos.includes("bags") ||
        campos.includes(
            "quantidadebags"
        );


    return (
        possuiCultivar &&
        possuiLote &&
        possuiBags
    );

}


// ==========================================
// EXTRAIR REGISTROS
//
// Aceita inclusive o Excel exportado
// pelo próprio SeedControl, que possui
// uma linha de título antes do cabeçalho.
// ==========================================

function extrairRegistrosPlanilha(
    planilha
) {

    const linhas =
        XLSX.utils.sheet_to_json(
            planilha,
            {
                header: 1,
                defval: ""
            }
        );


    if (
        !Array.isArray(linhas) ||
        linhas.length === 0
    ) {

        return [];

    }


    const indiceCabecalho =
        linhas.findIndex(
            linhaPareceCabecalho
        );


    // ======================================
    // FALLBACK
    // ======================================

    if (
        indiceCabecalho < 0
    ) {

        return XLSX.utils.sheet_to_json(
            planilha,
            {
                defval: ""
            }
        );

    }


    const cabecalhos =
        linhas[
            indiceCabecalho
        ].map(
            item =>
                String(
                    item ?? ""
                ).trim()
        );


    const registros = [];


    linhas
        .slice(
            indiceCabecalho + 1
        )
        .forEach(
            linha => {

                if (
                    !Array.isArray(
                        linha
                    )
                ) {

                    return;

                }


                const possuiDados =
                    linha.some(
                        valor =>
                            String(
                                valor ?? ""
                            ).trim() !== ""
                    );


                if (!possuiDados) {

                    return;

                }


                const objeto = {};


                cabecalhos.forEach(
                    (
                        cabecalho,
                        indice
                    ) => {

                        if (!cabecalho) {

                            return;

                        }


                        objeto[
                            cabecalho
                        ] =
                            linha[indice];

                    }
                );


                registros.push(
                    objeto
                );

            }
        );


    return registros;

}


// ==========================================
// DUPLICIDADE
// ==========================================

function criarChaveDuplicidadeImportacao(
    lote
) {

    const cultivar =
        normalizarTextoImportacao(
            lote.cultivar
        );


    const numeroLote =
        normalizarTextoImportacao(
            lote.lote
        );


    const fazenda =
        normalizarTextoImportacao(
            lote.fazenda
        );


    if (
        !cultivar ||
        !numeroLote ||
        !fazenda
    ) {

        return "";

    }


    return (
        cultivar +
        "|" +
        numeroLote +
        "|" +
        fazenda
    );

}


// ==========================================
// IMPORTAR
// ==========================================

if (btnImportar) {

    btnImportar.addEventListener(
        "click",
        function () {


            // ==================================
            // ARQUIVO
            // ==================================

            if (
                !inputArquivo ||
                inputArquivo.files.length === 0
            ) {

                alert(
                    "Selecione uma planilha."
                );

                return;

            }


            if (
                typeof XLSX ===
                "undefined"
            ) {

                alert(
                    "Biblioteca XLSX não carregada."
                );

                return;

            }


            if (
                typeof cadastrarLote !==
                "function"
            ) {

                alert(
                    "O banco de dados do SeedControl não foi carregado."
                );

                return;

            }


            const arquivo =
                inputArquivo.files[0];


            const nomeArquivo =
                String(
                    arquivo.name || ""
                ).toLowerCase();


            if (
                !nomeArquivo.endsWith(".xlsx") &&
                !nomeArquivo.endsWith(".xls")
            ) {

                alert(
                    "Selecione um arquivo Excel (.xlsx ou .xls)."
                );

                return;

            }


            const leitor =
                new FileReader();


            // ==================================
            // LEITURA
            // ==================================

            leitor.onload =
                function (evento) {

                    try {

                        const dados =
                            new Uint8Array(
                                evento.target.result
                            );


                        const workbook =
                            XLSX.read(
                                dados,
                                {
                                    type: "array"
                                }
                            );


                        if (
                            !workbook.SheetNames ||
                            workbook.SheetNames.length === 0
                        ) {

                            alert(
                                "Nenhuma aba encontrada na planilha."
                            );

                            return;

                        }


                        const nomeAba =
                            workbook.SheetNames[0];


                        const planilha =
                            workbook.Sheets[
                                nomeAba
                            ];


                        const registros =
                            extrairRegistrosPlanilha(
                                planilha
                            );


                        if (
                            !Array.isArray(registros) ||
                            registros.length === 0
                        ) {

                            alert(
                                "A planilha não possui registros para importar."
                            );

                            return;

                        }


                        // ==================================
                        // CONFIRMAÇÃO
                        // ==================================

                        const confirmar =
                            confirm(

                                "Importar esta planilha?\n\n" +

                                "Linhas encontradas: " +
                                registros.length +

                                "\n\nOs lotes atuais NÃO serão apagados." +

                                "\nLotes duplicados serão ignorados."

                            );


                        if (!confirmar) {

                            return;

                        }


                        // ==================================
                        // CONTADORES
                        // ==================================

                        let importados = 0;
                        let ignorados = 0;
                        let duplicados = 0;
                        let invalidos = 0;

                        let estimados = 0;
                        let comerciais = 0;


                        const idBase =
                            Date.now();


                        // ==================================
                        // DUPLICADOS EXISTENTES
                        // ==================================

                        const chavesExistentes =
                            new Set();


                        const estoqueAtual =
                            typeof carregarEstoque ===
                            "function"

                                ? carregarEstoque()

                                : [];


                        if (
                            Array.isArray(
                                estoqueAtual
                            )
                        ) {

                            estoqueAtual.forEach(
                                lote => {

                                    const chave =
                                        criarChaveDuplicidadeImportacao(
                                            lote
                                        );


                                    if (chave) {

                                        chavesExistentes.add(
                                            chave
                                        );

                                    }

                                }
                            );

                        }


                        // ==================================
                        // REGISTROS
                        // ==================================

                        registros.forEach(
                            function (
                                item,
                                indice
                            ) {


                                // ==========================
                                // CULTIVAR
                                // ==========================

                                const cultivar =
                                    String(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "CULTIVAR"
                                            ]

                                        ) ?? ""

                                    ).trim();


                                // ==========================
                                // PENEIRA
                                // ==========================

                                const peneira =
                                    String(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "PENEIRA"
                                            ]

                                        ) ?? ""

                                    ).trim();


                                // ==========================
                                // LOTE
                                // ==========================

                                const lote =
                                    converterNumeroImportacao(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "LOTE",
                                                "LOTES",
                                                "NÚMERO DO LOTE",
                                                "NUMERO DO LOTE"
                                            ]

                                        )

                                    );


                                // ==========================
                                // BAGS
                                // ==========================

                                const bags =
                                    converterNumeroImportacao(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "BAGS",
                                                "QUANTIDADE BAGS",
                                                "QUANTIDADE DE BAGS"
                                            ]

                                        )

                                    );


                                // ==========================
                                // UMIDADE
                                // ==========================

                                const umidade =
                                    converterNumeroImportacao(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "UMIDADE",
                                                "UMIDADE %",
                                                "UMIDADE PERCENTUAL"
                                            ]

                                        )

                                    );


                                // ==========================
                                // TEMPERATURA
                                // ==========================

                                const temperatura =
                                    converterNumeroImportacao(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "TEMPERATURA",
                                                "TEMPERATURA °C",
                                                "TEMPERATURA C"
                                            ]

                                        )

                                    );


                                // ==========================
                                // PMS
                                // ==========================

                                const pms =
                                    converterNumeroImportacao(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "PMS",
                                                "PMS (g)",
                                                "PMS ( g )"
                                            ]

                                        )

                                    );


                                // ==========================
                                // FAZENDA
                                // ==========================

                                const fazenda =
                                    String(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "FAZENDA"
                                            ]

                                        ) ?? ""

                                    ).trim();


                                // ==========================
                                // TALHÃO
                                // ==========================

                                const talhao =
                                    String(

                                        obterValorColunaImportacao(

                                            item,

                                            [
                                                "TALHÃO",
                                                "TALHAO"
                                            ]

                                        ) ?? ""

                                    ).trim();


                                // ==========================
                                // SECAGEM
                                // ==========================

                                const valorSecagem =
                                    obterValorColunaImportacao(

                                        item,

                                        [
                                            "SECAGEM",
                                            "SECADOR"
                                        ]

                                    );


                                // ==========================
                                // MÉTODO
                                // ==========================

                                const metodoPeso =
                                    interpretarMetodoPesoImportacao(
                                        item
                                    );


                                // ==========================
                                // PESO BAG
                                // ==========================

                                const pesoBagKg =
                                    interpretarPesoBagImportacao(

                                        item,

                                        metodoPeso

                                    );


                                // ==========================
                                // OBJETO
                                // ==========================

                                const novoLote = {

                                    id:
                                        idBase +
                                        indice,

                                    cultivar:
                                        cultivar,

                                    peneira:
                                        peneira,

                                    lote:
                                        lote,

                                    bags:
                                        bags,

                                    umidade:
                                        umidade,

                                    temperatura:
                                        temperatura,

                                    pms:
                                        pms,

                                    pesoBagKg:
                                        pesoBagKg,

                                    fazenda:
                                        fazenda,

                                    talhao:
                                        talhao,

                                    secagem:
                                        interpretarSecagemImportacao(
                                            valorSecagem
                                        ),

                                    metodoPeso:
                                        metodoPeso

                                };


                                // ==========================
                                // DUPLICIDADE
                                // ==========================

                                const chave =
                                    criarChaveDuplicidadeImportacao(
                                        novoLote
                                    );


                                if (
                                    chave &&
                                    chavesExistentes.has(
                                        chave
                                    )
                                ) {

                                    duplicados++;
                                    ignorados++;

                                    return;

                                }


                                // ==========================
                                // DATABASE
                                // ==========================

                                const resultado =
                                    cadastrarLote(

                                        novoLote,

                                        {
                                            silencioso:
                                                true
                                        }

                                    );


                                if (
                                    !resultado ||
                                    !resultado.ok
                                ) {

                                    invalidos++;
                                    ignorados++;

                                    return;

                                }


                                // ==========================
                                // SUCESSO
                                // ==========================

                                importados++;


                                if (chave) {

                                    chavesExistentes.add(
                                        chave
                                    );

                                }


                                if (
                                    metodoPeso ===
                                    "comercial"
                                ) {

                                    comerciais++;

                                } else {

                                    estimados++;

                                }

                            }
                        );


                        // ==================================
                        // NOTIFICAR UMA VEZ
                        // ==================================

                        if (
                            importados > 0 &&
                            typeof notificarMudanca ===
                                "function"
                        ) {

                            notificarMudanca(

                                "estoque",

                                {
                                    origem:
                                        "importacao",

                                    quantidade:
                                        importados
                                }

                            );

                        }


                        // ==================================
                        // RESULTADO
                        // ==================================

                        let mensagem =

                            "Importação concluída!\n\n" +

                            "✅ Importados: " +
                            importados +

                            "\n📦 Estimados: " +
                            estimados +

                            "\n🌱 Comerciais: " +
                            comerciais;


                        if (
                            duplicados > 0
                        ) {

                            mensagem +=

                                "\n\n🔁 Duplicados ignorados: " +
                                duplicados;

                        }


                        if (
                            invalidos > 0
                        ) {

                            mensagem +=

                                "\n⚠️ Linhas inválidas: " +
                                invalidos;

                        }


                        if (
                            ignorados > 0
                        ) {

                            mensagem +=

                                "\nTotal ignorado: " +
                                ignorados;

                        }


                        alert(
                            mensagem
                        );


                        window.location.href =
                            "estoque.html";


                    } catch (erro) {

                        console.error(
                            "Erro na importação:",
                            erro
                        );


                        alert(
                            "Erro ao importar planilha."
                        );

                    }

                };


            leitor.onerror =
                function () {

                    alert(
                        "Não foi possível ler a planilha."
                    );

                };


            leitor.readAsArrayBuffer(
                arquivo
            );

        }
    );

}