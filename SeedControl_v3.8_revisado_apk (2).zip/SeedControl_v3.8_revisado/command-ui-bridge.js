// ==========================================
// SeedControl v3.8
// command-ui-bridge.js
// ==========================================

(function () {

    "use strict";


    // ======================================
    // IA PRECISA EXISTIR
    // ======================================

    if (
        !window.SeedControlIA ||
        typeof window.SeedControlIA.processarMensagem !==
        "function"
    ) {

        console.error(
            "[SeedControl Command UI] IA Service não encontrado."
        );

        return;

    }


    const processamentoOriginal =
        window.SeedControlIA
            .processarMensagem
            .bind(
                window.SeedControlIA
            );


    // ======================================
    // RESPOSTA DE TEXTO
    // ======================================

    function criarRespostaTexto(
        retorno,
        mensagem
    ) {

        return {

            ok: true,

            origem:
                retorno &&
                retorno.origem
                    ? retorno.origem
                    : "local",

            tipoResultado:
                "texto",

            resultado:
                String(
                    mensagem ?? ""
                )

        };

    }


    // ======================================
    // FORMATAR
    // ======================================

    function formatarNumero(
        valor,
        casas = 2
    ) {

        const numero =
            Number(valor);


        if (!Number.isFinite(numero)) {

            return "0";

        }


        return numero.toLocaleString(
            "pt-BR",
            {

                minimumFractionDigits: 0,

                maximumFractionDigits:
                    casas

            }
        );

    }


    function nomeCampo(campo) {

        const nomes = {

            pms: "PMS",

            umidade: "Umidade",

            temperatura: "Temperatura",

            fazenda: "Fazenda",

            talhao: "Talhão",

            peneira: "Peneira",

            secagem: "Secagem",

            pesoBagKg: "Peso por Bag"

        };


        return nomes[campo] ||
            campo ||
            "-";

    }


    function formatarValor(
        campo,
        valor
    ) {

        if (campo === "pms") {

            return (
                formatarNumero(valor) +
                " g"
            );

        }


        if (campo === "umidade") {

            return (
                formatarNumero(valor) +
                "%"
            );

        }


        if (campo === "temperatura") {

            return (
                formatarNumero(valor) +
                " °C"
            );

        }


        if (campo === "secagem") {

            return (
                valor === true ||
                valor === "secou"

                    ? "Secou"

                    : "Não precisou secar"
            );

        }


        if (campo === "pesoBagKg") {

            return (
                formatarNumero(valor) +
                " kg/Bag"
            );

        }


        return (
            String(valor ?? "").trim() ||
            "-"
        );

    }


    // ======================================
    // CONFIRMAR
    // ======================================

    function confirmar(preparado) {

        if (!preparado) {
            return false;
        }


        if (
            preparado.requerConfirmacao !==
            true
        ) {

            return true;

        }


        const dados =
            preparado.confirmacao ||
            {};


        return window.confirm(

            (
                dados.titulo ||
                "CONFIRMAR OPERAÇÃO"
            ) +

            "\n\n" +

            (
                dados.mensagem ||
                "Deseja realizar esta operação?"
            ) +

            "\n\nDeseja confirmar?"

        );

    }


    // ======================================
    // FORMATAR MOVIMENTAÇÃO
    // ======================================

    function respostaMovimentacao(
        resultado
    ) {

        const lote =
            resultado.lote ||
            {};


        const entrada =
            resultado.tipo ===
            "entrada";


        return (

            "✅ " +
            (
                entrada
                    ? "Entrada realizada."
                    : "Saída realizada."
            ) +

            "\n\n🌱 Cultivar: " +
            (
                lote.cultivar ||
                "-"
            ) +

            "\n📋 Lote: " +
            (
                lote.lote ||
                "-"
            ) +

            "\n" +
            (
                entrada
                    ? "➕ Entrada: "
                    : "➖ Saída: "
            ) +

            formatarNumero(
                resultado.quantidade
            ) +
            " Bags" +

            "\n📦 Estoque atual: " +
            formatarNumero(
                lote.bags
            ) +
            " Bags" +

            (
                lote.pesoBagKg !== undefined
                    ? (
                        "\n⚖️ Peso por Bag: " +
                        formatarNumero(lote.pesoBagKg) +
                        " kg"
                    )
                    : ""
            ) +

            (
                lote.kgsMedia !==
                undefined

                    ? (
                        "\n⚖️ Kg (Média): " +
                        formatarNumero(
                            lote.kgsMedia
                        ) +
                        " kg"
                    )

                    : ""
            ) +

            (
                lote.sacas60kg !==
                undefined

                    ? (
                        "\n🌾 Sacas (60 kg): " +
                        formatarNumero(
                            lote.sacas60kg
                        )
                    )

                    : ""
            )

        );

    }


    // ======================================
    // FORMATAR ATUALIZAÇÃO
    // ======================================

    function respostaAtualizacao(
        resultado,
        preparado
    ) {

        const lote =
            resultado.lote ||
            {};


        const alteracao =
            preparado.alteracao ||
            {};


        const campo =
            resultado.campo ||
            alteracao.campo;


        return (

            "✅ Alteração realizada.\n\n" +

            "🌱 Cultivar: " +
            (
                lote.cultivar ||
                "-"
            ) +

            "\n📋 Lote: " +
            (
                lote.lote ||
                "-"
            ) +

            "\n⚙️ Campo: " +
            nomeCampo(campo) +

            "\n⬅️ Antes: " +
            formatarValor(
                campo,
                alteracao.valorAtual
            ) +

            "\n➡️ Agora: " +
            formatarValor(

                campo,

                lote[campo] !== undefined

                    ? lote[campo]

                    : resultado.valor

            )

        );

    }


    // ======================================
    // FORMATAR CADASTRO
    // ======================================

    function respostaCadastro(
        resultado
    ) {

        const dados =
            resultado.dados ||
            {};


        let mensagem =

            "✅ Novo lote cadastrado.\n\n" +

            "🌱 Cultivar: " +
            (
                dados.cultivar ||
                "-"
            ) +

            "\n📋 Lote: " +
            (
                dados.lote ||
                "-"
            ) +

            "\n📦 Bags: " +
            formatarNumero(
                dados.bags
            ) +

            "\n🚜 Fazenda: " +
            (
                dados.fazenda ||
                "-"
            ) +

            "\n🌾 Peneira: " +
            (
                dados.peneira ||
                "-"
            );


        if (
            typeof calcularPesoESacasLote ===
            "function"
        ) {

            try {

                const calculo =
                    calcularPesoESacasLote(

                        dados.bags,

                        dados.pms,

                        dados.metodoPeso,

                        dados.pesoBagKg

                    );


                if (calculo) {

                    mensagem +=

                        "\n⚖️ Peso por Bag: " +
                        formatarNumero(
                            calculo.pesoBagKg
                        ) +
                        " kg" +

                        "\n⚖️ Kg (Média): " +
                        formatarNumero(
                            calculo.kgsMedia
                        ) +
                        " kg" +

                        "\n🌾 Sacas (60 kg): " +
                        formatarNumero(
                            calculo.sacas60kg
                        );

                }

            } catch (erro) {

                console.warn(
                    "[SeedControl Command UI] Erro no cálculo:",
                    erro
                );

            }

        }


        return mensagem;

    }


    // ======================================
    // RESULTADO
    // ======================================

    function formatarResultado(
        resultado,
        preparado
    ) {

        if (!resultado) {

            return (
                "❌ A operação não retornou resultado."
            );

        }


        if (!resultado.ok) {

            return (

                "❌ Operação não realizada.\n\n" +

                (
                    resultado.mensagem ||
                    "Ocorreu um erro."
                )

            );

        }


        switch (resultado.acao) {

            case "movimentar_lote":

                return respostaMovimentacao(
                    resultado
                );


            case "atualizar_lote":

                return respostaAtualizacao(
                    resultado,
                    preparado
                );


            case "cadastrar_lote":

                return respostaCadastro(
                    resultado
                );


            default:

                return (
                    "✅ Operação realizada."
                );

        }

    }


    // ======================================
    // PROCESSAR COMANDO
    // ======================================

    function processarComando(retorno) {

        const pacote =
            retorno.resultado;


        if (!pacote) {

            return criarRespostaTexto(

                retorno,

                "❌ Não foi possível preparar o comando."

            );

        }


        if (
            pacote.ok === false
        ) {

            return criarRespostaTexto(

                retorno,

                "❌ " +
                (
                    pacote.mensagem ||
                    "Comando inválido."
                )

            );

        }


        const preparado =
            pacote.preparado;


        const intencao =
            pacote.intencao;


        if (
            !preparado ||
            !intencao
        ) {

            return criarRespostaTexto(

                retorno,

                "❌ Não foi possível preparar a operação."

            );

        }


        if (!confirmar(preparado)) {

            return criarRespostaTexto(

                retorno,

                "Operação cancelada.\n\nNenhum dado foi alterado."

            );

        }


        const resultado =
            window.SeedControlIA
                .executarIntencao(

                    intencao,

                    {
                        confirmado: true
                    }

                );


        return criarRespostaTexto(

            retorno,

            formatarResultado(
                resultado,
                preparado
            )

        );

    }


    // ======================================
    // INTERCEPTAR IA
    // ======================================

    window.SeedControlIA.processarMensagem =
        async function (
            mensagem,
            opcoes = {}
        ) {

            const retorno =
                await processamentoOriginal(
                    mensagem,
                    opcoes
                );


            if (
                !retorno ||
                retorno.tipoResultado !==
                "comando"
            ) {

                return retorno;

            }


            return processarComando(
                retorno
            );

        };


    // ======================================
    // API
    // ======================================

    window.SeedControlCommandUI = {

        ativo: true,

        versao: "1.1",

        confirmar:
            confirmar,

        formatarResultado:
            formatarResultado

    };


    try {

        window.dispatchEvent(

            new CustomEvent(
                "seedcontrol:command-ui-pronto",
                {

                    detail: {

                        ativo: true,

                        versao: "1.1"

                    }

                }
            )

        );

    } catch (erro) {

        console.warn(
            "[SeedControl Command UI] Evento não enviado:",
            erro
        );

    }


    console.log(
        "[SeedControl] Command UI Bridge carregado."
    );


})();