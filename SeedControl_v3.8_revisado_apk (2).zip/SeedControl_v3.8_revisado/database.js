// ======================================
// SeedControl Database v3.8
// ======================================


// ======================================
// CONSTANTES DE CÁLCULO
// ======================================

// Peso padrão para lotes antigos
// e novos lotes estimados.
const PESO_ESTIMADO_BAG_KG = 1050;

// Processo comercial
const SEMENTES_POR_BAG_COMERCIAL = 5000000;


// ======================================
// PESO PADRÃO DO BAG
// ======================================

function obterPesoEstimadoPadraoBagKg() {

    return PESO_ESTIMADO_BAG_KG;

}


// ======================================
// EVENTOS
// ======================================

function notificarMudanca(tipo, detalhe = {}) {

    try {

        if (
            typeof window !== "undefined" &&
            typeof window.dispatchEvent === "function"
        ) {

            window.dispatchEvent(
                new CustomEvent(
                    "seedcontrol:atualizado",
                    {
                        detail: {
                            tipo: tipo,
                            ...detalhe
                        }
                    }
                )
            );

        }

    } catch (erro) {

        console.error(
            "Erro ao notificar atualização:",
            erro
        );

    }

}


// ======================================
// TEXTO
// ======================================

function normalizarTexto(valor) {

    return String(valor || "")
        .trim()
        .toLowerCase();

}


// ======================================
// MÉTODO DE CÁLCULO DO PESO
// ======================================

function normalizarMetodoPeso(valor) {

    const metodo =
        normalizarTexto(valor);


    if (
        metodo === "comercial" ||
        metodo === "pms"
    ) {

        return "comercial";

    }


    // Compatibilidade com lotes antigos.
    return "estimado";

}


// ======================================
// NORMALIZAR PESO ESTIMADO DO BAG
// ======================================

function normalizarPesoBagEstimado(
    valor
) {

    const peso =
        Number(valor);


    if (
        Number.isFinite(peso) &&
        peso > 0
    ) {

        return peso;

    }


    return PESO_ESTIMADO_BAG_KG;

}


// ======================================
// CÁLCULO DO PESO DE UM BAG
// ======================================

function calcularPesoBagKg(
    metodoPeso,
    pms,
    pesoBagEstimado
) {

    const metodo =
        normalizarMetodoPeso(
            metodoPeso
        );


    // ==================================
    // MODO COMERCIAL
    // ==================================
    //
    // PMS = peso de 1.000 sementes
    //
    // Para 5 milhões de sementes:
    //
    // Peso do Bag = PMS × 5
    // ==================================

    if (metodo === "comercial") {

        const valorPMS =
            Number(pms) || 0;


        if (valorPMS <= 0) {

            return 0;

        }


        return (

            valorPMS *
            SEMENTES_POR_BAG_COMERCIAL

        ) / 1000000;

    }


    // ==================================
    // MODO ESTIMADO
    //
    // Agora o peso é individual
    // para cada lote.
    //
    // Se não existir, usa 1.050 kg.
    // ==================================

    return normalizarPesoBagEstimado(
        pesoBagEstimado
    );

}


// ======================================
// CÁLCULO COMPLETO DO LOTE
// ======================================

function calcularPesoESacasLote(
    bags,
    pms,
    metodoPeso,
    pesoBagEstimado
) {

    const quantidadeBags =
        Number(bags) || 0;


    const metodo =
        normalizarMetodoPeso(
            metodoPeso
        );


    const pesoBagKg =
        calcularPesoBagKg(

            metodo,

            pms,

            pesoBagEstimado

        );


    const kgsMedia =
        quantidadeBags *
        pesoBagKg;


    const sacas60kg =
        kgsMedia / 60;


    return {

        metodoPeso:
            metodo,

        bags:
            quantidadeBags,

        pesoBagKg:
            pesoBagKg,

        kgsMedia:
            kgsMedia,

        sacas60kg:
            sacas60kg

    };

}


// ======================================
// APLICAR CÁLCULOS AO LOTE
// ======================================

function aplicarCalculosLote(lote) {

    if (
        !lote ||
        typeof lote !== "object"
    ) {

        return lote;

    }


    const calculos =
        calcularPesoESacasLote(

            lote.bags,

            lote.pms,

            lote.metodoPeso,

            lote.pesoBagKg

        );


    return {

        ...lote,

        metodoPeso:
            calculos.metodoPeso,

        bags:
            calculos.bags,

        pesoBagKg:
            calculos.pesoBagKg,

        kgsMedia:
            calculos.kgsMedia,

        sacas60kg:
            calculos.sacas60kg

    };

}


// ======================================
// ESTOQUE
// ======================================

function carregarEstoque() {

    const dados =
        localStorage.getItem(
            "estoque"
        );


    if (!dados) {

        return [];

    }


    try {

        const estoque =
            JSON.parse(dados);


        if (
            !Array.isArray(
                estoque
            )
        ) {

            return [];

        }


        // Lotes antigos que não possuem
        // pesoBagKg recebem automaticamente
        // o padrão de 1.050 kg.
        return estoque.map(
            aplicarCalculosLote
        );


    } catch (erro) {

        console.error(
            "Erro ao carregar estoque:",
            erro
        );


        return [];

    }

}


function salvarEstoque(
    estoque,
    opcoes = {}
) {

    const base =
        Array.isArray(estoque)
            ? estoque
            : [];


    const estoqueCalculado =
        base.map(
            aplicarCalculosLote
        );


    localStorage.setItem(

        "estoque",

        JSON.stringify(
            estoqueCalculado
        )

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "estoque"
        );

    }

}


function obterLotePorId(id) {

    const estoque =
        carregarEstoque();


    return estoque.find(

        item =>
            Number(item.id) ===
            Number(id)

    ) || null;

}


// ======================================
// HISTÓRICO
// ======================================

function carregarHistorico() {

    const dados =
        localStorage.getItem(
            "historico"
        );


    if (!dados) {

        return [];

    }


    try {

        const historico =
            JSON.parse(dados);


        return Array.isArray(
            historico
        )
            ? historico
            : [];


    } catch (erro) {

        console.error(
            "Erro ao carregar histórico:",
            erro
        );


        return [];

    }

}


function salvarHistorico(
    historico,
    opcoes = {}
) {

    localStorage.setItem(

        "historico",

        JSON.stringify(

            Array.isArray(historico)
                ? historico
                : []

        )

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "historico"
        );

    }

}


// ======================================
// CONFIGURAÇÕES
// ======================================

function carregarConfiguracoes() {

    const dados =
        localStorage.getItem(
            "configuracoes"
        );


    if (!dados) {

        return {};

    }


    try {

        const configuracoes =
            JSON.parse(dados);


        return (
            configuracoes &&
            typeof configuracoes === "object"
        )
            ? configuracoes
            : {};


    } catch (erro) {

        console.error(
            "Erro ao carregar configurações:",
            erro
        );


        return {};

    }

}


function salvarConfiguracoes(
    config,
    opcoes = {}
) {

    localStorage.setItem(

        "configuracoes",

        JSON.stringify(

            config &&
            typeof config === "object"
                ? config
                : {}

        )

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "configuracoes"
        );

    }

}


// ======================================
// LIMITES DE ESTOQUE
// ======================================

function normalizarLimitesEstoque(
    limites
) {

    const padrao = {

        limiteBaixo: 30,

        limiteCritico: 10

    };


    const base = {

        limiteBaixo:
            padrao.limiteBaixo,

        limiteCritico:
            padrao.limiteCritico

    };


    if (
        limites &&
        typeof limites === "object"
    ) {

        const baixo =
            Number(
                limites.limiteBaixo
            );


        const critico =
            Number(
                limites.limiteCritico
            );


        if (
            Number.isFinite(baixo) &&
            baixo > 0
        ) {

            base.limiteBaixo =
                Math.floor(
                    baixo
                );

        }


        if (
            Number.isFinite(critico) &&
            critico >= 0
        ) {

            base.limiteCritico =
                Math.floor(
                    critico
                );

        }

    }


    if (
        base.limiteCritico >=
        base.limiteBaixo
    ) {

        base.limiteCritico =
            Math.max(
                0,
                base.limiteBaixo - 1
            );

    }


    return base;

}


function obterLimitesEstoque() {

    const configuracoes =
        carregarConfiguracoes();


    return normalizarLimitesEstoque(

        configuracoes.limitesEstoque ||

        configuracoes.estoqueInteligente ||

        configuracoes.limites ||

        configuracoes.limitesEstoqueInteligente

    );

}


function salvarLimitesEstoque(
    novosLimites,
    opcoes = {}
) {

    const configuracoes =
        carregarConfiguracoes();


    const limites =
        normalizarLimitesEstoque(
            novosLimites
        );


    configuracoes.limitesEstoque =
        limites;


    salvarConfiguracoes(

        configuracoes,

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(

            "configuracoes",

            {

                secao:
                    "estoque",

                limites:
                    limites

            }

        );

    }


    return {

        ok: true,

        sucesso: true,

        mensagem:
            "Limites de estoque salvos com sucesso.",

        limites:
            limites

    };

}


// ======================================
// STATUS DO ESTOQUE
// ======================================

function obterStatusEstoque(
    valorOuLote,
    limites = obterLimitesEstoque()
) {

    const quantidade =

        typeof valorOuLote === "object" &&
        valorOuLote !== null

            ? Number(
                valorOuLote.bags
            ) || 0

            : Number(
                valorOuLote
            ) || 0;


    const limitesNormalizados =
        normalizarLimitesEstoque(
            limites
        );


    if (
        quantidade <=
        limitesNormalizados.limiteCritico
    ) {

        return {

            nivel:
                "Crítico",

            chave:
                "critico",

            cor:
                "#ef4444",

            classe:
                "estoque-critico",

            texto:
                "🔴 Estoque Crítico",

            quantidade:
                quantidade,

            limiteBaixo:
                limitesNormalizados.limiteBaixo,

            limiteCritico:
                limitesNormalizados.limiteCritico

        };

    }


    if (
        quantidade <=
        limitesNormalizados.limiteBaixo
    ) {

        return {

            nivel:
                "Baixo",

            chave:
                "baixo",

            cor:
                "#facc15",

            classe:
                "estoque-baixo",

            texto:
                "🟡 Estoque Baixo",

            quantidade:
                quantidade,

            limiteBaixo:
                limitesNormalizados.limiteBaixo,

            limiteCritico:
                limitesNormalizados.limiteCritico

        };

    }


    return {

        nivel:
            "Normal",

        chave:
            "normal",

        cor:
            "#22c55e",

        classe:
            "estoque-normal",

        texto:
            "🟢 Estoque Normal",

        quantidade:
            quantidade,

        limiteBaixo:
            limitesNormalizados.limiteBaixo,

        limiteCritico:
            limitesNormalizados.limiteCritico

    };

}


// ======================================
// RESUMO INTELIGENTE
// ======================================

function obterResumoEstoqueInteligente(
    estoque
) {

    const base =
        Array.isArray(estoque)
            ? estoque
            : [];


    const limites =
        obterLimitesEstoque();


    let totalBags = 0;

    let totalKgsMedia = 0;

    let totalSacas60kg = 0;

    let totalRegistros = 0;


    const cultivares =
        new Set();

    const lotes =
        new Set();

    const fazendas =
        new Set();


    let normal = 0;

    let baixo = 0;

    let critico = 0;


    base.forEach(item => {

        if (
            !item ||
            !item.cultivar
        ) {

            return;

        }


        totalRegistros++;


        const loteCalculado =
            aplicarCalculosLote(
                item
            );


        totalBags +=
            Number(
                loteCalculado.bags
            ) || 0;


        totalKgsMedia +=
            Number(
                loteCalculado.kgsMedia
            ) || 0;


        totalSacas60kg +=
            Number(
                loteCalculado.sacas60kg
            ) || 0;


        const cultivar =
            String(
                item.cultivar
            ).trim();


        const lote =
            String(
                item.lote ?? ""
            ).trim();


        const fazenda =
            String(
                item.fazenda ?? ""
            ).trim();


        if (cultivar) {

            cultivares.add(
                cultivar
            );

        }


        if (lote) {

            lotes.add(
                lote
            );

        }


        if (fazenda) {

            fazendas.add(
                fazenda
            );

        }


        const status =
            obterStatusEstoque(
                item,
                limites
            );


        if (
            status.chave ===
            "critico"
        ) {

            critico++;

        } else if (
            status.chave ===
            "baixo"
        ) {

            baixo++;

        } else {

            normal++;

        }

    });


    return {

        totalBags:
            totalBags,

        totalKgsMedia:
            totalKgsMedia,

        totalSacas60kg:
            totalSacas60kg,

        totalRegistros:
            totalRegistros,

        totalCultivares:
            cultivares.size,

        totalLotes:
            lotes.size,

        totalFazendas:
            fazendas.size,

        normal:
            normal,

        baixo:
            baixo,

        critico:
            critico,

        limites:
            limites

    };

}


// ======================================
// RESUMO GERAL
// ======================================

function resumirEstoque(
    estoque
) {

    const base =
        Array.isArray(estoque)
            ? estoque
            : [];


    let totalBags = 0;

    let totalKgsMedia = 0;

    let totalSacas60kg = 0;

    let somaUmidade = 0;

    let somaTemperatura = 0;

    let somaPMS = 0;

    let totalRegistros = 0;


    const cultivares =
        new Set();

    const lotes =
        new Set();

    const fazendas =
        new Set();

    const bagsPorCultivar =
        {};


    base.forEach(item => {

        if (
            !item ||
            !item.cultivar
        ) {

            return;

        }


        totalRegistros++;


        const loteCalculado =
            aplicarCalculosLote(
                item
            );


        const bags =
            Number(
                loteCalculado.bags
            ) || 0;


        totalBags +=
            bags;


        totalKgsMedia +=
            Number(
                loteCalculado.kgsMedia
            ) || 0;


        totalSacas60kg +=
            Number(
                loteCalculado.sacas60kg
            ) || 0;


        somaUmidade +=
            Number(
                item.umidade
            ) || 0;


        somaTemperatura +=
            Number(
                item.temperatura
            ) || 0;


        somaPMS +=
            Number(
                item.pms
            ) || 0;


        const cultivar =
            String(
                item.cultivar
            ).trim();


        const lote =
            String(
                item.lote ?? ""
            ).trim();


        const fazenda =
            String(
                item.fazenda ?? ""
            ).trim();


        if (cultivar) {

            cultivares.add(
                cultivar
            );

        }


        if (lote) {

            lotes.add(
                lote
            );

        }


        if (fazenda) {

            fazendas.add(
                fazenda
            );

        }


        if (
            !bagsPorCultivar[
                cultivar
            ]
        ) {

            bagsPorCultivar[
                cultivar
            ] = 0;

        }


        bagsPorCultivar[
            cultivar
        ] += bags;

    });


    return {

        totalBags:
            totalBags,

        totalKgsMedia:
            totalKgsMedia,

        totalSacas60kg:
            totalSacas60kg,

        totalRegistros:
            totalRegistros,

        totalCultivares:
            cultivares.size,

        totalLotesDistintos:
            lotes.size,

        totalFazendas:
            fazendas.size,

        mediaUmidade:

            totalRegistros

                ? (
                    somaUmidade /
                    totalRegistros
                )

                : 0,

        mediaTemperatura:

            totalRegistros

                ? (
                    somaTemperatura /
                    totalRegistros
                )

                : 0,

        mediaPMS:

            totalRegistros

                ? (
                    somaPMS /
                    totalRegistros
                )

                : 0,

        bagsPorCultivar:
            bagsPorCultivar

    };

}


// ======================================
// VALIDAÇÃO
// ======================================

function validarLoteObrigatorio(
    novoLote
) {

    if (

        !novoLote ||

        !String(
            novoLote.cultivar || ""
        ).trim() ||

        !String(
            novoLote.peneira || ""
        ).trim() ||

        !String(
            novoLote.fazenda || ""
        ).trim() ||

        Number(
            novoLote.lote
        ) <= 0 ||

        Number(
            novoLote.bags
        ) <= 0

    ) {

        return false;

    }


    const metodo =
        normalizarMetodoPeso(
            novoLote.metodoPeso
        );


    if (
        metodo === "comercial" &&
        Number(novoLote.pms) <= 0
    ) {

        return false;

    }


    // Se o peso estimado foi informado
    // explicitamente, ele precisa ser válido.
    if (
        metodo === "estimado" &&
        novoLote.pesoBagKg !== undefined &&
        novoLote.pesoBagKg !== null &&
        novoLote.pesoBagKg !== "" &&
        Number(novoLote.pesoBagKg) <= 0
    ) {

        return false;

    }


    return true;

}


// ======================================
// MENSAGEM DE VALIDAÇÃO
// ======================================

function obterMensagemValidacaoLote(
    novoLote
) {

    const metodo =
        normalizarMetodoPeso(
            novoLote &&
            novoLote.metodoPeso
        );


    if (
        metodo === "comercial" &&
        Number(
            novoLote &&
            novoLote.pms
        ) <= 0
    ) {

        return (
            "No modo comercial, informe também um PMS válido."
        );

    }


    if (
        metodo === "estimado" &&
        novoLote &&
        novoLote.pesoBagKg !== undefined &&
        novoLote.pesoBagKg !== null &&
        novoLote.pesoBagKg !== "" &&
        Number(
            novoLote.pesoBagKg
        ) <= 0
    ) {

        return (
            "Informe um peso válido para o Bag."
        );

    }


    return (
        "Preencha todos os campos obrigatórios."
    );

}


// ======================================
// SECAGEM
// ======================================

function normalizarSecagem(valor) {

    if (valor === true) {

        return "secou";

    }


    if (valor === false) {

        return "nao_precisou";

    }


    if (
        valor ===
        "nao_precisou"
    ) {

        return "nao_precisou";

    }


    return "secou";

}


// ======================================
// CADASTRAR LOTE
// ======================================

function cadastrarLote(
    novoLote,
    opcoes = {}
) {

    if (
        !validarLoteObrigatorio(
            novoLote
        )
    ) {

        return {

            ok: false,

            mensagem:
                obterMensagemValidacaoLote(
                    novoLote
                )

        };

    }


    const estoque =
        carregarEstoque();


    const metodo =
        normalizarMetodoPeso(
            novoLote.metodoPeso
        );


    const loteBase = {

        id:
            novoLote.id ||
            Date.now(),

        cultivar:
            String(
                novoLote.cultivar
            ).trim(),

        peneira:
            String(
                novoLote.peneira
            ).trim(),

        lote:
            Number(
                novoLote.lote
            ),

        bags:
            Number(
                novoLote.bags
            ),

        umidade:
            Number(
                novoLote.umidade
            ) || 0,

        temperatura:
            Number(
                novoLote.temperatura
            ) || 0,

        pms:
            Number(
                novoLote.pms
            ) || 0,

        fazenda:
            String(
                novoLote.fazenda
            ).trim(),

        talhao:
            String(
                novoLote.talhao ||
                ""
            ).trim(),

        secagem:
            normalizarSecagem(
                novoLote.secagem
            ),

        metodoPeso:
            metodo,

        pesoBagKg:

            metodo === "estimado"

                ? normalizarPesoBagEstimado(
                    novoLote.pesoBagKg
                )

                : calcularPesoBagKg(
                    "comercial",
                    novoLote.pms
                )

    };


    const loteSalvo =
        aplicarCalculosLote(
            loteBase
        );


    estoque.push(
        loteSalvo
    );


    salvarEstoque(

        estoque,

        {
            silencioso: true
        }

    );


    const historico =
        carregarHistorico();


    historico.unshift({

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

        tipo:
            "cadastro",

        cultivar:
            loteSalvo.cultivar,

        lote:
            loteSalvo.lote,

        quantidade:
            loteSalvo.bags,

        observacao:
            "Novo lote cadastrado"

    });


    salvarHistorico(

        historico,

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "estoque"
        );

    }


    return {

        ok: true,

        mensagem:
            "Lote cadastrado com sucesso!",

        lote:
            loteSalvo

    };

}


// ======================================
// ATUALIZAR LOTE
// ======================================

function atualizarLote(
    idOriginal,
    novoLote,
    opcoes = {}
) {

    if (
        !validarLoteObrigatorio(
            novoLote
        )
    ) {

        return {

            ok: false,

            mensagem:
                obterMensagemValidacaoLote(
                    novoLote
                )

        };

    }


    const estoque =
        carregarEstoque();


    const indice =
        estoque.findIndex(

            item =>
                Number(item.id) ===
                Number(idOriginal)

        );


    if (indice < 0) {

        return {

            ok: false,

            mensagem:
                "Lote não encontrado."

        };

    }


    const metodo =
        normalizarMetodoPeso(
            novoLote.metodoPeso
        );


    const atualizadoBase = {

        ...estoque[indice],

        id:
            estoque[indice].id,

        cultivar:
            String(
                novoLote.cultivar
            ).trim(),

        peneira:
            String(
                novoLote.peneira
            ).trim(),

        lote:
            Number(
                novoLote.lote
            ),

        bags:
            Number(
                novoLote.bags
            ),

        umidade:
            Number(
                novoLote.umidade
            ) || 0,

        temperatura:
            Number(
                novoLote.temperatura
            ) || 0,

        pms:
            Number(
                novoLote.pms
            ) || 0,

        fazenda:
            String(
                novoLote.fazenda
            ).trim(),

        talhao:
            String(
                novoLote.talhao ||
                ""
            ).trim(),

        secagem:
            normalizarSecagem(
                novoLote.secagem
            ),

        metodoPeso:
            metodo,

        pesoBagKg:

            metodo === "estimado"

                ? normalizarPesoBagEstimado(
                    novoLote.pesoBagKg
                )

                : calcularPesoBagKg(
                    "comercial",
                    novoLote.pms
                )

    };


    const atualizado =
        aplicarCalculosLote(
            atualizadoBase
        );


    estoque[indice] =
        atualizado;


    salvarEstoque(

        estoque,

        {
            silencioso: true
        }

    );


    const historico =
        carregarHistorico();


    historico.unshift({

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

        tipo:
            "edicao",

        cultivar:
            atualizado.cultivar,

        lote:
            atualizado.lote,

        quantidade:
            atualizado.bags,

        observacao:
            "Dados do lote editados"

    });


    salvarHistorico(

        historico,

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "estoque"
        );

    }


    return {

        ok: true,

        mensagem:
            "Lote atualizado com sucesso!",

        lote:
            atualizado

    };

}


// ======================================
// EXCLUIR LOTE
// ======================================

function excluirLote(
    idOriginal,
    opcoes = {}
) {

    const estoque =
        carregarEstoque();


    const indice =
        estoque.findIndex(

            item =>
                Number(item.id) ===
                Number(idOriginal)

        );


    if (indice < 0) {

        return {

            ok: false,

            mensagem:
                "Lote não encontrado."

        };

    }


    const removido =
        estoque[indice];


    estoque.splice(
        indice,
        1
    );


    salvarEstoque(

        estoque,

        {
            silencioso: true
        }

    );


    const historico =
        carregarHistorico();


    historico.unshift({

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

        tipo:
            "exclusao",

        cultivar:
            removido.cultivar,

        lote:
            removido.lote,

        quantidade:
            Number(
                removido.bags
            ) || 0,

        observacao:
            "Lote excluído"

    });


    salvarHistorico(

        historico,

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "estoque"
        );

    }


    return {

        ok: true,

        mensagem:
            "Lote excluído com sucesso!"

    };

}


// ======================================
// MOVIMENTAÇÃO
// ======================================

function movimentarLote(
    registroOuId,
    tipo,
    quantidade,
    observacao,
    opcoes = {}
) {

    const estoque =
        carregarEstoque();


    const idBusca =

        typeof registroOuId === "object" &&
        registroOuId !== null

            ? registroOuId.id

            : registroOuId;


    const lote =
        estoque.find(

            item =>
                Number(item.id) ===
                Number(idBusca)

        );


    if (!lote) {

        return {

            ok: false,

            mensagem:
                "Lote não encontrado."

        };

    }


    if (
        isNaN(quantidade) ||
        Number(quantidade) <= 0
    ) {

        return {

            ok: false,

            mensagem:
                "Informe uma quantidade válida."

        };

    }


    const qtd =
        Number(
            quantidade
        );


    if (
        tipo ===
        "entrada"
    ) {

        lote.bags =
            Number(
                lote.bags
            ) + qtd;

    } else {

        if (
            qtd >
            (
                Number(
                    lote.bags
                ) || 0
            )
        ) {

            return {

                ok: false,

                mensagem:
                    "Estoque insuficiente."

            };

        }


        lote.bags =
            Number(
                lote.bags
            ) - qtd;

    }


    // O pesoBagKg fica no lote.
    // Portanto entrada/saída recalcula
    // usando o mesmo peso configurado.
    salvarEstoque(

        estoque,

        {
            silencioso: true
        }

    );


    const historico =
        carregarHistorico();


    historico.unshift({

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

        tipo:
            tipo,

        cultivar:
            lote.cultivar,

        lote:
            lote.lote,

        quantidade:
            qtd,

        observacao:
            String(
                observacao || ""
            ).trim()

    });


    salvarHistorico(

        historico,

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "estoque"
        );

    }


    const loteAtualizado =
        obterLotePorId(
            lote.id
        );


    return {

        ok: true,

        mensagem:
            "Movimentação registrada com sucesso!",

        lote:
            loteAtualizado

    };

}


// ======================================
// BACKUP
// ======================================

function gerarBackup() {

    return {

        versao:
            "1.0",

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

        estoque:
            carregarEstoque(),

        historico:
            carregarHistorico(),

        configuracoes:
            carregarConfiguracoes()

    };

}


function restaurarBackup(
    backup,
    opcoes = {}
) {

    if (
        !backup ||
        !Array.isArray(
            backup.estoque
        ) ||
        !Array.isArray(
            backup.historico
        )
    ) {

        return {

            ok: false,

            mensagem:
                "Arquivo de backup inválido."

        };

    }


    salvarEstoque(

        backup.estoque,

        {
            silencioso: true
        }

    );


    salvarHistorico(

        backup.historico,

        {
            silencioso: true
        }

    );


    salvarConfiguracoes(

        backup.configuracoes &&
        typeof backup.configuracoes === "object"

            ? backup.configuracoes

            : {},

        {
            silencioso: true
        }

    );


    if (!opcoes.silencioso) {

        notificarMudanca(
            "backup"
        );

    }


    return {

        ok: true,

        mensagem:
            "Backup restaurado com sucesso."

    };

}


// ======================================
// LIMPAR BANCO
// ======================================

function limparBanco(
    opcoes = {}
) {

    localStorage.clear();


    if (!opcoes.silencioso) {

        notificarMudanca(
            "limpeza"
        );

    }


    return {

        ok: true,

        mensagem:
            "Dados apagados com sucesso."

    };

}