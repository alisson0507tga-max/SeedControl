// ==========================================
// SeedControl v3.8
// diagnostico.js
//
// DIAGNÓSTICO DE DADOS
//
// NÃO ALTERA O ESTOQUE.
// NÃO EXCLUI DADOS.
// ==========================================


(function () {

    "use strict";


    // ======================================
    // ELEMENTOS
    // ======================================

    const tituloStatus =
        document.getElementById(
            "tituloStatusDiagnostico"
        );


    const textoStatus =
        document.getElementById(
            "textoStatusDiagnostico"
        );


    const diagRegistros =
        document.getElementById(
            "diagRegistros"
        );


    const diagBags =
        document.getElementById(
            "diagBags"
        );


    const diagErros =
        document.getElementById(
            "diagErros"
        );


    const diagAvisos =
        document.getElementById(
            "diagAvisos"
        );


    const listaDiagnostico =
        document.getElementById(
            "listaDiagnostico"
        );


    const btnExecutar =
        document.getElementById(
            "btnExecutarDiagnostico"
        );


    const btnBackup =
        document.getElementById(
            "btnBackupEmergencia"
        );


    // ======================================
    // FORMATAR NÚMERO
    // ======================================

    function formatarNumero(
        valor,
        casas = 2
    ) {

        const numero =
            Number(valor);


        if (
            !Number.isFinite(
                numero
            )
        ) {

            return "0";

        }


        return numero.toLocaleString(
            "pt-BR",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: casas
            }
        );

    }


    // ======================================
    // NORMALIZAR TEXTO
    // ======================================

    function normalizarTextoDiag(
        valor
    ) {

        return String(
            valor ?? ""
        )
            .normalize("NFD")
            .replace(
                /[\u0300-\u036f]/g,
                ""
            )
            .toLowerCase()
            .trim();

    }


    // ======================================
    // LER JSON COM SEGURANÇA
    // ======================================

    function lerJSONSeguro(
        chave,
        padrao
    ) {

        const bruto =
            localStorage.getItem(
                chave
            );


        if (
            bruto === null
        ) {

            return {
                ok: true,
                existe: false,
                bruto: null,
                valor: padrao
            };

        }


        try {

            return {
                ok: true,
                existe: true,
                bruto: bruto,
                valor: JSON.parse(
                    bruto
                )
            };


        } catch (erro) {

            return {
                ok: false,
                existe: true,
                bruto: bruto,
                valor: padrao,
                erro: erro
            };

        }

    }


    // ======================================
    // NORMALIZAR MÉTODO
    // ======================================

    function metodoPeso(
        valor
    ) {

        if (
            typeof normalizarMetodoPeso ===
            "function"
        ) {

            return normalizarMetodoPeso(
                valor
            );

        }


        const texto =
            normalizarTextoDiag(
                valor
            );


        if (
            texto === "comercial" ||
            texto === "pms"
        ) {

            return "comercial";

        }


        return "estimado";

    }


    // ======================================
    // NORMALIZAR SECAGEM
    // ======================================

    function secagem(
        valor
    ) {

        if (
            typeof normalizarSecagem ===
            "function"
        ) {

            return normalizarSecagem(
                valor
            );

        }


        if (
            valor === true ||
            valor === "secou"
        ) {

            return "secou";

        }


        if (
            valor === false ||
            valor === "nao_precisou"
        ) {

            return "nao_precisou";

        }


        return null;

    }


    // ======================================
    // PROBLEMA
    // ======================================

    function criarProblema(
        tipo,
        titulo,
        descricao,
        lote = null
    ) {

        return {
            tipo: tipo,
            titulo: titulo,
            descricao: descricao,
            lote: lote
        };

    }


    // ======================================
    // COMPARAR NÚMERO
    // ======================================

    function numerosProximos(
        a,
        b,
        tolerancia = 0.05
    ) {

        const numeroA =
            Number(a);


        const numeroB =
            Number(b);


        if (
            !Number.isFinite(
                numeroA
            ) ||
            !Number.isFinite(
                numeroB
            )
        ) {

            return false;

        }


        return (
            Math.abs(
                numeroA -
                numeroB
            ) <= tolerancia
        );

    }


    // ======================================
    // EXECUTAR DIAGNÓSTICO
    // ======================================

    function executarDiagnostico() {

        const problemas = [];

        let totalBags = 0;


        // ==================================
        // ESTOQUE BRUTO
        // ==================================

        const estoqueStorage =
            lerJSONSeguro(
                "estoque",
                []
            );


        if (
            !estoqueStorage.ok
        ) {

            problemas.push(

                criarProblema(

                    "erro",

                    "Estoque corrompido",

                    "O conteúdo salvo em “estoque” não é um JSON válido."

                )

            );

        }


        if (
            estoqueStorage.ok &&
            !Array.isArray(
                estoqueStorage.valor
            )
        ) {

            problemas.push(

                criarProblema(

                    "erro",

                    "Formato de estoque inválido",

                    "O estoque deveria ser uma lista de lotes."

                )

            );

        }


        const estoque =

            estoqueStorage.ok &&
            Array.isArray(
                estoqueStorage.valor
            )

                ? estoqueStorage.valor

                : [];


        // ==================================
        // HISTÓRICO
        // ==================================

        const historicoStorage =
            lerJSONSeguro(
                "historico",
                []
            );


        if (
            !historicoStorage.ok
        ) {

            problemas.push(

                criarProblema(

                    "erro",

                    "Histórico corrompido",

                    "O histórico salvo não é um JSON válido."

                )

            );

        } else if (
            !Array.isArray(
                historicoStorage.valor
            )
        ) {

            problemas.push(

                criarProblema(

                    "erro",

                    "Formato do histórico inválido",

                    "O histórico deveria ser uma lista."

                )

            );

        }


        // ==================================
        // CONFIGURAÇÕES
        // ==================================

        const configStorage =
            lerJSONSeguro(
                "configuracoes",
                {}
            );


        if (
            !configStorage.ok
        ) {

            problemas.push(

                criarProblema(

                    "aviso",

                    "Configurações inválidas",

                    "As configurações salvas não puderam ser lidas."

                )

            );

        }


        // ==================================
        // IDs
        // ==================================

        const ids =
            new Set();


        // ==================================
        // POSSÍVEIS DUPLICADOS
        // ==================================

        const chavesLotes =
            new Map();


        // ==================================
        // ANALISAR CADA LOTE
        // ==================================

        estoque.forEach(
            function (
                lote,
                indice
            ) {

                const numeroVisual =
                    lote &&
                    lote.lote !==
                    undefined

                        ? lote.lote

                        : (
                            "#" +
                            (
                                indice +
                                1
                            )
                        );


                // =============================
                // OBJETO
                // =============================

                if (
                    !lote ||
                    typeof lote !==
                    "object" ||
                    Array.isArray(
                        lote
                    )
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "Registro inválido",

                            "Existe um item do estoque que não é um lote válido.",

                            numeroVisual

                        )

                    );


                    return;

                }


                // =============================
                // ID
                // =============================

                if (
                    lote.id ===
                    undefined ||
                    lote.id ===
                    null ||
                    lote.id ===
                    ""
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "Lote sem ID",

                            "Este registro não possui identificador interno.",

                            numeroVisual

                        )

                    );

                } else {

                    const id =
                        String(
                            lote.id
                        );


                    if (
                        ids.has(
                            id
                        )
                    ) {

                        problemas.push(

                            criarProblema(

                                "erro",

                                "ID duplicado",

                                "Mais de um registro possui o ID " +
                                id +
                                ".",

                                numeroVisual

                            )

                        );

                    }


                    ids.add(
                        id
                    );

                }


                // =============================
                // CULTIVAR
                // =============================

                if (
                    !String(
                        lote.cultivar ??
                        ""
                    ).trim()
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "Cultivar ausente",

                            "O lote não possui cultivar informada.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // NÚMERO DO LOTE
                // =============================

                if (
                    lote.lote ===
                    undefined ||
                    lote.lote ===
                    null ||
                    String(
                        lote.lote
                    ).trim() ===
                    ""
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "Número do lote ausente",

                            "O registro está sem número de lote.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // PENEIRA
                // =============================

                if (
                    !String(
                        lote.peneira ??
                        ""
                    ).trim()
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "Peneira não informada",

                            "O lote está sem peneira.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // FAZENDA
                // =============================

                if (
                    !String(
                        lote.fazenda ??
                        ""
                    ).trim()
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "Fazenda não informada",

                            "O lote está sem Fazenda.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // BAGS
                // =============================

                const bags =
                    Number(
                        lote.bags
                    );


                if (
                    !Number.isFinite(
                        bags
                    )
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "Bags inválido",

                            "A quantidade de Bags não é um número válido.",

                            numeroVisual

                        )

                    );

                } else {

                    totalBags +=
                        bags;


                    if (
                        bags < 0
                    ) {

                        problemas.push(

                            criarProblema(

                                "erro",

                                "Estoque negativo",

                                "O lote possui " +
                                bags +
                                " Bags.",

                                numeroVisual

                            )

                        );

                    }

                }


                // =============================
                // UMIDADE
                // =============================

                if (
                    !Number.isFinite(
                        Number(
                            lote.umidade
                        )
                    )
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "Umidade inválida",

                            "A Umidade deste lote não é numérica.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // TEMPERATURA
                // =============================

                if (
                    !Number.isFinite(
                        Number(
                            lote.temperatura
                        )
                    )
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "Temperatura inválida",

                            "A Temperatura deste lote não é numérica.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // PMS
                // =============================

                const pms =
                    Number(
                        lote.pms
                    );


                if (
                    !Number.isFinite(
                        pms
                    ) ||
                    pms < 0
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "PMS inválido",

                            "O PMS deste lote precisa ser revisado.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // MÉTODO DE PESO
                // =============================

                const metodo =
                    metodoPeso(
                        lote.metodoPeso
                    );


                if (
                    metodo ===
                    "comercial" &&
                    (
                        !Number.isFinite(
                            pms
                        ) ||
                        pms <= 0
                    )
                ) {

                    problemas.push(

                        criarProblema(

                            "erro",

                            "PMS obrigatório",

                            "Este lote usa o método Comercial, mas não possui PMS válido.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // PESO POR BAG PERSONALIZADO
                // =============================

                const pesoBagFoiSalvo =
                    lote.pesoBagKg !==
                        undefined &&
                    lote.pesoBagKg !==
                        null &&
                    lote.pesoBagKg !==
                        "";


                if (
                    metodo ===
                    "estimado" &&
                    pesoBagFoiSalvo
                ) {

                    const pesoBag =
                        Number(
                            lote.pesoBagKg
                        );


                    if (
                        !Number.isFinite(
                            pesoBag
                        ) ||
                        pesoBag <= 0
                    ) {

                        problemas.push(

                            criarProblema(

                                "erro",

                                "Peso por Bag inválido",

                                "O peso informado para cada Bag precisa ser maior que zero.",

                                numeroVisual

                            )

                        );

                    }

                }


                // =============================
                // SECAGEM
                // =============================

                const valorSecagem =
                    secagem(
                        lote.secagem
                    );


                if (
                    !valorSecagem
                ) {

                    problemas.push(

                        criarProblema(

                            "aviso",

                            "Secagem não reconhecida",

                            "O valor de Secagem precisa ser conferido.",

                            numeroVisual

                        )

                    );

                }


                // =============================
                // PESO / SACAS
                // =============================

                if (
                    typeof calcularPesoESacasLote ===
                    "function" &&
                    Number.isFinite(
                        bags
                    )
                ) {

                    try {

                        // =================================
                        // IMPORTANTE
                        //
                        // Agora o peso personalizado
                        // do Bag também entra no cálculo.
                        //
                        // Lotes antigos sem pesoBagKg
                        // continuam usando 1.050 kg.
                        // =================================

                        const esperado =
                            calcularPesoESacasLote(

                                bags,

                                Number.isFinite(
                                    pms
                                )
                                    ? pms
                                    : 0,

                                metodo,

                                lote.pesoBagKg

                            );


                        if (
                            esperado
                        ) {

                            // =============================
                            // PESO DE UM BAG
                            // =============================

                            if (
                                pesoBagFoiSalvo &&
                                !numerosProximos(

                                    lote.pesoBagKg,

                                    esperado.pesoBagKg

                                )
                            ) {

                                problemas.push(

                                    criarProblema(

                                        "aviso",

                                        "Peso por Bag diferente do cálculo",

                                        "Salvo: " +
                                        formatarNumero(
                                            lote.pesoBagKg
                                        ) +
                                        " kg | Calculado: " +
                                        formatarNumero(
                                            esperado.pesoBagKg
                                        ) +
                                        " kg.",

                                        numeroVisual

                                    )

                                );

                            }


                            // =============================
                            // KG TOTAL
                            // =============================

                            if (
                                lote.kgsMedia !==
                                undefined &&
                                lote.kgsMedia !==
                                null &&
                                !numerosProximos(

                                    lote.kgsMedia,

                                    esperado.kgsMedia

                                )
                            ) {

                                problemas.push(

                                    criarProblema(

                                        "aviso",

                                        "Kg diferente do cálculo",

                                        "Salvo: " +
                                        formatarNumero(
                                            lote.kgsMedia
                                        ) +
                                        " kg | Calculado: " +
                                        formatarNumero(
                                            esperado.kgsMedia
                                        ) +
                                        " kg.",

                                        numeroVisual

                                    )

                                );

                            }


                            // =============================
                            // SACAS
                            // =============================

                            if (
                                lote.sacas60kg !==
                                undefined &&
                                lote.sacas60kg !==
                                null &&
                                !numerosProximos(

                                    lote.sacas60kg,

                                    esperado.sacas60kg

                                )
                            ) {

                                problemas.push(

                                    criarProblema(

                                        "aviso",

                                        "Sacas diferentes do cálculo",

                                        "Salvo: " +
                                        formatarNumero(
                                            lote.sacas60kg
                                        ) +
                                        " | Calculado: " +
                                        formatarNumero(
                                            esperado.sacas60kg
                                        ) +
                                        ".",

                                        numeroVisual

                                    )

                                );

                            }

                        }


                    } catch (
                        erro
                    ) {

                        problemas.push(

                            criarProblema(

                                "aviso",

                                "Falha ao conferir peso",

                                "Não foi possível conferir Kg/Sacas deste lote.",

                                numeroVisual

                            )

                        );

                    }

                }


                // =============================
                // POSSÍVEL DUPLICIDADE
                // =============================

                const chave =

                    normalizarTextoDiag(
                        lote.cultivar
                    ) +
                    "|" +

                    normalizarTextoDiag(
                        lote.lote
                    ) +
                    "|" +

                    normalizarTextoDiag(
                        lote.fazenda
                    );


                if (
                    chave !==
                    "||"
                ) {

                    if (
                        chavesLotes.has(
                            chave
                        )
                    ) {

                        problemas.push(

                            criarProblema(

                                "aviso",

                                "Possível lote duplicado",

                                "Existe outro registro com mesma Cultivar, Lote e Fazenda.",

                                numeroVisual

                            )

                        );

                    } else {

                        chavesLotes.set(
                            chave,
                            lote.id
                        );

                    }

                }

            }
        );


        // ==================================
        // CONTAGEM
        // ==================================

        const erros =
            problemas.filter(
                item =>
                    item.tipo ===
                    "erro"
            );


        const avisos =
            problemas.filter(
                item =>
                    item.tipo ===
                    "aviso"
            );


        atualizarTela(

            estoque.length,

            totalBags,

            erros,

            avisos,

            problemas

        );


        return {

            ok:
                erros.length === 0,

            registros:
                estoque.length,

            bags:
                totalBags,

            erros:
                erros,

            avisos:
                avisos,

            problemas:
                problemas

        };

    }


    // ======================================
    // ATUALIZAR TELA
    // ======================================

    function atualizarTela(
        registros,
        bags,
        erros,
        avisos,
        problemas
    ) {

        if (diagRegistros) {

            diagRegistros.textContent =
                registros;

        }


        if (diagBags) {

            diagBags.textContent =
                formatarNumero(
                    bags
                );

        }


        if (diagErros) {

            diagErros.textContent =
                erros.length;

        }


        if (diagAvisos) {

            diagAvisos.textContent =
                avisos.length;

        }


        // ==================================
        // STATUS
        // ==================================

        if (
            erros.length > 0
        ) {

            if (tituloStatus) {

                tituloStatus.textContent =
                    "🔴 Atenção necessária";

            }


            if (textoStatus) {

                textoStatus.textContent =

                    erros.length +
                    " erro(s) encontrado(s).";

            }


        } else if (
            avisos.length > 0
        ) {

            if (tituloStatus) {

                tituloStatus.textContent =
                    "🟡 Dados utilizáveis";

            }


            if (textoStatus) {

                textoStatus.textContent =

                    "Nenhum erro grave. " +
                    avisos.length +
                    " aviso(s) para conferir.";

            }


        } else {

            if (tituloStatus) {

                tituloStatus.textContent =
                    "🟢 Tudo certo";

            }


            if (textoStatus) {

                textoStatus.textContent =
                    "Nenhum problema foi encontrado.";

            }

        }


        // ==================================
        // LISTA
        // ==================================

        if (!listaDiagnostico) {

            return;

        }


        listaDiagnostico.innerHTML =
            "";


        if (
            problemas.length === 0
        ) {

            const item =
                document.createElement(
                    "div"
                );


            item.innerHTML =

                "<p><strong>✅ Nenhum problema encontrado.</strong></p>" +

                "<p>Estrutura principal dos dados está consistente.</p>";


            listaDiagnostico.appendChild(
                item
            );


            return;

        }


        problemas.forEach(
            problema => {

                const card =
                    document.createElement(
                        "div"
                    );


                card.className =
                    "card";


                const icone =
                    problema.tipo ===
                    "erro"

                        ? "❌"

                        : "⚠️";


                const loteTexto =
                    problema.lote !==
                    null

                        ? (
                            "<p><strong>📋 Lote:</strong> " +
                            problema.lote +
                            "</p>"
                        )

                        : "";


                card.innerHTML =

                    "<h3>" +
                    icone +
                    " " +
                    problema.titulo +
                    "</h3>" +

                    loteTexto +

                    "<p>" +
                    problema.descricao +
                    "</p>";


                listaDiagnostico.appendChild(
                    card
                );

            }
        );

    }


    // ======================================
    // BACKUP DE EMERGÊNCIA
    // ======================================

    function criarBackupEmergencia() {

        const estoque =
            lerJSONSeguro(
                "estoque",
                []
            );


        const historico =
            lerJSONSeguro(
                "historico",
                []
            );


        const configuracoes =
            lerJSONSeguro(
                "configuracoes",
                {}
            );


        return {

            seedControlBackup:
                true,

            tipo:
                "backup_emergencia",

            versao:
                "1.0",

            criadoEm:
                new Date()
                    .toISOString(),

            dados: {

                estoque:
                    estoque.ok
                        ? estoque.valor
                        : [],

                historico:
                    historico.ok
                        ? historico.valor
                        : [],

                configuracoes:
                    configuracoes.ok
                        ? configuracoes.valor
                        : {}

            },


            // ==================================
            // CÓPIA BRUTA
            // ==================================

            dadosBrutos: {

                estoque:
                    estoque.bruto,

                historico:
                    historico.bruto,

                configuracoes:
                    configuracoes.bruto

            }

        };

    }


    // ======================================
    // BAIXAR BACKUP
    // ======================================

    function baixarBackupEmergencia() {

        try {

            const backup =
                criarBackupEmergencia();


            const json =
                JSON.stringify(
                    backup,
                    null,
                    2
                );


            const blob =
                new Blob(
                    [
                        json
                    ],
                    {
                        type:
                            "application/json;charset=utf-8"
                    }
                );


            const url =
                URL.createObjectURL(
                    blob
                );


            const agora =
                new Date();


            const data =
                agora
                    .toISOString()
                    .slice(
                        0,
                        10
                    );


            const hora =
                String(
                    agora.getHours()
                ).padStart(
                    2,
                    "0"
                ) +
                "-" +
                String(
                    agora.getMinutes()
                ).padStart(
                    2,
                    "0"
                );


            const link =
                document.createElement(
                    "a"
                );


            link.href =
                url;


            link.download =

                "SeedControl_backup_emergencia_" +
                data +
                "_" +
                hora +
                ".json";


            document.body.appendChild(
                link
            );


            link.click();

            link.remove();


            setTimeout(
                function () {

                    URL.revokeObjectURL(
                        url
                    );

                },
                1000
            );


            alert(
                "Backup de emergência criado."
            );


        } catch (
            erro
        ) {

            console.error(
                erro
            );


            alert(
                "Não foi possível criar o backup."
            );

        }

    }


    // ======================================
    // EVENTOS
    // ======================================

    if (
        btnExecutar
    ) {

        btnExecutar.addEventListener(
            "click",
            executarDiagnostico
        );

    }


    if (
        btnBackup
    ) {

        btnBackup.addEventListener(
            "click",
            baixarBackupEmergencia
        );

    }


    // ======================================
    // API PARA TESTE
    // ======================================

    window.SeedControlDiagnostico = {

        executar:
            executarDiagnostico,

        criarBackup:
            criarBackupEmergencia

    };


    // ======================================
    // INICIAR
    // ======================================

    executarDiagnostico();


})();