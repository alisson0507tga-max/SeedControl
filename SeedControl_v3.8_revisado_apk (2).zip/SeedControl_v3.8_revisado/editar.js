// ===============================
// SeedControl v3.8
// editar.js
// ===============================

const id = Number(
    new URLSearchParams(
        window.location.search
    ).get("id")
);

const registro = obterLotePorId(id);


// ===============================
// VALIDAR LOTE
// ===============================

if (!registro) {

    alert("Lote não encontrado.");

    window.location.href =
        "estoque.html";

} else {

    // ===============================
    // ELEMENTOS
    // ===============================

    const campoCultivar =
        document.getElementById("cultivar");

    const campoPeneira =
        document.getElementById("peneira");

    const campoLote =
        document.getElementById("lote");

    const campoBags =
        document.getElementById("bags");

    const campoUmidade =
        document.getElementById("umidade");

    const campoTemperatura =
        document.getElementById("temperatura");

    const campoPMS =
        document.getElementById("pms");

    const campoFazenda =
        document.getElementById("fazenda");

    const campoTalhao =
        document.getElementById("talhao");

    const campoSecagem =
        document.getElementById("secagem");

    const campoMetodoPeso =
        document.getElementById("metodoPeso");

    const campoKgsMedia =
        document.getElementById("kgsMediaCalculado");

    const campoSacas60kg =
        document.getElementById("sacas60kgCalculado");

    const textoMetodoPeso =
        document.getElementById("textoMetodoPeso");

    const btnSalvar =
        document.getElementById("salvar");


    // ===============================
    // FORMATAÇÃO
    // ===============================

    function formatarNumeroEdicao(
        valor,
        casas = 2
    ) {

        const numero =
            Number(valor);

        if (!Number.isFinite(numero)) {
            return "0";
        }

        return numero.toLocaleString(
            "pt-BR",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: casas
            }
        );

    }


    // ===============================
    // PREENCHER DADOS
    // ===============================

    if (campoCultivar) {
        campoCultivar.value =
            registro.cultivar || "";
    }

    if (campoPeneira) {
        campoPeneira.value =
            registro.peneira || "";
    }

    if (campoLote) {
        campoLote.value =
            registro.lote ?? "";
    }

    if (campoBags) {
        campoBags.value =
            registro.bags ?? "";
    }

    if (campoUmidade) {
        campoUmidade.value =
            registro.umidade ?? "";
    }

    if (campoTemperatura) {
        campoTemperatura.value =
            registro.temperatura ?? "";
    }

    if (campoPMS) {
        campoPMS.value =
            registro.pms ?? "";
    }

    if (campoFazenda) {
        campoFazenda.value =
            registro.fazenda || "";
    }

    if (campoTalhao) {
        campoTalhao.value =
            registro.talhao || "";
    }


    // ===============================
    // SECAGEM
    // ===============================

    if (campoSecagem) {

        campoSecagem.value =
            normalizarSecagem(
                registro.secagem
            );

    }


    // ===============================
    // MÉTODO DO PESO
    // ===============================

    const metodoOriginal =
        normalizarMetodoPeso(
            registro.metodoPeso
        );

    if (campoMetodoPeso) {

        campoMetodoPeso.value =
            metodoOriginal;

    }


    // ===============================
    // ATUALIZAR CÁLCULO AUTOMÁTICO
    // ===============================

    function atualizarCalculoEdicao() {

        const bags =
            campoBags
                ? Number(campoBags.value) || 0
                : Number(registro.bags) || 0;

        const pms =
            campoPMS
                ? Number(campoPMS.value) || 0
                : Number(registro.pms) || 0;

        const metodo =
            campoMetodoPeso
                ? campoMetodoPeso.value
                : metodoOriginal;


        // Cálculo centralizado no database.js
        const calculo =
            calcularPesoESacasLote(
                bags,
                pms,
                metodo
            );


        if (campoKgsMedia) {

            campoKgsMedia.textContent =
                formatarNumeroEdicao(
                    calculo.kgsMedia,
                    2
                );

        }


        if (campoSacas60kg) {

            campoSacas60kg.textContent =
                formatarNumeroEdicao(
                    calculo.sacas60kg,
                    2
                );

        }


        if (textoMetodoPeso) {

            if (
                calculo.metodoPeso ===
                "comercial"
            ) {

                textoMetodoPeso.innerHTML =
                    "🌱 Peso calculado automaticamente pelo <strong>PMS</strong>, no padrão comercial.";

            } else {

                textoMetodoPeso.innerHTML =
                    "📦 Peso calculado automaticamente pelo método estimado.";

            }

        }

    }


    // ===============================
    // RECALCULAR EM TEMPO REAL
    // ===============================

    if (campoBags) {

        campoBags.addEventListener(
            "input",
            atualizarCalculoEdicao
        );

    }

    if (campoPMS) {

        campoPMS.addEventListener(
            "input",
            atualizarCalculoEdicao
        );

    }

    if (campoMetodoPeso) {

        campoMetodoPeso.addEventListener(
            "change",
            atualizarCalculoEdicao
        );

    }


    atualizarCalculoEdicao();


    // ===============================
    // SALVAR ALTERAÇÕES
    // ===============================

    if (btnSalvar) {

        btnSalvar.addEventListener(
            "click",
            function () {

                const novoLote = {

                    cultivar:
                        campoCultivar
                            ? campoCultivar.value.trim()
                            : "",

                    peneira:
                        campoPeneira
                            ? campoPeneira.value.trim()
                            : "",

                    lote:
                        campoLote
                            ? Number(campoLote.value)
                            : 0,

                    bags:
                        campoBags
                            ? Number(campoBags.value)
                            : 0,

                    umidade:
                        campoUmidade
                            ? Number(campoUmidade.value) || 0
                            : 0,

                    temperatura:
                        campoTemperatura
                            ? Number(campoTemperatura.value) || 0
                            : 0,

                    pms:
                        campoPMS
                            ? Number(campoPMS.value) || 0
                            : 0,

                    fazenda:
                        campoFazenda
                            ? campoFazenda.value.trim()
                            : "",

                    talhao:
                        campoTalhao
                            ? campoTalhao.value.trim()
                            : "",

                    secagem:
                        campoSecagem
                            ? campoSecagem.value
                            : normalizarSecagem(
                                registro.secagem
                            ),

                    // Se a tela possuir o seletor,
                    // usa a escolha atual.
                    // Se não possuir, preserva
                    // exatamente o método do lote.
                    metodoPeso:
                        campoMetodoPeso
                            ? campoMetodoPeso.value
                            : metodoOriginal

                };


                // ===============================
                // ATUALIZAR PELO DATABASE
                // ===============================

                const resultado =
                    atualizarLote(
                        id,
                        novoLote
                    );


                if (!resultado.ok) {

                    alert(
                        resultado.mensagem
                    );

                    return;

                }


                alert(
                    resultado.mensagem
                );


                window.location.href =
                    "cultivar.html?cultivar=" +
                    encodeURIComponent(
                        novoLote.cultivar
                    );

            }
        );

    }

}