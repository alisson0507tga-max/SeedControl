// ===============================
// SeedControl v3.8
// Dashboard (app.js)
// ===============================

let ouvintesDashboardRegistrados = false;


// ===============================
// FORMATAÇÃO
// ===============================

function formatarNumeroDashboard(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);

    if (!Number.isFinite(numero)) {
        return "0";
    }

    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ===============================
// ATUALIZAR ALERTAS
// ===============================

function atualizarAlertasEstoque(
    resumoInteligente
) {

    let painel =
        document.getElementById(
            "alertasEstoque"
        );


    // ===============================
    // CRIAR PAINEL SE NÃO EXISTIR
    // ===============================

    if (!painel) {

        const container =
            document.querySelector(
                ".container"
            );

        if (!container) {
            return;
        }


        painel =
            document.createElement(
                "div"
            );

        painel.id =
            "alertasEstoque";

        painel.className =
            "card";


        container.insertBefore(
            painel,
            container.firstChild
        );

    }


    // ===============================
    // GARANTIR RESUMO
    // ===============================

    const resumo =
        resumoInteligente || {

            totalRegistros: 0,

            normal: 0,

            baixo: 0,

            critico: 0,

            limites: {
                limiteBaixo: 30,
                limiteCritico: 10
            }

        };


    const totalRegistros =
        Number(
            resumo.totalRegistros
        ) || 0;


    const normal =
        Number(
            resumo.normal
        ) || 0;


    const baixo =
        Number(
            resumo.baixo
        ) || 0;


    const critico =
        Number(
            resumo.critico
        ) || 0;


    const limites =
        resumo.limites || {

            limiteBaixo: 30,

            limiteCritico: 10

        };


    // ===============================
    // MENSAGEM PRINCIPAL
    // ===============================

    let mensagem = "";


    if (totalRegistros === 0) {

        mensagem = `

            <p style="
                font-weight:bold;
            ">
                📦 Nenhum lote cadastrado.
            </p>

        `;

    } else {

        if (critico > 0) {

            mensagem += `

                <p style="
                    color:#dc2626;
                    font-weight:bold;
                ">
                    🔴 ${critico}
                    lote(s) em estoque crítico.
                </p>

            `;

        }


        if (baixo > 0) {

            mensagem += `

                <p style="
                    color:#ca8a04;
                    font-weight:bold;
                ">
                    🟡 ${baixo}
                    lote(s) com estoque baixo.
                </p>

            `;

        }


        if (
            critico === 0 &&
            baixo === 0
        ) {

            mensagem = `

                <p style="
                    color:#15803d;
                    font-weight:bold;
                ">
                    🟢 Todos os lotes estão
                    com estoque normal.
                </p>

            `;

        }

    }


    // ===============================
    // MONTAR PAINEL
    // ===============================

    painel.innerHTML = `

        <h2>
            🚨 Alertas de Estoque
        </h2>

        ${mensagem}

        <hr>

        <p>
            <strong>
                🟢 Normal:
            </strong>
            ${normal}
        </p>

        <p>
            <strong>
                🟡 Baixo:
            </strong>
            ${baixo}
        </p>

        <p>
            <strong>
                🔴 Crítico:
            </strong>
            ${critico}
        </p>

        <hr>

        <p style="
            font-size:0.9em;
            opacity:0.8;
        ">
            🟡 Baixo até
            <strong>
                ${limites.limiteBaixo} Bags
            </strong>
            |
            🔴 Crítico até
            <strong>
                ${limites.limiteCritico} Bags
            </strong>
        </p>

    `;

}


// ===============================
// ATUALIZAR DASHBOARD
// ===============================

function atualizarDashboard() {

    // ===============================
    // DADOS CENTRAIS
    // ===============================

    const estoque =
        carregarEstoque();


    const resumo =
        resumirEstoque(
            estoque
        );


    const resumoInteligente =
        obterResumoEstoqueInteligente(
            estoque
        );


    // ===============================
    // ELEMENTOS
    // ===============================

    const estoqueTotal =
        document.getElementById(
            "estoqueTotal"
        );

    const estoqueKgTotal =
        document.getElementById(
            "estoqueKgTotal"
        );

    const estoqueSacasTotal =
        document.getElementById(
            "estoqueSacasTotal"
        );

    const cultivares =
        document.getElementById(
            "cultivares"
        );

    const lotes =
        document.getElementById(
            "lotes"
        );

    const fazendas =
        document.getElementById(
            "fazendas"
        );


    // ===============================
    // TOTAL DE BAGS
    // ===============================

    if (estoqueTotal) {

        estoqueTotal.textContent =
            formatarNumeroDashboard(
                resumo.totalBags,
                2
            ) +
            " Bags";

    }


    // ===============================
    // TOTAL EM KG
    // ===============================

    if (estoqueKgTotal) {

        estoqueKgTotal.textContent =
            formatarNumeroDashboard(
                resumo.totalKgsMedia,
                2
            ) +
            " kg";

    }


    // ===============================
    // TOTAL EM SACAS DE 60 KG
    // ===============================

    if (estoqueSacasTotal) {

        estoqueSacasTotal.textContent =
            formatarNumeroDashboard(
                resumo.totalSacas60kg,
                2
            );

    }


    // ===============================
    // CULTIVARES
    // ===============================

    if (cultivares) {

        cultivares.textContent =
            resumo.totalCultivares;

    }


    // ===============================
    // LOTES
    // ===============================

    if (lotes) {

        lotes.textContent =
            resumo.totalLotesDistintos;

    }


    // ===============================
    // FAZENDAS
    // ===============================

    if (fazendas) {

        fazendas.textContent =
            resumo.totalFazendas;

    }


    // ===============================
    // ALERTAS
    // ===============================

    atualizarAlertasEstoque(
        resumoInteligente
    );


    // ===============================
    // ESTADO GLOBAL
    // ===============================

    window.__seedDashboard = {

        estoque:
            resumo,

        inteligente:
            resumoInteligente,

        totais: {

            bags:
                resumo.totalBags,

            kgsMedia:
                resumo.totalKgsMedia,

            sacas60kg:
                resumo.totalSacas60kg

        }

    };

}


// ===============================
// REGISTRAR OUVINTES
// ===============================

function registrarOuvintesDashboard() {

    if (
        ouvintesDashboardRegistrados
    ) {
        return;
    }


    ouvintesDashboardRegistrados =
        true;


    // ===============================
    // ALTERAÇÕES INTERNAS
    // ===============================

    window.addEventListener(
        "seedcontrol:atualizado",
        atualizarDashboard
    );


    // ===============================
    // OUTRAS ABAS
    // ===============================

    window.addEventListener(
        "storage",
        atualizarDashboard
    );


    // ===============================
    // RETORNO PARA A PÁGINA
    // ===============================

    window.addEventListener(
        "focus",
        atualizarDashboard
    );


    // ===============================
    // VISIBILIDADE
    // ===============================

    document.addEventListener(
        "visibilitychange",
        function () {

            if (!document.hidden) {

                atualizarDashboard();

            }

        }
    );

}


// ===============================
// INICIAR DASHBOARD
// ===============================

function iniciarDashboard() {

    atualizarDashboard();

    registrarOuvintesDashboard();

}


// ===============================
// INICIALIZAÇÃO
// ===============================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarDashboard
    );

} else {

    iniciarDashboard();

}