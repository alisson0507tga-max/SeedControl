// ===============================
// SeedControl v3.7
// Histórico
// ===============================

let ouvintesHistoricoRegistrados = false;

const lista = document.getElementById("lista");

function renderizarHistorico() {

    if (!lista) return;

    const historico = carregarHistorico();

    if (historico.length === 0) {

        lista.innerHTML = `
            <div class="card">
                <h2>📋 Nenhuma movimentação encontrada</h2>
                <p>Faça uma entrada, saída, edição ou exclusão para começar o histórico.</p>
            </div>
        `;

        return;

    }

    const html = historico.map(item => {

        let icone = "📋";

        if (item.tipo === "entrada") {
            icone = "➕";
        } else if (item.tipo === "saida") {
            icone = "➖";
        } else if (item.tipo === "edicao") {
            icone = "✏️";
        } else if (item.tipo === "exclusao") {
            icone = "🗑️";
        } else if (item.tipo === "cadastro") {
            icone = "🌱";
        }

        return `
            <div class="card">
                <h2>${icone} ${String(item.tipo || "").toUpperCase()}</h2>
                <p><strong>📅 Data:</strong> ${item.data || "-"}</p>
                <p><strong>🌱 Cultivar:</strong> ${item.cultivar || "-"}</p>
                <p><strong>📋 Lote:</strong> ${item.lote || "-"}</p>
                <p><strong>📦 Quantidade:</strong> ${item.quantidade || 0} Bags</p>
                <p><strong>📝 Observação:</strong> ${item.observacao || "Sem observação"}</p>
            </div>
        `;

    }).join("");

    lista.innerHTML = html;

}

function registrarOuvintesHistorico() {

    if (ouvintesHistoricoRegistrados) return;

    ouvintesHistoricoRegistrados = true;

    window.addEventListener("seedcontrol:atualizado", renderizarHistorico);
    window.addEventListener("storage", renderizarHistorico);
    window.addEventListener("focus", renderizarHistorico);

    document.addEventListener("visibilitychange", function () {

        if (!document.hidden) {
            renderizarHistorico();
        }

    });

}

function iniciarHistorico() {

    renderizarHistorico();
    registrarOuvintesHistorico();

}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", iniciarHistorico);
} else {
    iniciarHistorico();
}
