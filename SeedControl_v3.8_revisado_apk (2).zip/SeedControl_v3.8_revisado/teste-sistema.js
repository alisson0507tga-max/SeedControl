// ==========================================
// SeedControl v3.8
// teste-sistema.js
//
// TESTES SEM ALTERAR DADOS REAIS
// ==========================================

(function () {

    "use strict";


    const titulo =
        document.getElementById(
            "tituloTesteSistema"
        );


    const texto =
        document.getElementById(
            "textoTesteSistema"
        );


    const totalOk =
        document.getElementById(
            "totalTestesOk"
        );


    const totalFalha =
        document.getElementById(
            "totalTestesFalha"
        );


    const total =
        document.getElementById(
            "totalTestes"
        );


    const lista =
        document.getElementById(
            "listaTestesSistema"
        );


    const botao =
        document.getElementById(
            "btnExecutarTestes"
        );


    // ======================================
    // RESULTADOS
    // ======================================

    const resultados = [];


    function registrar(
        nome,
        ok,
        detalhe = ""
    ) {

        resultados.push(
            {
                nome,
                ok:
                    ok === true,
                detalhe
            }
        );

    }


    // ======================================
    // COMPARAR NÚMEROS
    // ======================================

    function numerosProximosTeste(
        a,
        b,
        tolerancia = 0.001
    ) {

        const numeroA =
            Number(a);


        const numeroB =
            Number(b);


        if (
            !Number.isFinite(
                numeroA
            ) ||
            !Number.isFinite(
                numeroB
            )
        ) {

            return false;

        }


        return (
            Math.abs(
                numeroA -
                numeroB
            ) <= tolerancia
        );

    }


    // ======================================
    // TESTE DE FUNÇÃO
    // ======================================

    function testarFuncao(
        nome,
        referencia
    ) {

        registrar(

            nome,

            typeof referencia ===
            "function",

            typeof referencia ===
            "function"

                ? "Disponível"

                : "Função não encontrada"

        );

    }


    // ======================================
    // TESTE DATABASE
    // ======================================

    function testarDatabase() {

        testarFuncao(
            "carregarEstoque()",
            window.carregarEstoque
        );


        testarFuncao(
            "salvarEstoque()",
            window.salvarEstoque
        );


        testarFuncao(
            "cadastrarLote()",
            window.cadastrarLote
        );


        testarFuncao(
            "atualizarLote()",
            window.atualizarLote
        );


        testarFuncao(
            "movimentarLote()",
            window.movimentarLote
        );


        testarFuncao(
            "obterLotePorId()",
            window.obterLotePorId
        );


        testarFuncao(
            "calcularPesoESacasLote()",
            window.calcularPesoESacasLote
        );


        testarFuncao(
            "aplicarCalculosLote()",
            window.aplicarCalculosLote
        );


        testarFuncao(
            "obterPesoEstimadoPadraoBagKg()",
            window.obterPesoEstimadoPadraoBagKg
        );


        testarFuncao(
            "resumirEstoque()",
            window.resumirEstoque
        );

    }


    // ======================================
    // TESTE DE LEITURA
    // ======================================

    function testarLeituraEstoque() {

        if (
            typeof carregarEstoque !==
            "function"
        ) {

            registrar(
                "Leitura do estoque",
                false,
                "carregarEstoque() indisponível"
            );

            return;

        }


        try {

            const estoque =
                carregarEstoque();


            registrar(

                "Leitura do estoque",

                Array.isArray(
                    estoque
                ),

                Array.isArray(
                    estoque
                )

                    ? estoque.length +
                      " registro(s)"

                    : "Formato inválido"

            );


        } catch (
            erro
        ) {

            registrar(
                "Leitura do estoque",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // TESTE DOS CÁLCULOS
    // ======================================

    function testarCalculos() {

        if (
            typeof calcularPesoESacasLote !==
            "function"
        ) {

            registrar(
                "Cálculo de peso",
                false,
                "Serviço indisponível"
            );

            return;

        }


        try {

            // ==================================
            // 1. ESTIMADO PADRÃO
            //
            // 10 Bags × 1.050 kg
            // = 10.500 kg
            // = 175 sacas
            // ==================================

            const estimadoPadrao =
                calcularPesoESacasLote(
                    10,
                    180,
                    "estimado"
                );


            registrar(

                "Peso estimado padrão — 1.050 kg/Bag",

                !!estimadoPadrao &&
                numerosProximosTeste(
                    estimadoPadrao.pesoBagKg,
                    1050
                ) &&
                numerosProximosTeste(
                    estimadoPadrao.kgsMedia,
                    10500
                ) &&
                numerosProximosTeste(
                    estimadoPadrao.sacas60kg,
                    175
                ),

                estimadoPadrao

                    ? (
                        estimadoPadrao.pesoBagKg +
                        " kg/Bag | " +
                        estimadoPadrao.kgsMedia +
                        " kg | " +
                        estimadoPadrao.sacas60kg +
                        " sacas"
                    )

                    : "Sem resultado"

            );


            // ==================================
            // 2. ESTIMADO PERSONALIZADO
            //
            // 10 Bags × 900 kg
            // = 9.000 kg
            // = 150 sacas
            // ==================================

            const estimado900 =
                calcularPesoESacasLote(
                    10,
                    180,
                    "estimado",
                    900
                );


            registrar(

                "Peso estimado personalizado — 900 kg/Bag",

                !!estimado900 &&
                numerosProximosTeste(
                    estimado900.pesoBagKg,
                    900
                ) &&
                numerosProximosTeste(
                    estimado900.kgsMedia,
                    9000
                ) &&
                numerosProximosTeste(
                    estimado900.sacas60kg,
                    150
                ),

                estimado900

                    ? (
                        estimado900.pesoBagKg +
                        " kg/Bag | " +
                        estimado900.kgsMedia +
                        " kg | " +
                        estimado900.sacas60kg +
                        " sacas"
                    )

                    : "Sem resultado"

            );


            // ==================================
            // 3. OUTRO PESO PERSONALIZADO
            //
            // 10 Bags × 1150 kg
            // = 11.500 kg
            // ==================================

            const estimado1150 =
                calcularPesoESacasLote(
                    10,
                    180,
                    "estimado",
                    1150
                );


            registrar(

                "Peso estimado personalizado — 1.150 kg/Bag",

                !!estimado1150 &&
                numerosProximosTeste(
                    estimado1150.pesoBagKg,
                    1150
                ) &&
                numerosProximosTeste(
                    estimado1150.kgsMedia,
                    11500
                ) &&
                numerosProximosTeste(
                    estimado1150.sacas60kg,
                    11500 / 60
                ),

                estimado1150

                    ? (
                        estimado1150.kgsMedia +
                        " kg"
                    )

                    : "Sem resultado"

            );


            // ==================================
            // 4. COMERCIAL PMS
            //
            // PMS 200 × 5
            // = 1000 kg/Bag
            //
            // 10 Bags = 10.000 kg
            // ==================================

            const comercial =
                calcularPesoESacasLote(
                    10,
                    200,
                    "comercial"
                );


            registrar(

                "Peso Comercial (PMS)",

                !!comercial &&
                numerosProximosTeste(
                    comercial.pesoBagKg,
                    1000
                ) &&
                numerosProximosTeste(
                    comercial.kgsMedia,
                    10000
                ),

                comercial

                    ? (
                        comercial.pesoBagKg +
                        " kg/Bag | " +
                        comercial.kgsMedia +
                        " kg"
                    )

                    : "Sem resultado"

            );


            // ==================================
            // 5. COMERCIAL DEVE IGNORAR
            // PESO ESTIMADO INFORMADO
            // ==================================

            const comercialIgnoraPeso =
                calcularPesoESacasLote(
                    10,
                    200,
                    "comercial",
                    900
                );


            registrar(

                "Comercial ignora peso estimado manual",

                !!comercialIgnoraPeso &&
                numerosProximosTeste(
                    comercialIgnoraPeso.pesoBagKg,
                    1000
                ) &&
                numerosProximosTeste(
                    comercialIgnoraPeso.kgsMedia,
                    10000
                ),

                comercialIgnoraPeso

                    ? (
                        comercialIgnoraPeso.pesoBagKg +
                        " kg/Bag"
                    )

                    : "Sem resultado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Cálculos de peso",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // COMPATIBILIDADE COM LOTES ANTIGOS
    // ======================================

    function testarCompatibilidadeLoteAntigo() {

        if (
            typeof aplicarCalculosLote !==
            "function"
        ) {

            registrar(
                "Compatibilidade com lote antigo",
                false,
                "aplicarCalculosLote() indisponível"
            );

            return;

        }


        try {

            // Lote antigo:
            // não possui pesoBagKg.

            const loteAntigo = {

                id:
                    1,

                cultivar:
                    "TESTE",

                peneira:
                    "P1",

                lote:
                    1,

                bags:
                    2,

                pms:
                    180,

                metodoPeso:
                    "estimado",

                fazenda:
                    "TESTE",

                secagem:
                    "nao_precisou"

            };


            const calculado =
                aplicarCalculosLote(
                    loteAntigo
                );


            registrar(

                "Lote antigo assume 1.050 kg/Bag",

                !!calculado &&
                numerosProximosTeste(
                    calculado.pesoBagKg,
                    1050
                ) &&
                numerosProximosTeste(
                    calculado.kgsMedia,
                    2100
                ) &&
                numerosProximosTeste(
                    calculado.sacas60kg,
                    35
                ),

                calculado

                    ? (
                        calculado.pesoBagKg +
                        " kg/Bag | " +
                        calculado.kgsMedia +
                        " kg"
                    )

                    : "Sem resultado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Compatibilidade com lote antigo",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // SIMULAÇÃO DE MOVIMENTAÇÃO
    //
    // NÃO USA O LOCALSTORAGE.
    // NÃO ALTERA ESTOQUE REAL.
    // ======================================

    function testarPesoAposMovimentacao() {

        if (
            typeof aplicarCalculosLote !==
            "function"
        ) {

            registrar(
                "Peso mantido após movimentação",
                false,
                "aplicarCalculosLote() indisponível"
            );

            return;

        }


        try {

            // 10 Bags de 900 kg.

            const antes =
                aplicarCalculosLote(
                    {
                        id:
                            999999,

                        cultivar:
                            "TESTE",

                        peneira:
                            "P1",

                        lote:
                            999999,

                        bags:
                            10,

                        pms:
                            180,

                        metodoPeso:
                            "estimado",

                        pesoBagKg:
                            900,

                        fazenda:
                            "TESTE",

                        secagem:
                            "nao_precisou"
                    }
                );


            // Simula saída de 1 Bag.
            // Não chama movimentarLote().
            // Portanto não toca nos dados reais.

            const depois =
                aplicarCalculosLote(
                    {
                        ...antes,
                        bags:
                            9
                    }
                );


            registrar(

                "Peso de 900 kg mantido após saída simulada",

                !!depois &&
                numerosProximosTeste(
                    depois.pesoBagKg,
                    900
                ) &&
                numerosProximosTeste(
                    depois.kgsMedia,
                    8100
                ) &&
                numerosProximosTeste(
                    depois.sacas60kg,
                    135
                ),

                depois

                    ? (
                        depois.bags +
                        " Bags | " +
                        depois.pesoBagKg +
                        " kg/Bag | " +
                        depois.kgsMedia +
                        " kg"
                    )

                    : "Sem resultado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Peso mantido após movimentação",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // COMMAND SERVICE
    // ======================================

    function testarCommandService() {

        const commands =
            window.SeedControlCommands;


        registrar(

            "Command Service carregado",

            !!commands,

            commands
                ? "Ativo"
                : "Não encontrado"

        );


        if (!commands) {

            return;

        }


        registrar(

            "Command Service preparar()",

            typeof commands.preparar ===
            "function",

            typeof commands.preparar ===
            "function"
                ? "Disponível"
                : "Ausente"

        );


        registrar(

            "Command Service executar()",

            typeof commands.executar ===
            "function",

            typeof commands.executar ===
            "function"
                ? "Disponível"
                : "Ausente"

        );


        // ==================================
        // PESO POR BAG NO COMMAND SERVICE
        // ==================================

        try {

            const acoes =
                typeof commands.listarAcoes ===
                "function"

                    ? commands.listarAcoes()

                    : null;


            const campos =
                acoes &&
                acoes.atualizacao &&
                Array.isArray(
                    acoes.atualizacao.campos
                )

                    ? acoes.atualizacao.campos

                    : [];


            registrar(

                "Command Service suporta pesoBagKg",

                campos.includes(
                    "pesoBagKg"
                ),

                campos.includes(
                    "pesoBagKg"
                )
                    ? "Disponível"
                    : "Campo ausente"

            );


        } catch (erro) {

            registrar(
                "Command Service suporta pesoBagKg",
                false,
                erro.message
            );

        }


        // ==================================
        // CAMPO PROIBIDO
        // ==================================

        try {

            const testeCampo =
                commands.preparar(
                    {

                        acao:
                            "atualizar_lote",

                        parametros: {

                            lote:
                                "__LOTE_TESTE_INEXISTENTE__",

                            campo:
                                "campo_proibido",

                            valor:
                                "teste"

                        }

                    }
                );


            registrar(

                "Bloqueio de campo não permitido",

                testeCampo &&
                testeCampo.ok ===
                false &&
                testeCampo.codigo ===
                "CAMPO_NAO_PERMITIDO",

                testeCampo &&
                testeCampo.codigo

                    ? testeCampo.codigo

                    : "Resultado inesperado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Bloqueio de campo não permitido",
                false,
                erro.message
            );

        }


        // ==================================
        // MOVIMENTAÇÃO SEM QUANTIDADE
        // ==================================

        try {

            const testeQuantidade =
                commands.preparar(
                    {

                        acao:
                            "saida",

                        parametros: {

                            lote:
                                "__LOTE_TESTE__",

                            quantidade:
                                0

                        }

                    }
                );


            registrar(

                "Bloqueio de movimentação inválida",

                testeQuantidade &&
                testeQuantidade.ok ===
                false,

                testeQuantidade &&
                testeQuantidade.codigo

                    ? testeQuantidade.codigo

                    : "Resultado inesperado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Bloqueio de movimentação inválida",
                false,
                erro.message
            );

        }


        // ==================================
        // CADASTRO INCOMPLETO
        // ==================================

        try {

            const cadastro =
                commands.preparar(
                    {

                        acao:
                            "cadastrar_lote",

                        parametros: {

                            cultivar:
                                "TESTE"

                        }

                    }
                );


            registrar(

                "Bloqueio de cadastro incompleto",

                cadastro &&
                cadastro.ok ===
                false,

                cadastro &&
                cadastro.codigo

                    ? cadastro.codigo

                    : "Resultado inesperado"

            );


        } catch (
            erro
        ) {

            registrar(
                "Bloqueio de cadastro incompleto",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // IA SERVICE
    // ======================================

    function testarIA() {

        const ia =
            window.SeedControlIA;


        registrar(

            "IA Service carregado",

            !!ia,

            ia
                ? "Ativo"
                : "Não encontrado"

        );


        if (!ia) {

            return;

        }


        registrar(

            "IA processarMensagem()",

            typeof ia.processarMensagem ===
            "function",

            "Entrada central da IA"

        );


        registrar(

            "IA criarContexto()",

            typeof ia.criarContexto ===
            "function",

            "Contexto disponível"

        );


        try {

            const estado =
                ia.obterEstado();


            registrar(

                "Estado da IA",

                !!estado &&
                estado.ativo ===
                true,

                estado &&
                estado.modo

                    ? "Modo: " +
                      estado.modo

                    : "Sem modo"

            );


        } catch (
            erro
        ) {

            registrar(
                "Estado da IA",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // CONFIG IA
    // ======================================

    function testarConfiguracaoIA() {

        registrar(

            "IA Config carregado",

            !!window.SeedControlIAConfig,

            window.SeedControlIAConfig

                ? (
                    "Modo: " +
                    window
                        .SeedControlIAConfig
                        .modo
                )

                : "Não encontrado"

        );

    }


    // ======================================
    // COMMAND UI
    // ======================================

    function testarCommandUI() {

        registrar(

            "Command UI Bridge",

            !!window.SeedControlCommandUI,

            window.SeedControlCommandUI

                ? "Ativo"

                : "Não encontrado"

        );

    }


    // ======================================
    // LOCALSTORAGE
    // ======================================

    function testarLocalStorage() {

        try {

            const chave =
                "__seedcontrol_teste_storage__";


            localStorage.setItem(
                chave,
                "ok"
            );


            const valor =
                localStorage.getItem(
                    chave
                );


            localStorage.removeItem(
                chave
            );


            registrar(

                "Armazenamento local",

                valor === "ok",

                valor === "ok"
                    ? "Funcionando"
                    : "Falhou"

            );


        } catch (
            erro
        ) {

            registrar(
                "Armazenamento local",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // ARQUIVOS CRÍTICOS
    // ======================================

    async function testarArquivosCriticos() {

        try {

            const resposta =
                await fetch(
                    "assistente.js",
                    {
                        cache:
                            "no-store"
                    }
                );


            const conteudo =
                await resposta.text();


            let sintaxeOk =
                resposta.ok;


            let detalhe =
                resposta.ok
                    ? "Carregado e compilável"
                    : (
                        "HTTP " +
                        resposta.status
                    );


            if (sintaxeOk) {

                try {

                    new Function(
                        conteudo
                    );

                } catch (erroSintaxe) {

                    sintaxeOk =
                        false;

                    detalhe =
                        erroSintaxe.message;

                }

            }


            registrar(
                "assistente.js válido",
                sintaxeOk,
                detalhe
            );


        } catch (erro) {

            registrar(
                "assistente.js válido",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // MANIFEST
    // ======================================

    async function testarManifest() {

        try {

            const resposta =
                await fetch(
                    "manifest.json",
                    {
                        cache:
                            "no-store"
                    }
                );


            registrar(

                "manifest.json",

                resposta.ok,

                resposta.ok
                    ? "Carregado"
                    : (
                        "HTTP " +
                        resposta.status
                    )

            );


            if (!resposta.ok) {
                return;
            }


            const manifest =
                await resposta.json();


            const icones =
                Array.isArray(
                    manifest.icons
                )
                    ? manifest.icons
                    : [];


            for (
                const tamanho of [
                    "192x192",
                    "512x512"
                ]
            ) {

                const icone =
                    icones.find(
                        item =>
                            item &&
                            item.sizes ===
                                tamanho &&
                            item.src
                    );


                if (!icone) {

                    registrar(
                        "Ícone PWA " + tamanho,
                        false,
                        "Não declarado no manifest"
                    );

                    continue;

                }


                try {

                    const respostaIcone =
                        await fetch(
                            icone.src,
                            {
                                cache:
                                    "no-store"
                            }
                        );


                    registrar(
                        "Ícone PWA " + tamanho,
                        respostaIcone.ok,
                        respostaIcone.ok
                            ? "Carregado"
                            : (
                                "HTTP " +
                                respostaIcone.status
                            )
                    );


                } catch (erroIcone) {

                    registrar(
                        "Ícone PWA " + tamanho,
                        false,
                        erroIcone.message
                    );

                }

            }


        } catch (erro) {

            registrar(
                "manifest.json",
                false,
                erro.message
            );

        }

    }


    // ======================================
    // SERVICE WORKER
    // ======================================

    function testarServiceWorker() {

        const suportado =
            "serviceWorker" in
            navigator;


        registrar(

            "Suporte a Service Worker",

            suportado,

            suportado
                ? "Disponível"
                : "Navegador não suporta"

        );


        if (
            suportado
        ) {

            const controlador =
                !!navigator
                    .serviceWorker
                    .controller;


            registrar(

                "PWA controlando a página",

                controlador,

                controlador

                    ? "Service Worker ativo"

                    : "Ainda não controlando esta página"

            );

        }

    }


    // ======================================
    // RENDERIZAR
    // ======================================

    function renderizar() {

        if (!lista) {

            return;

        }


        lista.innerHTML =
            "";


        resultados.forEach(
            item => {

                const div =
                    document.createElement(
                        "div"
                    );


                div.className =
                    "card";


                div.innerHTML =

                    "<h3>" +
                    (
                        item.ok

                            ? "✅ "

                            : "❌ "
                    ) +
                    item.nome +
                    "</h3>" +

                    "<p>" +
                    item.detalhe +
                    "</p>";


                lista.appendChild(
                    div
                );

            }
        );


        const aprovados =
            resultados.filter(
                item =>
                    item.ok
            ).length;


        const falhas =
            resultados.length -
            aprovados;


        if (totalOk) {

            totalOk.textContent =
                aprovados;

        }


        if (totalFalha) {

            totalFalha.textContent =
                falhas;

        }


        if (total) {

            total.textContent =
                resultados.length;

        }


        if (
            falhas === 0
        ) {

            if (titulo) {

                titulo.textContent =
                    "🟢 Sistema aprovado";

            }


            if (texto) {

                texto.textContent =
                    "Todos os testes passaram.";

            }


        } else {

            if (titulo) {

                titulo.textContent =
                    "🔴 Foram encontradas falhas";

            }


            if (texto) {

                texto.textContent =

                    falhas +
                    " teste(s) precisam de atenção.";

            }

        }

    }


    // ======================================
    // EXECUTAR
    // ======================================

    async function executar() {

        resultados.length =
            0;


        if (titulo) {

            titulo.textContent =
                "🔄 Executando testes...";

        }


        if (texto) {

            texto.textContent =
                "Aguarde.";

        }


        if (lista) {

            lista.innerHTML =
                "Executando...";

        }


        testarDatabase();

        testarLeituraEstoque();

        testarCalculos();

        testarCompatibilidadeLoteAntigo();

        testarPesoAposMovimentacao();

        testarCommandService();

        testarIA();

        testarConfiguracaoIA();

        testarCommandUI();

        testarLocalStorage();

        testarServiceWorker();

        await testarArquivosCriticos();

        await testarManifest();


        renderizar();


        window.__seedControlTestes =
            {
                data:
                    new Date()
                        .toISOString(),

                resultados:
                    [
                        ...resultados
                    ]
            };

    }


    // ======================================
    // BOTÃO
    // ======================================

    if (botao) {

        botao.addEventListener(
            "click",
            executar
        );

    }


    // ======================================
    // INICIAR
    // ======================================

    executar();


})();