// ===============================
// SeedControl - Histórico editável
// ===============================

let ouvintesHistoricoRegistrados = false;
const lista = document.getElementById("lista");

function escaparHistorico(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, function (caractere) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[caractere];
    });
}

function nomeTipoHistorico(tipo) {
    return ({ entrada: "Entrada", saida: "Saída", edicao: "Edição", exclusao: "Exclusão", cadastro: "Cadastro" })[tipo] || tipo || "Registro";
}

function iconeTipoHistorico(tipo) {
    return ({ entrada: "➕", saida: "➖", edicao: "✏️", exclusao: "🗑️", cadastro: "🌱" })[tipo] || "📋";
}

function alternarEdicaoHistorico(indice, editar) {
    const form = document.getElementById("historico-edicao-" + indice);
    const resumo = document.getElementById("historico-resumo-" + indice);
    if (form) form.hidden = !editar;
    if (resumo) resumo.hidden = editar;
}

function salvarEdicaoHistorico(indice) {
    const form = document.getElementById("historico-edicao-" + indice);
    if (!form) return;
    const resultado = atualizarRegistroHistorico(indice, {
        quantidade: form.elements.quantidade ? form.elements.quantidade.value : undefined,
        observacao: form.elements.observacao ? form.elements.observacao.value : undefined,
        data: form.elements.data ? form.elements.data.value : undefined
    });
    if (!resultado.ok) { alert(resultado.mensagem); return; }
    renderizarHistorico();
}

function renderizarHistorico() {
    if (!lista) return;
    const historico = carregarHistorico();
    if (historico.length === 0) {
        lista.innerHTML = '<div class="card"><h2>📋 Nenhuma movimentação encontrada</h2><p>Faça uma entrada, saída, edição ou exclusão para começar o histórico.</p></div>';
        return;
    }
    lista.innerHTML = historico.map(function (item, indice) {
        const tipo = String(item.tipo || "").toLowerCase();
        const permiteQuantidade = tipo === "entrada" || tipo === "saida";
        return '<div class="card historico-item">' +
            '<div id="historico-resumo-' + indice + '">' +
            '<h2>' + iconeTipoHistorico(tipo) + ' ' + escaparHistorico(nomeTipoHistorico(tipo)) + '</h2>' +
            '<p><strong>📅 Data:</strong> ' + escaparHistorico(item.data || "-") + '</p>' +
            '<p><strong>🌱 Cultivar:</strong> ' + escaparHistorico(item.cultivar || "-") + '</p>' +
            '<p><strong>📋 Lote:</strong> ' + escaparHistorico(item.lote || "-") + '</p>' +
            '<p><strong>📦 Quantidade:</strong> ' + escaparHistorico(item.quantidade ?? 0) + ' Bags</p>' +
            '<p><strong>📝 Observação:</strong> ' + escaparHistorico(item.observacao || "Sem observação") + '</p>' +
            '<button type="button" onclick="alternarEdicaoHistorico(' + indice + ', true)">✏️ Editar registro</button>' +
            '</div>' +
            '<form id="historico-edicao-' + indice + '" hidden onsubmit="event.preventDefault(); salvarEdicaoHistorico(' + indice + ')">' +
            '<h3>Editar ' + escaparHistorico(nomeTipoHistorico(tipo)) + '</h3>' +
            '<label>Data<input name="data" type="text" value="' + escaparHistorico(item.data || "") + '"></label>' +
            (permiteQuantidade ? '<label>Quantidade de Bags<input name="quantidade" type="text" inputmode="text" value="' + escaparHistorico(item.quantidade ?? "") + '"></label>' : '') +
            '<label>Observação<textarea name="observacao">' + escaparHistorico(item.observacao || "") + '</textarea></label>' +
            '<button type="submit">💾 Salvar edição</button> <button type="button" onclick="alternarEdicaoHistorico(' + indice + ', false)">Cancelar</button>' +
            '</form>' +
            '</div>';
    }).join("");
}

function registrarOuvintesHistorico() {
    if (ouvintesHistoricoRegistrados) return;
    ouvintesHistoricoRegistrados = true;
    window.addEventListener("seedcontrol:atualizado", renderizarHistorico);
    window.addEventListener("storage", renderizarHistorico);
    window.addEventListener("focus", renderizarHistorico);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) renderizarHistorico(); });
}

function iniciarHistorico() { renderizarHistorico(); registrarOuvintesHistorico(); }
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciarHistorico);
else iniciarHistorico();
