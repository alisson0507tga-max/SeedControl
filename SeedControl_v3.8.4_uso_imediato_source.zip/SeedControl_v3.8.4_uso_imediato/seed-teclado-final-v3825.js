// seedcontrol-teclado-final-v3825
(function () {
    "use strict";

    let campoAtivo = null;
    let tecladoAberto = false;
    let textoClipboard = "";
    let barra = null;

    const TERMOS = [
        "estoque", "bags", "bag", "lote", "lotes", "cultivar", "cultivares",
        "fazenda", "talhão", "peneira", "umidade", "temperatura", "PMS",
        "total", "quanto", "quantas", "temos", "tenho", "entrada", "saída"
    ];

    function plugin(nome) {
        try {
            return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[nome];
        } catch (_) {
            return null;
        }
    }

    function ehCampoTexto(el) {
        if (!el || el.disabled || el.readOnly) return false;
        if (el.tagName === "TEXTAREA") return true;
        if (el.tagName !== "INPUT") return false;
        return ["text", "search", "email", "url", "tel"].includes(String(el.type || "text").toLowerCase());
    }

    function estoqueAtual() {
        try {
            if (typeof window.carregarEstoque === "function") {
                const e = window.carregarEstoque();
                return Array.isArray(e) ? e : [];
            }
        } catch (_) {}

        for (const chave of ["estoque", "seedcontrol_estoque", "lotes"]) {
            try {
                const valor = JSON.parse(localStorage.getItem(chave) || "[]");
                if (Array.isArray(valor) && valor.length) return valor;
            } catch (_) {}
        }
        return [];
    }

    function unicos(lista) {
        return [...new Set(lista.map(v => String(v == null ? "" : v).trim()).filter(Boolean))];
    }

    function prefixoAtual() {
        if (!campoAtivo) return "";
        const valor = String(campoAtivo.value || "");
        const pos = typeof campoAtivo.selectionStart === "number" ? campoAtivo.selectionStart : valor.length;
        const antes = valor.slice(0, pos);
        const m = antes.match(/([^\s,.;:!?()\[\]{}]+)$/);
        return m ? m[1].toLowerCase() : "";
    }

    function sugestoesDoCampo() {
        const estoque = estoqueAtual();
        const id = String(campoAtivo && campoAtivo.id || "").toLowerCase();
        let lista = [];

        if (id.includes("cultivar")) lista = unicos(estoque.map(x => x.cultivar));
        else if (id.includes("peneira")) lista = unicos(estoque.map(x => x.peneira));
        else if (id.includes("fazenda")) lista = unicos(estoque.map(x => x.fazenda));
        else if (id.includes("talhao") || id.includes("talhão")) lista = unicos(estoque.map(x => x.talhao));
        else lista = TERMOS.concat(unicos(estoque.map(x => x.cultivar))).concat(unicos(estoque.map(x => x.fazenda)));

        const p = prefixoAtual();
        if (p) {
            const comeca = lista.filter(v => String(v).toLowerCase().startsWith(p));
            const contem = lista.filter(v => !comeca.includes(v) && String(v).toLowerCase().includes(p));
            lista = comeca.concat(contem);
        }

        return unicos(lista).slice(0, 5);
    }

    async function lerClipboard() {
        textoClipboard = "";
        const clip = plugin("Clipboard");
        if (clip && typeof clip.read === "function") {
            try {
                const r = await clip.read();
                textoClipboard = String(r && r.value || "").trim();
                return;
            } catch (_) {}
        }

        try {
            if (navigator.clipboard && typeof navigator.clipboard.readText === "function") {
                textoClipboard = String(await navigator.clipboard.readText() || "").trim();
            }
        } catch (_) {}
    }

    function inserirTexto(texto, substituirPalavra) {
        if (!campoAtivo) return;
        const valor = String(campoAtivo.value || "");
        let ini = typeof campoAtivo.selectionStart === "number" ? campoAtivo.selectionStart : valor.length;
        let fim = typeof campoAtivo.selectionEnd === "number" ? campoAtivo.selectionEnd : ini;

        if (substituirPalavra && ini === fim) {
            const antes = valor.slice(0, ini);
            const m = antes.match(/([^\s,.;:!?()\[\]{}]+)$/);
            if (m) ini -= m[1].length;
        }

        const novo = valor.slice(0, ini) + texto + valor.slice(fim);
        campoAtivo.value = novo;
        const pos = ini + texto.length;
        try { campoAtivo.setSelectionRange(pos, pos); } catch (_) {}
        campoAtivo.dispatchEvent(new Event("input", { bubbles: true }));
        campoAtivo.focus();
        renderizar();
    }

    function criarBarra() {
        if (barra) return barra;
        barra = document.createElement("div");
        barra.id = "seedSugestoesV3825";
        barra.className = "seed-sugestoes-v3825";
        barra.setAttribute("aria-label", "Sugestões e área de transferência");
        document.body.appendChild(barra);
        return barra;
    }

    function botao(texto, classe, acao) {
        const b = document.createElement("button");
        b.type = "button";
        b.textContent = texto;
        if (classe) b.className = classe;
        b.addEventListener("pointerdown", function (e) { e.preventDefault(); });
        b.addEventListener("click", acao);
        return b;
    }

    function renderizar() {
        criarBarra();
        barra.innerHTML = "";

        if (!tecladoAberto || !ehCampoTexto(campoAtivo)) {
            barra.classList.remove("ativo");
            return;
        }

        if (textoClipboard) {
            const preview = textoClipboard.replace(/\s+/g, " ").slice(0, 22);
            barra.appendChild(botao("📋 " + preview + (textoClipboard.length > 22 ? "…" : ""), "seed-colar-v3825", function () {
                inserirTexto(textoClipboard, false);
            }));
        } else {
            barra.appendChild(botao("📋 Colar", "seed-colar-v3825", async function () {
                await lerClipboard();
                if (textoClipboard) inserirTexto(textoClipboard, false);
                else renderizar();
            }));
        }

        sugestoesDoCampo().forEach(function (s) {
            barra.appendChild(botao(String(s), "", function () {
                inserirTexto(String(s), true);
            }));
        });

        barra.classList.add("ativo");
    }

    function setTeclado(aberto) {
        tecladoAberto = !!aberto;
        document.body.classList.toggle("seed-teclado-aberto-v3825", tecladoAberto);
        if (!tecladoAberto) {
            textoClipboard = "";
            if (barra) barra.classList.remove("ativo");
        } else {
            setTimeout(function () {
                lerClipboard().finally(renderizar);
            }, 80);
        }
    }

    async function ligarKeyboardNativo() {
        const kb = plugin("Keyboard");
        if (!kb || typeof kb.addListener !== "function") return false;
        try {
            await kb.addListener("keyboardWillShow", function () { setTeclado(true); });
            await kb.addListener("keyboardDidShow", function () { setTeclado(true); });
            await kb.addListener("keyboardWillHide", function () { setTeclado(false); });
            await kb.addListener("keyboardDidHide", function () { setTeclado(false); });
            return true;
        } catch (_) {
            return false;
        }
    }

    function ligarFallbackViewport() {
        const base = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
        function conferir() {
            const atual = window.visualViewport ? window.visualViewport.height : (window.innerHeight || 0);
            setTeclado(base - atual > 140 || (!!campoAtivo && document.activeElement === campoAtivo && atual < base * 0.82));
        }
        if (window.visualViewport) window.visualViewport.addEventListener("resize", conferir, { passive: true });
        window.addEventListener("resize", conferir, { passive: true });
    }

    function iniciar() {
        criarBarra();

        document.addEventListener("focusin", function (e) {
            if (!ehCampoTexto(e.target)) return;
            campoAtivo = e.target;
            campoAtivo.setAttribute("autocomplete", "on");
            campoAtivo.setAttribute("autocorrect", "on");
            campoAtivo.setAttribute("spellcheck", "true");
            setTimeout(function () { lerClipboard().finally(renderizar); }, 120);
        }, true);

        document.addEventListener("input", function (e) {
            if (e.target === campoAtivo) renderizar();
        }, true);

        document.addEventListener("focusout", function (e) {
            if (e.target !== campoAtivo) return;
            setTimeout(function () {
                if (document.activeElement !== campoAtivo && !ehCampoTexto(document.activeElement)) {
                    campoAtivo = null;
                    if (barra) barra.classList.remove("ativo");
                }
            }, 140);
        }, true);

        ligarKeyboardNativo().then(function (ok) {
            if (!ok) ligarFallbackViewport();
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, { once: true });
    else iniciar();
})();
