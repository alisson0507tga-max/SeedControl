// ===============================
// SeedControl v3.8
// cultivar.js
// ===============================


// ===============================
// CULTIVAR SELECIONADA
// ===============================

const params =
    new URLSearchParams(
        window.location.search
    );

const nomeCultivar =
    params.get("cultivar");


// ===============================
// ELEMENTOS
// ===============================

const titulo =
    document.getElementById(
        "tituloCultivar"
    );

const lista =
    document.getElementById(
        "listaLotes"
    );

const totalBags =
    document.getElementById(
        "totalBags"
    );

let ouvintesCultivarRegistrados =
    false;


// ===============================
// TÍTULO
// ===============================

if (titulo) {

    titulo.textContent =
        nomeCultivar ||
        "Cultivar";

}


// ===============================
// FORMATAÇÃO
// ===============================

function formatarNumeroCultivar(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);


    if (!Number.isFinite(numero)) {
        return "0";
    }


    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    );

}


// ===============================
// SEGURANÇA HTML
// ===============================

function escaparHtmlCultivar(valor) {

    return String(valor ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

}


// ===============================
// SECAGEM
// ===============================

function obterTextoSecagemCultivar(
    valor
) {

    const situacao =
        normalizarSecagem(
            valor
        );


    if (
        situacao ===
        "secou"
    ) {

        return "✅ Secou";

    }


    return "ℹ️ Não precisou secar";

}


// ===============================
// MÉTODO DO PESO
// ===============================

function obterTextoMetodoPesoCultivar(
    valor
) {

    const metodo =
        normalizarMetodoPeso(
            valor
        );


    if (
        metodo ===
        "comercial"
    ) {

        return "🌱 Comercial (PMS)";

    }


    return "📦 Estimado";

}


// ===============================
// PESO DO BAG
// ===============================

function obterTextoPesoBagCultivar(
    item
) {

    const peso =
        formatarNumeroCultivar(
            item.pesoBagKg,
            2
        );


    const metodo =
        normalizarMetodoPeso(
            item.metodoPeso
        );


    if (
        metodo ===
        "comercial"
    ) {

        return (
            peso +
            " kg — calculado pelo PMS"
        );

    }


    return peso + " kg";

}


// ===============================
// RENDERIZAR CULTIVAR
// ===============================

function renderizarCultivar() {

    const estoque =
        carregarEstoque();


    if (!lista) {
        return;
    }


    lista.innerHTML = "";


    // ===============================
    // SEM CULTIVAR
    // ===============================

    if (!nomeCultivar) {

        lista.innerHTML = `

            <div class="card">

                <h2>
                    ⚠️ Nenhuma cultivar selecionada.
                </h2>

            </div>

        `;


        if (totalBags) {

            totalBags.textContent =
                "0 Bags";

        }


        return;

    }


    // ===============================
    // FILTRAR LOTES
    // ===============================

    const lotes =
        estoque.filter(
            item =>
                item &&
                item.cultivar ===
                    nomeCultivar
        );


    // ===============================
    // SEM LOTES
    // ===============================

    if (
        lotes.length === 0
    ) {

        lista.innerHTML = `

            <div class="card">

                <h2>
                    ⚠️ Nenhum lote encontrado.
                </h2>

            </div>

        `;


        if (totalBags) {

            totalBags.textContent =
                "0 Bags";

        }


        return;

    }


    // ===============================
    // TOTAL DA CULTIVAR
    // ===============================

    let somaBags = 0;


    lotes.forEach(
        item => {

            somaBags +=
                Number(
                    item.bags
                ) || 0;


            // ===============================
            // STATUS
            // ===============================

            const status =
                obterStatusEstoque(
                    item
                );


            // ===============================
            // VALORES
            // ===============================

            const pesoBag =
                obterTextoPesoBagCultivar(
                    item
                );


            const kgsMedia =
                formatarNumeroCultivar(
                    item.kgsMedia,
                    2
                );


            const sacas60kg =
                formatarNumeroCultivar(
                    item.sacas60kg,
                    2
                );


            const metodoPeso =
                obterTextoMetodoPesoCultivar(
                    item.metodoPeso
                );


            const secagem =
                obterTextoSecagemCultivar(
                    item.secagem
                );


            // ===============================
            // CARD
            // ===============================

            lista.innerHTML += `

            <div
                class="card"
                style="
                    border-left:8px solid ${status.cor};
                "
            >

                <h2>
                    📋 Lote ${escaparHtmlCultivar(item.lote)}
                </h2>


                <p>
                    <strong>
                        ${status.texto}
                    </strong>
                </p>


                <p>
                    <strong>📦 Bags:</strong>
                    ${formatarNumeroCultivar(item.bags, 2)}
                </p>


                <p>
                    <strong>⚖️ Peso por Bag:</strong>
                    ${pesoBag}
                </p>


                <p>
                    <strong>⚖️ Kg (Média):</strong>
                    ${kgsMedia} kg
                </p>


                <p>
                    <strong>🌾 Sacas (60 kg):</strong>
                    ${sacas60kg}
                </p>


                <p>
                    <strong>⚙️ Método do Peso:</strong>
                    ${metodoPeso}
                </p>


                <p>
                    <strong>🌱 Peneira:</strong>
                    ${escaparHtmlCultivar(item.peneira)}
                </p>


                <p>
                    <strong>🚜 Fazenda:</strong>
                    ${escaparHtmlCultivar(item.fazenda)}
                </p>


                <p>
                    <strong>📍 Talhão:</strong>
                    ${escaparHtmlCultivar(item.talhao || "-")}
                </p>


                <p>
                    <strong>💧 Umidade:</strong>
                    ${formatarNumeroCultivar(item.umidade, 2)}%
                </p>


                <p>
                    <strong>🌡️ Temperatura:</strong>
                    ${formatarNumeroCultivar(item.temperatura, 2)} °C
                </p>


                <p>
                    <strong>⚖️ PMS:</strong>
                    ${formatarNumeroCultivar(item.pms, 2)} g
                </p>


                <p>
                    <strong>🌬️ Secagem:</strong>
                    ${secagem}
                </p>


                <button
                    type="button"
                    onclick="window.location.href='movimentacao.html?id=${item.id}'"
                    style="
                        background:#16a34a;
                        margin-bottom:10px;
                    "
                >
                    📦 Movimentar Estoque
                </button>


                <button
                    type="button"
                    onclick="window.location.href='cadastro.html?id=${item.id}'"
                >
                    ✏️ Editar
                </button>

            </div>

            `;

        }
    );


    // ===============================
    // TOTAL DE BAGS
    // ===============================

    if (totalBags) {

        totalBags.textContent =
            formatarNumeroCultivar(
                somaBags,
                2
            ) +
            " Bags";

    }

}


// ===============================
// OUVINTES
// ===============================

function registrarOuvintesCultivar() {

    if (
        ouvintesCultivarRegistrados
    ) {
        return;
    }


    ouvintesCultivarRegistrados =
        true;


    window.addEventListener(
        "seedcontrol:atualizado",
        renderizarCultivar
    );


    window.addEventListener(
        "storage",
        renderizarCultivar
    );


    window.addEventListener(
        "focus",
        renderizarCultivar
    );


    document.addEventListener(
        "visibilitychange",
        function () {

            if (!document.hidden) {

                renderizarCultivar();

            }

        }
    );

}


// ===============================
// INICIAR
// ===============================

function iniciarCultivar() {

    renderizarCultivar();

    registrarOuvintesCultivar();

}


// ===============================
// INICIALIZAÇÃO
// ===============================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarCultivar
    );

} else {

    iniciarCultivar();

}