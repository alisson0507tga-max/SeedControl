// seedcontrol-ime-nativo-real-v3827
(function () {
    "use strict";

    let campoAtivo = null;
    let pluginLigado = false;
    let ativando = false;

    function plugin() {
        try {
            return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NativeIme;
        } catch (_) {
            return null;
        }
    }

    function paginaAtual() {
        return String(location.pathname || "").split("/").pop().toLowerCase();
    }

    function ehCampoTexto(el) {
        if (!el || el.disabled || el.readOnly) return false;
        if (el.tagName === "TEXTAREA") return true;
        if (el.tagName !== "INPUT") return false;
        return ["text", "search", "email", "url", "tel"].includes(String(el.type || "text").toLowerCase());
    }

    function camposVisiveisCadastro() {
        if (paginaAtual() !== "cadastro.html") return [];
        return Array.from(document.querySelectorAll("input, select, textarea"))
            .filter(function (el) {
                if (!el || el.disabled || el.readOnly || el.hidden || el.offsetParent === null) return false;
                if (el.tagName === "INPUT") {
                    const t = String(el.type || "text").toLowerCase();
                    if (["hidden", "file", "checkbox", "radio", "button", "submit", "reset", "image"].includes(t)) return false;
                }
                return true;
            });
    }

    function acaoDoCampo(campo) {
        if (paginaAtual() === "assistente-chat-v384.html") return "send";
        if (paginaAtual() === "cadastro.html") {
            const campos = camposVisiveisCadastro();
            const i = campos.indexOf(campo);
            return i >= 0 && i < campos.length - 1 ? "next" : "done";
        }
        return "done";
    }

    function marcar(campo, ativo) {
        if (!campo) return;
        campo.classList.toggle("seed-ime-nativo-ativo-v3827", !!ativo);
    }

    async function ativar(campo) {
        const p = plugin();
        if (!p || typeof p.focusInput !== "function" || !ehCampoTexto(campo) || ativando) return;

        ativando = true;
        try {
            if (campoAtivo && campoAtivo !== campo) marcar(campoAtivo, false);
            campoAtivo = campo;

            let inicio = String(campo.value || "").length;
            let fim = inicio;
            try {
                if (typeof campo.selectionStart === "number") inicio = campo.selectionStart;
                if (typeof campo.selectionEnd === "number") fim = campo.selectionEnd;
            } catch (_) {}

            // O foco real passa para um EditText Android. O HTML continua sendo
            // a interface visível e recebe o texto espelhado pelos eventos nativos.
            try { campo.blur(); } catch (_) {}
            marcar(campo, true);

            await p.focusInput({
                value: String(campo.value || ""),
                selectionStart: inicio,
                selectionEnd: fim,
                action: acaoDoCampo(campo)
            });
        } catch (erro) {
            marcar(campo, false);
            campoAtivo = null;
            try { campo.focus(); } catch (_) {}
            console.warn("SeedControl: entrada nativa indisponível; usando WebView.", erro);
        } finally {
            ativando = false;
        }
    }

    function aplicarTexto(valor, inicio, fim) {
        if (!campoAtivo) return;
        campoAtivo.value = String(valor == null ? "" : valor);
        campoAtivo.dispatchEvent(new Event("input", { bubbles: true }));
        try {
            campoAtivo.setSelectionRange(Number(inicio) || campoAtivo.value.length, Number(fim) || Number(inicio) || campoAtivo.value.length);
        } catch (_) {}
    }

    async function esconderNativo() {
        const p = plugin();
        if (p && typeof p.hideInput === "function") {
            try { await p.hideInput(); } catch (_) {}
        }
        if (campoAtivo) marcar(campoAtivo, false);
        campoAtivo = null;
    }

    async function proximoCampo() {
        if (!campoAtivo || paginaAtual() !== "cadastro.html") return;
        const atual = campoAtivo;
        const campos = camposVisiveisCadastro();
        const i = campos.indexOf(atual);
        const proximo = i >= 0 ? campos[i + 1] : null;

        if (!proximo) {
            await esconderNativo();
            return;
        }

        marcar(atual, false);
        campoAtivo = null;

        if (ehCampoTexto(proximo)) {
            await ativar(proximo);
        } else {
            await esconderNativo();
            try { proximo.focus({ preventScroll: true }); } catch (_) { try { proximo.focus(); } catch (_) {} }
            try { proximo.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (_) {}
        }
    }

    function ligarPlugin() {
        if (pluginLigado) return;
        const p = plugin();
        if (!p || typeof p.addListener !== "function") return;
        pluginLigado = true;

        p.addListener("textChanged", function (d) {
            aplicarTexto(d && d.value, d && d.selectionStart, d && d.selectionEnd);
        });

        p.addListener("editorAction", async function (d) {
            const acao = String(d && d.action || "");
            if (acao === "send" && paginaAtual() === "assistente-chat-v384.html") {
                const botao = document.getElementById("enviar");
                await esconderNativo();
                if (botao) botao.click();
                return;
            }
            if (acao === "next" && paginaAtual() === "cadastro.html") {
                await proximoCampo();
                return;
            }
            if (acao === "done") await esconderNativo();
        });
    }

    function iniciar() {
        ligarPlugin();

        // O campo WebView recebe foco por um instante apenas para calcular a
        // posição do cursor. Em seguida o foco é transferido ao EditText nativo.
        document.addEventListener("focusin", function (e) {
            if (!ehCampoTexto(e.target)) return;
            setTimeout(function () { ativar(e.target); }, 0);
        }, true);

        document.addEventListener("click", function (e) {
            const alvo = e.target && e.target.closest ? e.target.closest("button") : null;
            if (!alvo) return;
            if (alvo.id === "enviar" || alvo.id === "microfone" || alvo.id === "salvar") {
                esconderNativo();
            }
        }, true);

        document.addEventListener("visibilitychange", function () {
            if (document.hidden) esconderNativo();
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, { once: true });
    else iniciar();
})();
