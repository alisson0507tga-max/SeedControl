// seedcontrol-dados-soja2026-v3830
(function () {
    "use strict";

    const MARCA = "seedcontrol_soja2026_v3830_importado";
    const REGISTROS = [{"cultivar":"77i79 RSF(VORAZ)","peneira":"P1","lote":1,"bags":18,"pesoBagKg":1050,"kgsMedia":18900,"sacas60kg":315,"umidade":11.4,"temperatura":22.6,"pms":149.07,"fazenda":"Santa Terezinha","talhao":"8","secagem":true,"metodoPeso":"estimado"},{"cultivar":"77i79 RSF(VORAZ)","peneira":"P2","lote":2,"bags":30,"pesoBagKg":1050,"kgsMedia":31500,"sacas60kg":525,"umidade":11.5,"temperatura":22.4,"pms":192.44,"fazenda":"Santa Terezinha","talhao":"8","secagem":true,"metodoPeso":"estimado"},{"cultivar":"77i79 RSF(VORAZ)","peneira":"P2","lote":3,"bags":31,"pesoBagKg":1050,"kgsMedia":32550,"sacas60kg":542.5,"umidade":11.3,"temperatura":22.7,"pms":192.54,"fazenda":"Santa Terezinha","talhao":"8","secagem":true,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":4,"bags":33,"pesoBagKg":1050,"kgsMedia":34650,"sacas60kg":577.5,"umidade":11.4,"temperatura":22.1,"pms":182.73,"fazenda":"Graciosa","talhao":"4","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":5,"bags":30,"pesoBagKg":1050,"kgsMedia":31500,"sacas60kg":525,"umidade":11.3,"temperatura":22.5,"pms":183.36,"fazenda":"Graciosa","talhao":"4","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P1","lote":6,"bags":18,"pesoBagKg":1050,"kgsMedia":18900,"sacas60kg":315,"umidade":11.5,"temperatura":22.1,"pms":143.02,"fazenda":"Graciosa","talhao":"4","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":7,"bags":44,"pesoBagKg":1050,"kgsMedia":46200,"sacas60kg":770,"umidade":11.8,"temperatura":22.9,"pms":186.6,"fazenda":"Graciosa","talhao":"6","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":8,"bags":18,"pesoBagKg":1050,"kgsMedia":18900,"sacas60kg":315,"umidade":11.7,"temperatura":22.8,"pms":183.38,"fazenda":"Graciosa","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P1","lote":9,"bags":25,"pesoBagKg":1050,"kgsMedia":26250,"sacas60kg":437.5,"umidade":12.0,"temperatura":22.4,"pms":149.1,"fazenda":"Graciosa","talhao":"3 e 6","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":10,"bags":22,"pesoBagKg":1050,"kgsMedia":23100,"sacas60kg":385,"umidade":11.4,"temperatura":22.9,"pms":183.26,"fazenda":"Graciosa","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"67i68 RSF (GUEPARDO)","peneira":"P2","lote":11,"bags":27,"pesoBagKg":1050,"kgsMedia":28350,"sacas60kg":472.5,"umidade":11.3,"temperatura":22.9,"pms":181.17,"fazenda":"Graciosa","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"76sc114 i2x(GARCAS)","peneira":"P2","lote":12,"bags":34,"pesoBagKg":1050,"kgsMedia":35700,"sacas60kg":595,"umidade":11.8,"temperatura":22.8,"pms":188.55,"fazenda":"São João","talhao":"5","secagem":false,"metodoPeso":"estimado"},{"cultivar":"76sc114 i2x(GARCAS)","peneira":"P1","lote":13,"bags":4,"pesoBagKg":1050,"kgsMedia":4200,"sacas60kg":70,"umidade":11.8,"temperatura":22.8,"pms":145.11,"fazenda":"São João","talhao":"5","secagem":false,"metodoPeso":"estimado"},{"cultivar":"CZ37B07 i2x","peneira":"P2","lote":14,"bags":32,"pesoBagKg":1050,"kgsMedia":33600,"sacas60kg":560,"umidade":12.2,"temperatura":22.9,"pms":184.88,"fazenda":"Santa Edwige","talhao":"1","secagem":false,"metodoPeso":"estimado"},{"cultivar":"CZ37B07 i2x","peneira":"P1","lote":15,"bags":9,"pesoBagKg":1050,"kgsMedia":9450,"sacas60kg":157.5,"umidade":12.3,"temperatura":22.8,"pms":147.81,"fazenda":"Santa Edwige","talhao":"1","secagem":false,"metodoPeso":"estimado"},{"cultivar":"80i82 RSF(OLIMPO)","peneira":"P2","lote":16,"bags":40,"pesoBagKg":1050,"kgsMedia":42000,"sacas60kg":700,"umidade":11.8,"temperatura":22.8,"pms":185.16,"fazenda":"Santa Terezinha","talhao":"4 e 5","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80i82 RSF(OLIMPO)","peneira":"P2","lote":17,"bags":42,"pesoBagKg":1050,"kgsMedia":44100,"sacas60kg":735,"umidade":11.7,"temperatura":22.5,"pms":184.74,"fazenda":"Santa Terezinha","talhao":"4 e 5","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80i82 RSF(OLIMPO)","peneira":"P1","lote":18,"bags":40,"pesoBagKg":1050,"kgsMedia":42000,"sacas60kg":700,"umidade":11.8,"temperatura":22.3,"pms":143.88,"fazenda":"Santa Terezinha","talhao":"4 e 5","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80i82 RSF(OLIMPO)","peneira":"P2","lote":19,"bags":19,"pesoBagKg":1050,"kgsMedia":19950,"sacas60kg":332.5,"umidade":11.7,"temperatura":22.8,"pms":186.68,"fazenda":"Santa Terezinha","talhao":"4 e 5","secagem":true,"metodoPeso":"estimado"},{"cultivar":"CZ37B66 i2x","peneira":"P2","lote":20,"bags":21,"pesoBagKg":1050,"kgsMedia":22050,"sacas60kg":367.5,"umidade":12.5,"temperatura":22.9,"pms":182.88,"fazenda":"Santa Terezinha","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"CZ37B66 i2x","peneira":"P2","lote":21,"bags":33,"pesoBagKg":1050,"kgsMedia":34650,"sacas60kg":577.5,"umidade":12.1,"temperatura":22.8,"pms":186.63,"fazenda":"Santa Terezinha","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"CZ37B66 i2x","peneira":"P1","lote":22,"bags":6,"pesoBagKg":1050,"kgsMedia":6300,"sacas60kg":105,"umidade":12.1,"temperatura":22.4,"pms":148.41,"fazenda":"Santa Terezinha","talhao":"3","secagem":false,"metodoPeso":"estimado"},{"cultivar":"7601 i2x","peneira":"P2","lote":23,"bags":35,"pesoBagKg":1050,"kgsMedia":36750,"sacas60kg":612.5,"umidade":11.9,"temperatura":22.2,"pms":180.35,"fazenda":"Graciosa","talhao":"7","secagem":false,"metodoPeso":"estimado"},{"cultivar":"7601 i2x","peneira":"P1","lote":24,"bags":28,"pesoBagKg":1050,"kgsMedia":29400,"sacas60kg":490,"umidade":11.8,"temperatura":22.9,"pms":143.12,"fazenda":"Graciosa","talhao":"7","secagem":false,"metodoPeso":"estimado"},{"cultivar":"7601 i2x","peneira":"P2","lote":25,"bags":32,"pesoBagKg":1050,"kgsMedia":33600,"sacas60kg":560,"umidade":11.7,"temperatura":22.7,"pms":179.33,"fazenda":"Santa Terezinha","talhao":"7","secagem":true,"metodoPeso":"estimado"},{"cultivar":"7601 i2x","peneira":"P1","lote":26,"bags":26,"pesoBagKg":1050,"kgsMedia":27300,"sacas60kg":455,"umidade":12.0,"temperatura":22.3,"pms":143.5,"fazenda":"Santa Terezinha","talhao":"7","secagem":true,"metodoPeso":"estimado"},{"cultivar":"69SC100 i2x(MOGI)","peneira":"P2","lote":27,"bags":43,"pesoBagKg":1050,"kgsMedia":45150,"sacas60kg":752.5,"umidade":11.4,"temperatura":23.0,"pms":194.53,"fazenda":"Santa Terezinha","talhao":"1","secagem":true,"metodoPeso":"estimado"},{"cultivar":"69SC100 i2x(MOGI)","peneira":"P1","lote":28,"bags":24,"pesoBagKg":1050,"kgsMedia":25200,"sacas60kg":420,"umidade":11.5,"temperatura":23.0,"pms":155.4,"fazenda":"Santa Terezinha","talhao":"1","secagem":true,"metodoPeso":"estimado"},{"cultivar":"69SC100 i2x(MOGI)","peneira":"P2","lote":29,"bags":35,"pesoBagKg":1050,"kgsMedia":36750,"sacas60kg":612.5,"umidade":11.8,"temperatura":22.5,"pms":194.76,"fazenda":"Santa Terezinha","talhao":"1","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80ix81 RSF (SPARTA)","peneira":"P2","lote":30,"bags":32,"pesoBagKg":1050,"kgsMedia":33600,"sacas60kg":560,"umidade":11.4,"temperatura":23.1,"pms":195.7,"fazenda":"Graciosa","talhao":"9A","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80ix81 RSF (SPARTA)","peneira":"P2","lote":31,"bags":42,"pesoBagKg":1050,"kgsMedia":44100,"sacas60kg":735,"umidade":11.6,"temperatura":22.6,"pms":194.01,"fazenda":"Graciosa","talhao":"9A","secagem":true,"metodoPeso":"estimado"},{"cultivar":"80ix81 RSF (SPARTA)","peneira":"P1","lote":32,"bags":18,"pesoBagKg":1050,"kgsMedia":18900,"sacas60kg":315,"umidade":11.4,"temperatura":22.6,"pms":150.01,"fazenda":"Graciosa","talhao":"9A","secagem":true,"metodoPeso":"estimado"},{"cultivar":"CZ47B91 i2x","peneira":"P2","lote":33,"bags":45,"pesoBagKg":1050,"kgsMedia":47250,"sacas60kg":787.5,"umidade":11.6,"temperatura":22.3,"pms":188.16,"fazenda":"Graciosa","talhao":"10A","secagem":true,"metodoPeso":"estimado"},{"cultivar":"CZ47B91 i2x","peneira":"P1","lote":34,"bags":28,"pesoBagKg":1050,"kgsMedia":29400,"sacas60kg":490,"umidade":11.9,"temperatura":22.8,"pms":153.16,"fazenda":"Graciosa","talhao":"10A","secagem":true,"metodoPeso":"estimado"},{"cultivar":"81SC118 i2x(mutum)","peneira":"P2","lote":35,"bags":25,"pesoBagKg":1050,"kgsMedia":26250,"sacas60kg":437.5,"umidade":11.5,"temperatura":21.3,"pms":165.78,"fazenda":"Fundão","talhao":"5","secagem":true,"metodoPeso":"estimado"},{"cultivar":"81SC118 i2x(mutum)","peneira":"P1","lote":36,"bags":14,"pesoBagKg":1050,"kgsMedia":14700,"sacas60kg":245,"umidade":11.4,"temperatura":21.7,"pms":120.48,"fazenda":"Fundão","talhao":"5","secagem":true,"metodoPeso":"estimado"}];

    function normalizar(valor) {
        return String(valor == null ? "" : valor)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .trim()
            .replace(/\s+/g, " ");
    }

    function chave(item) {
        return [
            normalizar(item.cultivar),
            normalizar(item.peneira),
            String(Number(item.lote) || 0),
            normalizar(item.fazenda),
            normalizar(item.talhao)
        ].join("|");
    }

    function carregar() {
        try {
            const dados = JSON.parse(localStorage.getItem("estoque") || "[]");
            return Array.isArray(dados) ? dados : [];
        } catch (_) {
            return [];
        }
    }

    function importar() {
        if (localStorage.getItem(MARCA) === "1") return;

        const estoque = carregar();
        const existentes = new Set(estoque.map(chave));
        const ids = new Set(
            estoque
                .map(item => Number(item && item.id))
                .filter(Number.isFinite)
        );

        let adicionados = 0;

        REGISTROS.forEach(function (origem, indice) {
            if (existentes.has(chave(origem))) return;

            let id = 2026081900000 + indice + 1;
            while (ids.has(id)) id++;

            const novo = Object.assign({
                id: id,
                dataCadastro: "2026-08-19T11:44:00-04:00",
                origem: "Soja 2026"
            }, origem);

            estoque.push(novo);
            existentes.add(chave(novo));
            ids.add(id);
            adicionados++;
        });

        if (adicionados > 0) {
            localStorage.setItem("estoque", JSON.stringify(estoque));
            try {
                window.dispatchEvent(
                    new CustomEvent("seedcontrol:atualizado", {
                        detail: {
                            origem: "Soja 2026",
                            adicionados: adicionados
                        }
                    })
                );
            } catch (_) {}
        }

        localStorage.setItem(MARCA, "1");
        localStorage.setItem(
            "seedcontrol_soja2026_v3830_adicionados",
            String(adicionados)
        );
    }

    importar();
})();
