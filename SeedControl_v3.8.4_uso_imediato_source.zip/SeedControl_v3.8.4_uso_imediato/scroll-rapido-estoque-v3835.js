// seedcontrol-scroll-rapido-estoque-v3835
(function () {
    'use strict';

    if (document.getElementById('seedFastTrack')) return;

    const track = document.createElement('div');
    track.id = 'seedFastTrack';
    track.setAttribute('aria-hidden', 'true');
    track.innerHTML = '<div id="seedFastThumb"><div id="seedFastBubble">Lote</div></div>';
    document.body.appendChild(track);

    const thumb = document.getElementById('seedFastThumb');
    const bubble = document.getElementById('seedFastBubble');

    let dragging = false;
    let pointerId = null;
    let offsetY = 0;
    let raf = null;

    function maxScroll() {
        return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    }

    function trackRange() {
        return Math.max(1, track.clientHeight - thumb.offsetHeight);
    }

    function tecladoAberto() {
        return !!(window.visualViewport && window.visualViewport.height < window.innerHeight * 0.72);
    }

    function posicaoThumb() {
        const max = maxScroll();
        if (max <= 0) return 0;
        return Math.max(0, Math.min(trackRange(), (window.scrollY / max) * trackRange()));
    }

    function atualizarThumb() {
        if (!dragging) thumb.style.top = posicaoThumb() + 'px';
        const mostrar = maxScroll() > 600 && !tecladoAberto();
        track.classList.toggle('seed-fast-visible', mostrar);
    }

    function loteVisivel() {
        const cards = Array.from(document.querySelectorAll('#lista .card-registro, #lista .estoque-registro'));
        if (!cards.length) return '';
        const alvoY = window.innerHeight * 0.48;
        let melhor = null;
        let melhorDist = Infinity;
        for (const card of cards) {
            const r = card.getBoundingClientRect();
            const centro = (r.top + r.bottom) / 2;
            const dist = Math.abs(centro - alvoY);
            if (dist < melhorDist) {
                melhorDist = dist;
                melhor = card;
            }
        }
        if (!melhor) return '';
        const texto = String(melhor.innerText || melhor.textContent || '');
        const m = texto.match(/Lote\s*:?\s*([^\n\r]+)/i);
        if (m && m[1]) return m[1].trim().split(/\s+/)[0];
        return '';
    }

    function atualizarBubble() {
        const lote = loteVisivel();
        if (lote) bubble.textContent = 'Lote ' + lote;
        else {
            const max = maxScroll();
            const pct = max > 0 ? Math.round((window.scrollY / max) * 100) : 0;
            bubble.textContent = pct + '%';
        }
    }

    function scrollPeloPointer(clientY) {
        const rect = track.getBoundingClientRect();
        let top = clientY - rect.top - offsetY;
        top = Math.max(0, Math.min(trackRange(), top));
        thumb.style.top = top + 'px';
        const proporcao = top / trackRange();
        const destino = proporcao * maxScroll();
        window.scrollTo(0, destino);
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(atualizarBubble);
    }

    thumb.addEventListener('pointerdown', function (ev) {
        if (ev.pointerType === 'mouse' && ev.button !== 0) return;
        ev.preventDefault();
        dragging = true;
        pointerId = ev.pointerId;
        const rect = thumb.getBoundingClientRect();
        offsetY = ev.clientY - rect.top;
        thumb.classList.add('seed-fast-dragging');
        atualizarBubble();
        try { thumb.setPointerCapture(pointerId); } catch (_) {}
    });

    thumb.addEventListener('pointermove', function (ev) {
        if (!dragging || ev.pointerId !== pointerId) return;
        ev.preventDefault();
        scrollPeloPointer(ev.clientY);
    });

    function finalizar(ev) {
        if (!dragging) return;
        if (ev) ev.preventDefault();
        dragging = false;
        thumb.classList.remove('seed-fast-dragging');
        try {
            if (pointerId !== null && thumb.hasPointerCapture(pointerId)) thumb.releasePointerCapture(pointerId);
        } catch (_) {}
        pointerId = null;
        atualizarThumb();
    }

    thumb.addEventListener('pointerup', finalizar);
    thumb.addEventListener('pointercancel', finalizar);
    thumb.addEventListener('lostpointercapture', function () {
        if (dragging) finalizar();
    });
    thumb.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });

    window.addEventListener('scroll', function () {
        if (!dragging) atualizarThumb();
    }, { passive: true });
    window.addEventListener('resize', atualizarThumb, { passive: true });
    if (window.visualViewport) window.visualViewport.addEventListener('resize', atualizarThumb, { passive: true });

    const observer = new MutationObserver(function () {
        if (!dragging) atualizarThumb();
    });
    observer.observe(document.getElementById('lista') || document.body, { childList: true, subtree: true });

    atualizarThumb();
})();
