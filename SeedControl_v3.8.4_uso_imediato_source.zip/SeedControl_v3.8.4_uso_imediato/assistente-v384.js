// seedcontrol-assistente-conversa-v384
// seedcontrol-assistente-intencao-v384
(function () {
    "use strict";

    const CHAVE_CONVERSA = "seedcontrol_assistente_conversa_v384";
    const LIMITE_MENSAGENS = 60;

    let mensagens = [];
    let movimentoPendente = null;
    let ouvindo = false;

    const $ = (id) => document.getElementById(id);

    function normalizar(valor) {
        return String(valor == null ? "" : valor)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .trim();
    }

    function numero(valor) {
        const n = Number(String(valor == null ? "" : valor).replace(",", "."));
        return Number.isFinite(n) ? n : 0;
    }

    function estoqueAtual() {
        try {
            if (typeof carregarEstoque === "function") return carregarEstoque();
            const bruto = JSON.parse(localStorage.getItem("estoque") || "[]");
            return Array.isArray(bruto) ? bruto : [];
        } catch (_) {
            return [];
        }
    }

    function salvarBase(estoque) {
        if (typeof salvarEstoque === "function") {
            salvarEstoque(estoque);
            return;
        }
        localStorage.setItem("estoque", JSON.stringify(estoque));
    }

    function salvarHistoricoMovimento(item, tipo, qtd, antes, depois) {
        try {
            const historico = typeof carregarHistorico === "function"
                ? carregarHistorico()
                : JSON.parse(localStorage.getItem("historico") || "[]");

            const lista = Array.isArray(historico) ? historico : [];
            lista.unshift({
                id: Date.now(),
                data: new Date().toLocaleString("pt-BR"),
                tipo,
                quantidade: qtd,
                cultivar: item.cultivar || "",
                lote: item.lote || "",
                fazenda: item.fazenda || "",
                talhao: item.talhao || "",
                peneira: item.peneira || "",
                bagsAntes: antes,
                bagsDepois: depois,
                origem: "Assistente SeedControl"
            });

            if (typeof salvarHistorico === "function") salvarHistorico(lista);
            else localStorage.setItem("historico", JSON.stringify(lista));
        } catch (_) {}
    }

    function horario() {
        return new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    }

    function salvarConversa() {
        try {
            localStorage.setItem(CHAVE_CONVERSA, JSON.stringify(mensagens.slice(-LIMITE_MENSAGENS)));
        } catch (_) {}
    }

    function escapar(texto) {
        return String(texto)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function rolarFim() {
        const caixa = $("assistenteMensagens");
        if (!caixa) return;
        requestAnimationFrame(() => {
            caixa.scrollTop = caixa.scrollHeight;
        });
    }

    function criarBolha(tipo, texto, opcoes) {
        const caixa = $("assistenteMensagens");
        if (!caixa) return;

        const div = document.createElement("div");
        div.className = "assistente-v384-msg " + (tipo === "usuario" ? "usuario" : "assistente");
        div.innerHTML = `<div>${escapar(texto).replace(/\n/g, "<br>")}</div><span class="hora">${horario()}</span>`;

        if (opcoes && opcoes.confirmacao) {
            const acoes = document.createElement("div");
            acoes.className = "confirmacao-acoes";
            acoes.innerHTML = `
                <button type="button" data-confirmar-movimento="1">✓ Confirmar</button>
                <button type="button" class="cancelar" data-cancelar-movimento="1">Cancelar</button>
            `;
            div.appendChild(acoes);
        }

        caixa.appendChild(div);
        rolarFim();
    }

    function adicionar(tipo, texto, opcoes) {
        const msg = { tipo, texto: String(texto), data: Date.now() };
        mensagens.push(msg);
        mensagens = mensagens.slice(-LIMITE_MENSAGENS);
        salvarConversa();
        criarBolha(tipo, texto, opcoes);
    }

    function restaurarConversa() {
        try {
            const lidas = JSON.parse(localStorage.getItem(CHAVE_CONVERSA) || "[]");
            mensagens = Array.isArray(lidas) ? lidas.slice(-LIMITE_MENSAGENS) : [];
        } catch (_) {
            mensagens = [];
        }

        const caixa = $("assistenteMensagens");
        if (caixa) caixa.innerHTML = "";

        mensagens.forEach((m) => criarBolha(m.tipo, m.texto));

        if (!mensagens.length) {
            adicionar(
                "assistente",
                "Olá! Eu sou o Assistente SeedControl. Você pode falar ou escrever comigo.\n\nExemplos:\n• Quantas bags da Guepardo eu tenho?\n• Onde está o lote 105?\n• Quais lotes têm umidade acima de 12%?\n• Saiu 10 bags do lote 25."
            );
        }
    }

    function setStatus(texto, estaOuvindo) {
        const status = $("assistenteStatus");
        const bloco = status && status.parentElement;
        if (status) status.textContent = texto;
        if (bloco) bloco.classList.toggle("ouvindo", !!estaOuvindo);
    }

    function formatarNumero(n, casas) {
        return Number(n || 0).toLocaleString("pt-BR", {
            minimumFractionDigits: casas || 0,
            maximumFractionDigits: casas == null ? 2 : casas
        });
    }

    function cultivarMencionada(frase, estoque) {
        const n = normalizar(frase);
        const nomes = [...new Set(estoque.map((x) => String(x.cultivar || "").trim()).filter(Boolean))];
        return nomes
            .sort((a, b) => b.length - a.length)
            .find((nome) => n.includes(normalizar(nome))) || "";
    }

    function fazendaMencionada(frase, estoque) {
        const n = normalizar(frase);
        const nomes = [...new Set(estoque.map((x) => String(x.fazenda || "").trim()).filter(Boolean))];
        return nomes
            .sort((a, b) => b.length - a.length)
            .find((nome) => n.includes(normalizar(nome))) || "";
    }

    function extrairLote(frase) {
        const m = normalizar(frase).match(/\blote\s*(?:n[ºo°.]?\s*)?(\d+)\b/);
        return m ? Number(m[1]) : null;
    }

    function descreverLote(item) {
        const partes = [
            `Lote ${item.lote}`,
            item.cultivar ? `cultivar ${item.cultivar}` : "",
            `${formatarNumero(item.bags, 0)} bags`,
            item.fazenda ? `fazenda ${item.fazenda}` : "",
            item.talhao ? `talhão ${item.talhao}` : "",
            item.peneira ? `peneira ${item.peneira}` : ""
        ].filter(Boolean);
        return partes.join(" • ");
    }

    function ajuda() {
        return "Hoje eu consigo consultar o estoque e entender vários pedidos em português.\n\nVocê pode perguntar por cultivar, lote, fazenda e umidade. Também pode dizer algo como ‘saiu 10 bags do lote 25’ ou ‘entrou 5 bags no lote 25’. Antes de alterar o estoque eu sempre mostro o que vou fazer e peço confirmação.";
    }

    // seedcontrol-assistente-entendimento-amplo-v384
    function distanciaEdicao(a, b) {
        a = normalizar(a);
        b = normalizar(b);
        if (a === b) return 0;
        if (!a.length) return b.length;
        if (!b.length) return a.length;

        const anterior = Array.from({ length: b.length + 1 }, (_, i) => i);
        const atual = new Array(b.length + 1);

        for (let i = 1; i <= a.length; i++) {
            atual[0] = i;
            for (let j = 1; j <= b.length; j++) {
                const custo = a[i - 1] === b[j - 1] ? 0 : 1;
                atual[j] = Math.min(
                    atual[j - 1] + 1,
                    anterior[j] + 1,
                    anterior[j - 1] + custo
                );
            }
            for (let j = 0; j <= b.length; j++) anterior[j] = atual[j];
        }
        return anterior[b.length];
    }

    function palavras(frase) {
        return normalizar(frase)
            .replace(/[^a-z0-9\s]/g, ' ')
            .split(/\s+/)
            .filter(Boolean);
    }

    function entidadeMencionadaAmpla(frase, estoque, campo) {
        const n = normalizar(frase);
        const tokens = palavras(frase);
        const nomes = [...new Set(
            estoque.map((x) => String(x && x[campo] || '').trim()).filter(Boolean)
        )].sort((a, b) => b.length - a.length);

        const direta = nomes.find((nome) => n.includes(normalizar(nome)));
        if (direta) return direta;

        let melhor = '';
        let melhorDist = 99;

        for (const nome of nomes) {
            const alvo = normalizar(nome);
            if (alvo.length < 5 || alvo.includes(' ')) continue;

            for (const token of tokens) {
                if (token.length < 4) continue;
                const dist = distanciaEdicao(token, alvo);
                const limite = alvo.length >= 9 ? 2 : 1;
                if (dist <= limite && dist < melhorDist) {
                    melhor = nome;
                    melhorDist = dist;
                }
            }
        }

        return melhor;
    }

    function cultivarMencionadaAmpla(frase, estoque) {
        return entidadeMencionadaAmpla(frase, estoque, 'cultivar');
    }

    function fazendaMencionadaAmpla(frase, estoque) {
        return entidadeMencionadaAmpla(frase, estoque, 'fazenda');
    }

    function numeroPorExtensoPt(trecho) {
        const t = palavras(trecho);
        if (!t.length) return null;

        const unidades = {
            zero: 0, um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4,
            cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10,
            onze: 11, doze: 12, treze: 13, quatorze: 14, catorze: 14,
            quinze: 15, dezesseis: 16, dezassete: 17, dezessete: 17,
            dezoito: 18, dezenove: 19
        };
        const dezenas = {
            vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50,
            sessenta: 60, setenta: 70, oitenta: 80, noventa: 90
        };
        const centenas = {
            cem: 100, cento: 100, duzentos: 200, trezentos: 300,
            quatrocentos: 400, quinhentos: 500, seiscentos: 600,
            setecentos: 700, oitocentos: 800, novecentos: 900
        };

        let total = 0;
        let encontrou = false;
        for (const token of t) {
            if (token === 'e') continue;
            if (Object.prototype.hasOwnProperty.call(unidades, token)) {
                total += unidades[token];
                encontrou = true;
                continue;
            }
            if (Object.prototype.hasOwnProperty.call(dezenas, token)) {
                total += dezenas[token];
                encontrou = true;
                continue;
            }
            if (Object.prototype.hasOwnProperty.call(centenas, token)) {
                total += centenas[token];
                encontrou = true;
                continue;
            }
            if (encontrou) break;
        }
        return encontrou ? total : null;
    }

    function extrairLoteAmplo(frase) {
        const direto = extrairLote(frase);
        if (direto != null) return direto;

        const n = normalizar(frase);
        const m = n.match(/\blote\s+(?:numero\s+)?([a-z\s-]{1,45})/);
        if (!m) return null;
        return numeroPorExtensoPt(m[1]);
    }

    function extrairQuantidadeAmpla(frase) {
        const n = normalizar(frase);
        const numerico = n.match(/(\d+(?:[.,]\d+)?)\s*(?:bags?|bagui?s?|begs?|beques?)/)
            || n.match(/(?:saiu|saida|retirou|retirar|tirou|tirar|baixou|baixar|descontou|descontar|entrou|entrada|recebeu|recebi|chegou|chegaram|adicionar|acrescentar|somar|colocar|coloca|poe|veio)\D{0,22}(\d+(?:[.,]\d+)?)/);
        if (numerico) return numero(numerico[1]);

        const antesBag = n.match(/([a-z\s-]{1,45})\s+(?:bags?|bagui?s?|begs?|beques?)\b/);
        if (antesBag) {
            const palavrasTrecho = palavras(antesBag[1]);
            const ultimas = palavrasTrecho.slice(-5).join(' ');
            const extenso = numeroPorExtensoPt(ultimas);
            if (extenso != null) return extenso;
        }

        return 0;
    }

    function mensagensUsuarioAnteriores(fraseAtual) {
        const atual = normalizar(fraseAtual);
        const lista = [];
        let pulouAtual = false;

        for (let i = mensagens.length - 1; i >= 0 && lista.length < 8; i--) {
            const m = mensagens[i];
            if (!m || m.tipo !== 'usuario') continue;
            const t = String(m.texto || '');
            if (!pulouAtual && normalizar(t) === atual) {
                pulouAtual = true;
                continue;
            }
            lista.push(t);
        }
        return lista;
    }

    function contextoAnterior(frase, estoque) {
        const anteriores = mensagensUsuarioAnteriores(frase);
        const contexto = {
            lote: null,
            cultivar: '',
            fazenda: '',
            quantidade: false,
            localizacao: false,
            umidade: false
        };

        for (const anterior of anteriores) {
            const n = normalizar(anterior);
            if (contexto.lote == null) contexto.lote = extrairLoteAmplo(anterior);
            if (!contexto.cultivar) contexto.cultivar = cultivarMencionadaAmpla(anterior, estoque);
            if (!contexto.fazenda) contexto.fazenda = fazendaMencionadaAmpla(anterior, estoque);
            if (!contexto.quantidade && /(quant|quanto|total|bags?|estoque|saldo|sobrou|sobra|restou|resta|tem|tenho|disponivel)/.test(n)) contexto.quantidade = true;
            if (!contexto.localizacao && /(onde|local|fica|esta|localiza)/.test(n)) contexto.localizacao = true;
            if (!contexto.umidade && /umidade/.test(n)) contexto.umidade = true;

            if (contexto.lote != null && contexto.cultivar && contexto.fazenda && contexto.quantidade) break;
        }
        return contexto;
    }

    function temUnidadeForaDoSeedControl(n) {
        return /\b(megas?|megabytes?|gigas?|gigabytes?|mb|gb|reais?|dinheiro|pix|km|quilometros?|litros?|horas?|minutos?|celular|internet|dados moveis)\b/.test(n);
    }

    function parecePerguntaQuantidade(n) {
        if (temUnidadeForaDoSeedControl(n)) return false;
        if (/(bags?|bagui?s?|begs?|beques?|estoque|saldo|sobra|sobrou|resta|restou|disponivel|quantidade)/.test(n)) return true;
        if (/(quanto|quantos|qual.*total|me fala.*total|tem quanto|quanto tem)/.test(n) && !/[a-z]+bytes?/.test(n)) return true;
        return false;
    }

    function fraseDeContinuacao(n) {
        return /^(e\b|e da\b|e do\b|e na\b|e no\b|e esse\b|e essa\b|e dele\b|e dela\b|e agora\b|quanto dele\b|quanto dela\b)/.test(n)
            || /\b(desse|dessa|deste|desta|dele|dela|o mesmo|a mesma)\b/.test(n);
    }

    function interpretarConsulta(frase) {
        const estoque = estoqueAtual();
        const n = normalizar(frase);
        const contexto = contextoAnterior(frase, estoque);

        if (!estoque.length && !/(ajuda|consegue|pode fazer|ola|oi|bom dia|boa tarde|boa noite)/.test(n)) {
            return 'Ainda não encontrei lotes cadastrados no estoque deste aparelho.';
        }

        if (/^(oi|ola|opa|e ai|bom dia|boa tarde|boa noite)\b/.test(n)) {
            return 'Olá! Pode falar comigo normalmente. Eu entendo perguntas sobre estoque, bags, cultivares, lotes, fazendas e umidade, e também lembro o assunto das mensagens anteriores.';
        }

        if (/(o que.*consegue|o que.*faz|ajuda|comandos|como usar|como funciona|entende o que)/.test(n)) {
            return 'Posso consultar estoque total, bags por cultivar ou fazenda, localizar lotes, listar cultivares e fazendas, verificar umidade e preparar entradas ou saídas de bags. Você também pode continuar o assunto: “quanto tem da Guepardo?” e depois só perguntar “e da Voraz?”. Alterações sempre pedem confirmação.';
        }

        const continuar = fraseDeContinuacao(n);
        let loteNumero = extrairLoteAmplo(frase);
        let cultivar = cultivarMencionadaAmpla(frase, estoque);
        let fazenda = fazendaMencionadaAmpla(frase, estoque);

        if (continuar) {
            if (loteNumero == null) loteNumero = contexto.lote;
            if (!cultivar) cultivar = contexto.cultivar;
            if (!fazenda) fazenda = contexto.fazenda;
        }

        const querQuantidade = parecePerguntaQuantidade(n) || (continuar && contexto.quantidade);
        const querLocalizacao = /(onde|local|fica|esta|localiza|encontra|qual fazenda|qual talhao)/.test(n) || (continuar && contexto.localizacao);

        if (loteNumero != null && (querLocalizacao || querQuantidade || /\blote\b/.test(n) || continuar)) {
            const encontrados = estoque.filter((x) => Number(x.lote) === loteNumero);
            if (!encontrados.length) return `Não encontrei o lote ${loteNumero}.`;
            if (encontrados.length === 1) return descreverLote(encontrados[0]) + '.';
            return `Encontrei ${encontrados.length} registros com o lote ${loteNumero}:\n` + encontrados.map((x) => '• ' + descreverLote(x)).join('\n');
        }

        if (cultivar && querQuantidade) {
            const itens = estoque.filter((x) => normalizar(x.cultivar) === normalizar(cultivar));
            const bags = itens.reduce((s, x) => s + numero(x.bags), 0);
            return `${cultivar}: ${formatarNumero(bags, 0)} bags em ${itens.length} lote${itens.length === 1 ? '' : 's'}.`;
        }

        if (fazenda && querQuantidade) {
            const itens = estoque.filter((x) => normalizar(x.fazenda) === normalizar(fazenda));
            const bags = itens.reduce((s, x) => s + numero(x.bags), 0);
            return `Na fazenda ${fazenda} há ${formatarNumero(bags, 0)} bags em ${itens.length} lote${itens.length === 1 ? '' : 's'}.`;
        }

        if (cultivar && querLocalizacao) {
            const itens = estoque.filter((x) => normalizar(x.cultivar) === normalizar(cultivar));
            if (!itens.length) return `Não encontrei a cultivar ${cultivar}.`;
            return `${cultivar} aparece em ${itens.length} lote${itens.length === 1 ? '' : 's'}:\n` + itens.slice(0, 20).map((x) => '• ' + descreverLote(x)).join('\n');
        }

        const umidadeNum = n.match(/umidade.*?(?:acima de|maior que|>|mais de)\s*(\d+(?:[.,]\d+)?)/);
        let limiteUmidade = umidadeNum ? numero(umidadeNum[1]) : null;
        if (limiteUmidade == null && /umidade/.test(n)) {
            const trecho = n.match(/(?:acima de|maior que|mais de)\s+([a-z\s-]{1,35})/);
            if (trecho) limiteUmidade = numeroPorExtensoPt(trecho[1]);
        }
        if (limiteUmidade != null) {
            const itens = estoque.filter((x) => numero(x.umidade) > limiteUmidade);
            if (!itens.length) return `Não encontrei lotes com umidade acima de ${formatarNumero(limiteUmidade, 1)}%.`;
            return `${itens.length} lote${itens.length === 1 ? '' : 's'} com umidade acima de ${formatarNumero(limiteUmidade, 1)}%:\n` +
                itens.slice(0, 20).map((x) => `• Lote ${x.lote} • ${x.cultivar || 'Sem cultivar'} • ${formatarNumero(x.umidade, 1)}%`).join('\n') +
                (itens.length > 20 ? `\n… e mais ${itens.length - 20}.` : '');
        }

        if (/(quais|lista|mostrar|mostra).*(cultivar|variedade)|cultivares.*tenho/.test(n)) {
            const mapa = new Map();
            estoque.forEach((x) => {
                const nome = String(x.cultivar || 'Sem cultivar').trim() || 'Sem cultivar';
                mapa.set(nome, (mapa.get(nome) || 0) + numero(x.bags));
            });
            return `${mapa.size} cultivares:\n` + [...mapa.entries()].sort((a,b) => b[1] - a[1]).map(([nome, bags]) => `• ${nome}: ${formatarNumero(bags, 0)} bags`).join('\n');
        }

        if (/(quais|lista|mostrar|mostra).*(fazenda)|fazendas.*tenho/.test(n)) {
            const mapa = new Map();
            estoque.forEach((x) => {
                const nome = String(x.fazenda || 'Sem fazenda').trim() || 'Sem fazenda';
                mapa.set(nome, (mapa.get(nome) || 0) + numero(x.bags));
            });
            return `${mapa.size} fazendas:\n` + [...mapa.entries()].sort((a,b) => b[1] - a[1]).map(([nome, bags]) => `• ${nome}: ${formatarNumero(bags, 0)} bags`).join('\n');
        }

        if (/(quant.*lote|total.*lote|lotes.*tenho)/.test(n)) {
            return `Há ${estoque.length} lotes cadastrados no estoque.`;
        }

        if (querQuantidade) {
            const bags = estoque.reduce((s, x) => s + numero(x.bags), 0);
            const cultivares = new Set(estoque.map((x) => normalizar(x.cultivar)).filter(Boolean)).size;
            return `O estoque tem ${formatarNumero(bags, 0)} bags, distribuídas em ${estoque.length} lotes e ${cultivares} cultivares.`;
        }

        return 'Ainda não entendi esse pedido com segurança. Pode falar de outro jeito ou citar o lote, cultivar, fazenda, bags, estoque ou umidade.';
    }

    function detectarMovimento(frase) {
        const n = normalizar(frase);
        const estoque = estoqueAtual();
        const contexto = contextoAnterior(frase, estoque);
        let tipo = null;

        const saida = /\b(saiu|saida|retirou|retirar|tirou|tirar|baixou|baixar|baixa|descontou|descontar|despachou|despachei|mandou|mandei|enviou|enviei|carregou|carreguei)\b/;
        const entrada = /\b(entrou|entrada|recebeu|recebi|chegou|chegaram|adicionar|adiciona|acrescentar|somar|soma|colocar|coloca|poe|veio|vieram)\b/;

        if (saida.test(n)) tipo = 'saida';
        if (entrada.test(n)) tipo = 'entrada';
        if (!tipo) return null;

        let lote = extrairLoteAmplo(frase);
        let qtd = extrairQuantidadeAmpla(frase);
        let cultivar = cultivarMencionadaAmpla(frase, estoque);
        let fazenda = fazendaMencionadaAmpla(frase, estoque);

        const referenciaContextual = /\b(dele|dela|desse|dessa|deste|desta|mesmo|mesma)\b/.test(n) || !/\blote\b/.test(n);
        if (referenciaContextual) {
            if (lote == null) lote = contexto.lote;
            if (!cultivar) cultivar = contexto.cultivar;
            if (!fazenda) fazenda = contexto.fazenda;
        }

        if (qtd <= 0) {
            return { erro: 'Para movimentar, preciso da quantidade de bags. Exemplo: “Saiu 10 bags do lote 25”.' };
        }

        let candidatos = estoque.slice();
        if (lote != null) candidatos = candidatos.filter((x) => Number(x.lote) === lote);
        if (cultivar) candidatos = candidatos.filter((x) => normalizar(x.cultivar) === normalizar(cultivar));
        if (fazenda) candidatos = candidatos.filter((x) => normalizar(x.fazenda) === normalizar(fazenda));

        if (lote == null && !cultivar && !fazenda) {
            return { erro: 'Entendi a movimentação e a quantidade, mas preciso saber de qual lote, cultivar ou fazenda você está falando.' };
        }

        if (!candidatos.length) {
            const alvo = lote != null ? `lote ${lote}` : (cultivar || fazenda || 'registro informado');
            return { erro: `Não encontrei ${alvo} com essas informações.` };
        }

        if (candidatos.length > 1) {
            return {
                erro: `Encontrei mais de um registro possível. Diga também o lote, cultivar ou fazenda para eu saber qual movimentar.\n` +
                    candidatos.slice(0, 10).map((x) => '• ' + descreverLote(x)).join('\n')
            };
        }

        const item = candidatos[0];
        const atual = numero(item.bags);
        const depois = tipo === 'saida' ? atual - qtd : atual + qtd;

        if (tipo === 'saida' && depois < 0) {
            return { erro: `Esse lote tem ${formatarNumero(atual, 0)} bags. Não posso retirar ${formatarNumero(qtd, 0)} porque o estoque ficaria negativo.` };
        }

        return { tipo, qtd, item, atual, depois };
    }

    function pedirConfirmacao(mov) {
        movimentoPendente = {
            tipo: mov.tipo,
            qtd: mov.qtd,
            lote: Number(mov.item.lote),
            id: mov.item.id == null ? null : mov.item.id,
            cultivar: mov.item.cultivar || "",
            fazenda: mov.item.fazenda || "",
            atual: mov.atual,
            depois: mov.depois
        };

        const verbo = mov.tipo === "saida" ? "RETIRAR" : "ADICIONAR";
        const texto = `${verbo} ${formatarNumero(mov.qtd, 0)} bags do lote ${mov.item.lote} (${mov.item.cultivar || "sem cultivar"})?\nEstoque: ${formatarNumero(mov.atual, 0)} → ${formatarNumero(mov.depois, 0)} bags.`;
        adicionar("assistente", texto, { confirmacao: true });
    }

    function confirmarMovimento() {
        if (!movimentoPendente) {
            adicionar("assistente", "Não há nenhuma movimentação aguardando confirmação.");
            return;
        }

        const pend = movimentoPendente;
        const estoque = estoqueAtual();
        let indice = -1;

        if (pend.id != null) indice = estoque.findIndex((x) => String(x.id) === String(pend.id));
        if (indice < 0) {
            indice = estoque.findIndex((x) =>
                Number(x.lote) === pend.lote &&
                normalizar(x.cultivar) === normalizar(pend.cultivar) &&
                normalizar(x.fazenda) === normalizar(pend.fazenda)
            );
        }

        if (indice < 0) {
            movimentoPendente = null;
            adicionar("assistente", "O lote mudou ou não existe mais. Não fiz nenhuma alteração.");
            return;
        }

        const item = estoque[indice];
        const antes = numero(item.bags);
        const depois = pend.tipo === "saida" ? antes - pend.qtd : antes + pend.qtd;

        if (pend.tipo === "saida" && depois < 0) {
            movimentoPendente = null;
            adicionar("assistente", "O estoque desse lote mudou e agora a saída deixaria o valor negativo. Não fiz a alteração.");
            return;
        }

        item.bags = depois;
        salvarBase(estoque);
        salvarHistoricoMovimento(item, pend.tipo, pend.qtd, antes, depois);
        movimentoPendente = null;

        adicionar(
            "assistente",
            `Pronto. ${pend.tipo === "saida" ? "Saída" : "Entrada"} registrada: ${formatarNumero(pend.qtd, 0)} bags no lote ${item.lote}. Saldo atual: ${formatarNumero(depois, 0)} bags.`
        );
    }

    function cancelarMovimento() {
        if (!movimentoPendente) return;
        movimentoPendente = null;
        adicionar("assistente", "Movimentação cancelada. Nenhum dado foi alterado.");
    }

    async function processar(texto) {
        const frase = String(texto || "").trim();
        if (!frase) return;

        adicionar("usuario", frase);
        setStatus("Consultando dados do SeedControl…", false);

        await new Promise((r) => setTimeout(r, 90));

        const n = normalizar(frase);
        if (movimentoPendente && /^(confirmar|confirma|sim|pode|pode fazer|ok|certo)$/i.test(n)) {
            confirmarMovimento();
            setStatus("Pronto para conversar", false);
            return;
        }
        if (movimentoPendente && /^(cancelar|cancela|nao|não|deixa|parar)$/i.test(n)) {
            cancelarMovimento();
            setStatus("Pronto para conversar", false);
            return;
        }

        const mov = detectarMovimento(frase);
        if (mov) {
            if (mov.erro) adicionar("assistente", mov.erro);
            else pedirConfirmacao(mov);
        } else {
            adicionar("assistente", interpretarConsulta(frase));
        }

        setStatus("Pronto para conversar", false);
    }

    function autoAltura() {
        const entrada = $("assistenteEntrada");
        if (!entrada) return;
        entrada.style.height = "auto";
        entrada.style.height = Math.min(116, entrada.scrollHeight) + "px";
    }

    async function enviarEntrada() {
        const entrada = $("assistenteEntrada");
        if (!entrada) return;
        const texto = entrada.value.trim();
        if (!texto) return;
        entrada.value = "";
        autoAltura();
        await processar(texto);
    }

    function pluginVoz() {
        return window.Capacitor && window.Capacitor.Plugins
            ? window.Capacitor.Plugins.SpeechRecognition
            : null;
    }

    async function ouvirComPlugin() {
        const speech = pluginVoz();
        if (!speech) return false;

        try {
            const permissao = await speech.requestPermissions();
            if (permissao && permissao.speechRecognition === "denied") {
                throw new Error("Permissão do microfone negada.");
            }

            const disp = await speech.available();
            if (!disp || disp.available !== true) {
                throw new Error("Reconhecimento de voz não disponível neste aparelho.");
            }

            setStatus("Ouvindo… fale normalmente", true);
            ouvindo = true;
            $("btnMicrofoneAssistente")?.classList.add("ouvindo");

            const resultado = await speech.start({
                language: "pt-BR",
                maxResults: 3,
                partialResults: false,
                popup: false
            });

            const texto = resultado && Array.isArray(resultado.matches)
                ? String(resultado.matches[0] || "").trim()
                : "";

            if (texto) {
                const entrada = $("assistenteEntrada");
                if (entrada) {
                    entrada.value = texto;
                    autoAltura();
                }
                await enviarEntrada();
            } else {
                setStatus("Não consegui entender. Toque no microfone e tente novamente.", false);
            }
            return true;
        } catch (erro) {
            console.warn("SpeechRecognition:", erro);
            setStatus(erro && erro.message ? erro.message : "Não foi possível usar o microfone.", false);
            return true;
        } finally {
            ouvindo = false;
            $("btnMicrofoneAssistente")?.classList.remove("ouvindo");
        }
    }

    async function ouvirComWebSpeech() {
        const Classe = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!Classe) return false;

        return new Promise((resolve) => {
            const rec = new Classe();
            rec.lang = "pt-BR";
            rec.interimResults = false;
            rec.maxAlternatives = 3;

            ouvindo = true;
            $("btnMicrofoneAssistente")?.classList.add("ouvindo");
            setStatus("Ouvindo… fale normalmente", true);

            rec.onresult = async (evento) => {
                const texto = evento.results && evento.results[0] && evento.results[0][0]
                    ? String(evento.results[0][0].transcript || "").trim()
                    : "";
                if (texto) {
                    const entrada = $("assistenteEntrada");
                    if (entrada) entrada.value = texto;
                    await enviarEntrada();
                }
            };

            rec.onerror = () => setStatus("Não foi possível reconhecer a fala.", false);
            rec.onend = () => {
                ouvindo = false;
                $("btnMicrofoneAssistente")?.classList.remove("ouvindo");
                resolve(true);
            };
            rec.start();
        });
    }

    async function iniciarVoz() {
        if (ouvindo) return;
        const nativo = await ouvirComPlugin();
        if (nativo) return;
        const web = await ouvirComWebSpeech();
        if (web) return;
        setStatus("Reconhecimento de voz indisponível nesta versão do aparelho.", false);
    }

    function instalarEventos() {
        $("btnVoltarAssistente")?.addEventListener("click", () => {
            window.location.href = "index.html";
        });

        $("btnLimparConversa")?.addEventListener("click", () => {
            if (!confirm("Limpar a conversa do Assistente?")) return;
            mensagens = [];
            movimentoPendente = null;
            localStorage.removeItem(CHAVE_CONVERSA);
            restaurarConversa();
        });

        $("btnEnviarAssistente")?.addEventListener("click", enviarEntrada);
        $("btnMicrofoneAssistente")?.addEventListener("click", iniciarVoz);

        const entrada = $("assistenteEntrada");
        entrada?.addEventListener("input", autoAltura);
        entrada?.addEventListener("keydown", (evento) => {
            if (evento.key === "Enter" && !evento.shiftKey) {
                evento.preventDefault();
                enviarEntrada();
            }
        });

        $("assistenteSugestoes")?.addEventListener("click", (evento) => {
            const botao = evento.target.closest("[data-pergunta]");
            if (botao) processar(botao.dataset.pergunta || "");
        });

        $("assistenteMensagens")?.addEventListener("click", (evento) => {
            if (evento.target.closest("[data-confirmar-movimento]")) confirmarMovimento();
            if (evento.target.closest("[data-cancelar-movimento]")) cancelarMovimento();
        });
    }

    function iniciar() {
        instalarEventos();
        restaurarConversa();
        autoAltura();
        setStatus("Pronto para conversar", false);
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar);
    else iniciar();
})();


// seedcontrol-assistente-rodape-safe-v384
(function () {
    "use strict";

    function atualizarAreaVisivel() {
        const vv = window.visualViewport;
        const alturaJanela = window.innerHeight || document.documentElement.clientHeight || 0;
        const alturaVisivel = vv ? vv.height : alturaJanela;
        const diferenca = Math.max(0, alturaJanela - alturaVisivel);
        const tecladoAberto = diferenca > 140;

        document.body.classList.toggle("seed-assistente-teclado-aberto", tecladoAberto);
        document.documentElement.style.setProperty(
            "--seed-assistente-altura-visivel",
            Math.max(320, Math.round(alturaVisivel)) + "px"
        );

        if (tecladoAberto) {
            const campo = document.getElementById("assistenteEntrada");
            if (campo === document.activeElement) {
                setTimeout(function () {
                    try { campo.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (_) {}
                }, 60);
            }
        }
    }

    function iniciarRodapeSeguro() {
        atualizarAreaVisivel();
        window.addEventListener("resize", atualizarAreaVisivel, { passive: true });
        window.addEventListener("orientationchange", atualizarAreaVisivel, { passive: true });
        if (window.visualViewport) {
            window.visualViewport.addEventListener("resize", atualizarAreaVisivel, { passive: true });
            window.visualViewport.addEventListener("scroll", atualizarAreaVisivel, { passive: true });
        }

        const campo = document.getElementById("assistenteEntrada");
        if (campo) {
            campo.addEventListener("focus", function () {
                setTimeout(atualizarAreaVisivel, 80);
            });
            campo.addEventListener("blur", function () {
                setTimeout(atualizarAreaVisivel, 80);
            });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", iniciarRodapeSeguro, { once: true });
    } else {
        iniciarRodapeSeguro();
    }
})();
