// SeedControl - teclado nativo e area de transferencia
(function () {
    "use strict";
    function preparar(campo) {
        if (!campo || campo.disabled || campo.readOnly) return;
        campo.setAttribute("inputmode", "text");
        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("spellcheck", "true");
        campo.style.userSelect = "text";
        campo.style.webkitUserSelect = "text";
    }
    function iniciar() {
        document.querySelectorAll("input, textarea, [contenteditable=true]").forEach(preparar);
        document.addEventListener("focusin", e => preparar(e.target), true);
        new MutationObserver(() => document.querySelectorAll("input, textarea, [contenteditable=true]").forEach(preparar)).observe(document.body, {childList:true, subtree:true});
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, {once:true}); else iniciar();
})();
