(function () {
    "use strict";
    const lista = document.getElementById("listaArquivos");
    function esc(v) { return String(v == null ? "" : v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
    function data(v) { try { return new Date(v).toLocaleString("pt-BR"); } catch (_) { return v || ""; } }
    async function abrir(item) {
        const fs = window.Capacitor?.Plugins?.Filesystem, share = window.Capacitor?.Plugins?.Share;
        if (!fs || !share) { alert("O componente de arquivos do Android não está disponível. Instale a nova versão do SeedControl."); return; }
        try { const r = item.externalUri ? { uri: item.externalUri } : await fs.getUri({ directory: item.directory || "DATA", path: item.path }); await share.share({ title: item.nome, text: "Arquivo salvo em Downloads/SeedControl.", url: r.uri, dialogTitle: "Abrir arquivo" }); }
        catch (e) { alert("Não foi possível abrir o arquivo. " + (e.message || e)); }
    }
    function render() {
        const itens = window.SeedControlArquivos?.listar?.() || [];
        if (!itens.length) { lista.innerHTML = '<div class="card"><h2>📂 Nenhum arquivo gerado ainda</h2><p>Gere um PDF ou Excel em Relatório de Saídas ou Relatórios.</p></div>'; return; }
        lista.innerHTML = itens.map((item, i) => '<div class="card"><h2>' + (item.tipo === "PDF" ? "📕" : "📗") + ' ' + esc(item.tipo) + '</h2><p><strong>Arquivo:</strong> ' + esc(item.nome) + '</p><p><strong>Gerado em:</strong> ' + esc(data(item.criadoEm)) + '</p><button type="button" data-abrir="' + i + '">👁️ Visualizar / Salvar no celular</button> <button type="button" data-remover="' + i + '">🗑️ Remover da lista</button></div>').join("");
        lista.querySelectorAll("[data-abrir]").forEach(b => b.onclick = () => abrir(itens[Number(b.dataset.abrir)]));
        lista.querySelectorAll("[data-remover]").forEach(b => b.onclick = () => { window.SeedControlArquivos.remover(itens[Number(b.dataset.remover)].path); render(); });
    }
    render();
})();
