// SeedControl v3.8.4 - armazenamento interno sem permissao externa
(function () {
    "use strict";
    const META_KEY = "seedcontrol:arquivos-relatorios:v384";
    function metas() { try { const v = JSON.parse(localStorage.getItem(META_KEY) || "[]"); return Array.isArray(v) ? v : []; } catch (_) { return []; } }
    function guardarMetas(lista) { localStorage.setItem(META_KEY, JSON.stringify(lista.slice(0, 100))); }
    function registrar(opcoes, resultado) {
        const path = String(opcoes.path || "");
        const nome = path.split("/").pop();
        if (!nome || !/\.(pdf|xlsx?|csv)$/i.test(nome)) return;
        const lista = metas().filter(x => x.path !== opcoes.path);
        lista.unshift({ nome, path: opcoes.path, directory: opcoes.directory || "DATA", uri: resultado && resultado.uri || "", criadoEm: new Date().toISOString(), tipo: /\.pdf$/i.test(nome) ? "PDF" : "Excel/Planilha" });
        guardarMetas(lista);
    }
    window.SeedControlArquivos = {
        listar: metas,
        remover: function (path) { guardarMetas(metas().filter(x => x.path !== path)); },
        registrar
    };
    function instalar() {
        const fs = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Filesystem;
        if (!fs || fs.__seedcontrolStorageV384) return;
        const original = fs.writeFile.bind(fs);
        fs.writeFile = async function (opcoes) {
            const entrada = { ...(opcoes || {}) };
            const nome = String(entrada.path || "").split("/").pop();
            if (String(entrada.directory || "").toUpperCase() === "DOCUMENTS") {
                // DATA não exige MANAGE_EXTERNAL_STORAGE e funciona no Android moderno.
                entrada.path = "SeedControl/Arquivos/" + nome;
                entrada.directory = "DATA";
                entrada.recursive = true;
            }
            const resultado = await original(entrada);
            registrar(entrada, resultado);
            return resultado;
        };
        fs.__seedcontrolStorageV384 = true;
    }
    instalar();
    setTimeout(instalar, 0);
})();
