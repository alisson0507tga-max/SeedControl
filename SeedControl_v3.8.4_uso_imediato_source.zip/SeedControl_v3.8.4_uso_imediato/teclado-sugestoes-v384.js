// seedcontrol-teclado-sugestoes-v384
(function () {
    "use strict";

    function prepararCampo(campo) {
        if (!campo || campo.disabled || campo.readOnly) return;
        if (campo.tagName !== "INPUT" && campo.tagName !== "TEXTAREA") return;

        const tipo = String(campo.type || "text").toLowerCase();
        const textuais = ["text", "search", "email", "url", "tel"];

        if (campo.tagName === "INPUT" && !textuais.includes(tipo)) return;

        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("spellcheck", "true");
        campo.setAttribute("autocapitalize", "sentences");

        if (campo.tagName === "INPUT" && (tipo === "text" || tipo === "search")) {
            campo.setAttribute("inputmode", "text");
        }

        // No Assistente, reforça explicitamente o comportamento de texto normal
        // para o Android/WebView oferecer a faixa de sugestões do teclado.
        if (campo.id === "assistenteEntrada") {
            campo.setAttribute("autocomplete", "on");
            campo.setAttribute("autocorrect", "on");
            campo.setAttribute("spellcheck", "true");
            campo.setAttribute("autocapitalize", "sentences");
            campo.setAttribute("inputmode", "text");
        }
    }

    function prepararTodos() {
        document.querySelectorAll('input, textarea').forEach(prepararCampo);
    }

    function iniciar() {
        prepararTodos();

        document.addEventListener("focusin", function (evento) {
            prepararCampo(evento.target);
        }, true);

        const observador = new MutationObserver(prepararTodos);
        observador.observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", iniciar, { once: true });
    } else {
        iniciar();
    }
})();
