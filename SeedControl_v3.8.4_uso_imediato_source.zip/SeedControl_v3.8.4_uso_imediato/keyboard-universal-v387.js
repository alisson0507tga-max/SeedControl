// SeedControl v3.8.7 - teclado de texto e colagem em todas as telas
(function () {
    "use strict";
    function preparar(campo) {
        if (!campo || campo.disabled || campo.readOnly) return;
        if (campo.tagName !== "INPUT" && campo.tagName !== "TEXTAREA") return;
        const tipo = String(campo.type || "text").toLowerCase();
        if (campo.tagName === "INPUT" && ["file", "checkbox", "radio", "button", "submit", "reset", "color", "range", "date", "datetime-local", "time"].includes(tipo)) return;
        if (campo.tagName === "INPUT" && tipo === "number") campo.type = "text";
        campo.setAttribute("inputmode", "text");
        campo.setAttribute("autocomplete", "on");
        campo.setAttribute("autocorrect", "on");
        campo.setAttribute("spellcheck", "true");
        campo.setAttribute("autocapitalize", "sentences");
    }
    function colar(campo) {
        const clip = window.Capacitor?.Plugins?.Clipboard;
        const ler = clip?.read ? clip.read().then(r => r?.value || "") : navigator.clipboard?.readText?.();
        Promise.resolve(ler).then(function (texto) {
            if (!texto) return;
            const inicio = campo.selectionStart ?? campo.value.length;
            const fim = campo.selectionEnd ?? inicio;
            campo.setRangeText(String(texto), inicio, fim, "end");
            campo.dispatchEvent(new Event("input", { bubbles: true }));
        }).catch(function () {});
    }
    function iniciar() {
        document.querySelectorAll("input, textarea").forEach(preparar);
        document.addEventListener("focusin", e => preparar(e.target), true);
        document.addEventListener("contextmenu", function (e) {
            if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) preparar(e.target);
        }, true);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar, { once: true }); else iniciar();
    window.SeedControlColar = colar;
})();
