// seedcontrol-cadastro-nota-v384
(function () {
    "use strict";

    let fotoNotaAtual = "";

    function valor(id) {
        const el = document.getElementById(id);
        return el ? String(el.value || "").trim() : "";
    }

    function normalizar(v) {
        return String(v == null ? "" : v).trim().toLowerCase();
    }

    function mesmoLote(item) {
        if (!item) return false;

        return (
            normalizar(item.cultivar) === normalizar(valor("cultivar")) &&
            normalizar(item.lote) === normalizar(valor("lote")) &&
            normalizar(item.fazenda) === normalizar(valor("fazenda")) &&
            normalizar(item.peneira) === normalizar(valor("peneira")) &&
            normalizar(item.talhao) === normalizar(valor("talhao"))
        );
    }

    function comprimirImagem(arquivo) {
        return new Promise(function (resolve, reject) {
            if (!arquivo || !arquivo.type || !arquivo.type.startsWith("image/")) {
                reject(new Error("Selecione uma imagem válida."));
                return;
            }

            const leitor = new FileReader();

            leitor.onerror = function () {
                reject(new Error("Não foi possível ler a foto."));
            };

            leitor.onload = function () {
                const imagem = new Image();

                imagem.onerror = function () {
                    reject(new Error("Não foi possível abrir a foto."));
                };

                imagem.onload = function () {
                    const limite = 2000;
                    let largura = imagem.naturalWidth || imagem.width;
                    let altura = imagem.naturalHeight || imagem.height;

                    if (largura > limite || altura > limite) {
                        const escala = Math.min(limite / largura, limite / altura);
                        largura = Math.max(1, Math.round(largura * escala));
                        altura = Math.max(1, Math.round(altura * escala));
                    }

                    const canvas = document.createElement("canvas");
                    canvas.width = largura;
                    canvas.height = altura;

                    const ctx = canvas.getContext("2d", { alpha: false });
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = "high";
                    ctx.fillStyle = "#ffffff";
                    ctx.fillRect(0, 0, largura, altura);
                    ctx.drawImage(imagem, 0, 0, largura, altura);

                    let resultado = canvas.toDataURL("image/jpeg", 0.86);
                    if (resultado.length > 1400000) {
                        resultado = canvas.toDataURL("image/jpeg", 0.74);
                    }

                    resolve(resultado);
                };

                imagem.src = String(leitor.result || "");
            };

            leitor.readAsDataURL(arquivo);
        });
    }

    function atualizarPreview() {
        const bloco = document.getElementById("notaPreviewV384");
        const img = document.getElementById("notaPreviewImgV384");
        if (!bloco || !img) return;

        if (fotoNotaAtual) {
            img.src = fotoNotaAtual;
            bloco.classList.add("ativo");
        } else {
            img.removeAttribute("src");
            bloco.classList.remove("ativo");
        }
    }

    async function receberArquivo(arquivo) {
        try {
            fotoNotaAtual = await comprimirImagem(arquivo);
            atualizarPreview();
        } catch (erro) {
            alert(erro && erro.message ? erro.message : "Não foi possível adicionar a foto.");
        }
    }

    function criarAreaNota() {
        const salvar = document.getElementById("salvar");
        if (!salvar || document.getElementById("notaEntradaV384")) return;

        const bloco = document.createElement("section");
        bloco.id = "notaEntradaV384";
        bloco.className = "nota-entrada-v384";
        bloco.innerHTML = `
            <div class="nota-titulo">📄 Nota de entrada <small style="font-size:11px;color:#91a3aa;font-weight:600">(opcional)</small></div>
            <p class="nota-subtitulo">Anexe a foto da nota recebida com a semente. A imagem será vinculada a este lote e incluída no backup.</p>
            <div class="nota-acoes-v384">
                <button type="button" id="btnNotaCameraV384">📷 Tirar foto</button>
                <button type="button" id="btnNotaGaleriaV384">🖼️ Galeria</button>
            </div>
            <input id="notaCameraV384" type="file" accept="image/*" capture="environment" hidden>
            <input id="notaGaleriaV384" type="file" accept="image/*" hidden>
            <div class="nota-preview-v384" id="notaPreviewV384">
                <img id="notaPreviewImgV384" alt="Prévia da nota de entrada">
                <div class="nota-preview-acoes-v384">
                    <span>✓ Foto anexada</span>
                    <button type="button" id="btnNotaRemoverV384">Remover</button>
                </div>
            </div>
        `;

        salvar.parentNode.insertBefore(bloco, salvar);

        const camera = document.getElementById("notaCameraV384");
        const galeria = document.getElementById("notaGaleriaV384");

        document.getElementById("btnNotaCameraV384").addEventListener("click", function () {
            camera.value = "";
            camera.click();
        });

        document.getElementById("btnNotaGaleriaV384").addEventListener("click", function () {
            galeria.value = "";
            galeria.click();
        });

        camera.addEventListener("change", function () {
            if (camera.files && camera.files[0]) receberArquivo(camera.files[0]);
        });

        galeria.addEventListener("change", function () {
            if (galeria.files && galeria.files[0]) receberArquivo(galeria.files[0]);
        });

        document.getElementById("btnNotaRemoverV384").addEventListener("click", function () {
            fotoNotaAtual = "";
            atualizarPreview();
        });
    }

    function protegerPersistenciaDaNota() {
        if (typeof window.salvarEstoque !== "function") return;
        if (window.salvarEstoque.__seedcontrolNotaV384) return;

        const original = window.salvarEstoque;

        function salvarComNota(lista) {
            if (fotoNotaAtual && Array.isArray(lista)) {
                for (let i = lista.length - 1; i >= 0; i -= 1) {
                    if (mesmoLote(lista[i])) {
                        lista[i].notaEntradaFoto = fotoNotaAtual;
                        lista[i].notaEntradaTipo = "image/jpeg";
                        lista[i].notaEntradaAtualizadaEm = new Date().toISOString();
                        break;
                    }
                }
            }

            return original(lista);
        }

        salvarComNota.__seedcontrolNotaV384 = true;
        window.salvarEstoque = salvarComNota;
    }

    function iniciar() {
        document.body.classList.add("cadastro-v384");
        criarAreaNota();
        protegerPersistenciaDaNota();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", iniciar);
    } else {
        iniciar();
    }
})();
