// seedcontrol-duplicidade-universal-v3902
(function () {
    "use strict";

    if (window.__seedcontrolDuplicidadeUniversalV3902) return;
    window.__seedcontrolDuplicidadeUniversalV3902 = true;

    let chaveOriginalEdicao = "";

    function normalizar(valor) {
        return String(valor == null ? "" : valor).trim().toLowerCase();
    }

    function normalizarLote(valor) {
        const texto = normalizar(valor);
        if (/^\d+$/.test(texto)) return String(Number(texto));
        return texto;
    }

    function chave(lote) {
        return [
            normalizar(lote && lote.cultivar),
            normalizarLote(lote && lote.lote),
            normalizar(lote && lote.fazenda),
            normalizar(lote && lote.peneira),
            normalizar(lote && lote.talhao)
        ].join("|");
    }

    function valoresFormulario() {
        return {
            cultivar: document.getElementById("cultivar")?.value || "",
            lote: document.getElementById("lote")?.value || "",
            fazenda: document.getElementById("fazenda")?.value || "",
            peneira: document.getElementById("peneira")?.value || "",
            talhao: document.getElementById("talhao")?.value || ""
        };
    }

    function formularioPreenchido() {
        const atual = valoresFormulario();
        return Boolean(String(atual.cultivar).trim() || String(atual.lote).trim());
    }

    function modoEdicao() {
        const botao = document.getElementById("salvar");
        const textoBotao = normalizar(botao && botao.textContent);
        const caminho = normalizar(window.location.pathname);
        const params = new URLSearchParams(window.location.search);

        return (
            caminho.includes("editar") ||
            textoBotao.includes("alter") ||
            params.has("editar") ||
            params.has("registro") ||
            params.has("registroId") ||
            params.has("loteId")
        );
    }

    function capturarOriginal() {
        if (!modoEdicao() || chaveOriginalEdicao || !formularioPreenchido()) return;
        chaveOriginalEdicao = chave(valoresFormulario());
    }

    function agendarCapturaOriginal() {
        let tentativas = 0;
        const timer = setInterval(function () {
            tentativas += 1;
            capturarOriginal();
            if (chaveOriginalEdicao || tentativas >= 50) clearInterval(timer);
        }, 60);
    }

    function idsDaUrl() {
        const params = new URLSearchParams(window.location.search);
        const nomes = ["id", "registro", "registroId", "loteId"];
        const ids = [];

        nomes.forEach(function (nome) {
            const valor = params.get(nome);
            if (valor != null && String(valor).trim()) {
                ids.push(String(valor).trim());
            }
        });

        return ids;
    }

    function indiceDaUrl() {
        const params = new URLSearchParams(window.location.search);
        for (const nome of ["index", "indice", "i"]) {
            const valor = params.get(nome);
            if (valor != null && /^\d+$/.test(String(valor))) {
                return Number(valor);
            }
        }
        return -1;
    }

    function instalar() {
        const botao = document.getElementById("salvar");
        if (!botao || botao.dataset.seedcontrolDuplicidadeUniversalV3902 === "1") return;

        botao.dataset.seedcontrolDuplicidadeUniversalV3902 = "1";

        agendarCapturaOriginal();
        document.addEventListener("focusin", capturarOriginal, true);

        botao.addEventListener("click", function (evento) {
            capturarOriginal();

            const base = typeof carregarEstoque === "function"
                ? carregarEstoque()
                : [];

            if (!Array.isArray(base)) return;

            const candidato = valoresFormulario();
            const chaveCandidato = chave(candidato);
            const editando = modoEdicao();
            const idsUrl = idsDaUrl();
            const indiceUrl = indiceDaUrl();
            let originalIgnorado = false;

            const duplicado = base.some(function (item, indice) {
                if (!item) return false;

                if (editando) {
                    if (idsUrl.length && idsUrl.includes(String(item.id == null ? "" : item.id))) {
                        return false;
                    }

                    if (indiceUrl >= 0 && indice === indiceUrl) {
                        return false;
                    }

                    if (!originalIgnorado && chaveOriginalEdicao && chave(item) === chaveOriginalEdicao) {
                        originalIgnorado = true;
                        return false;
                    }
                }

                return chave(item) === chaveCandidato;
            });

            if (!duplicado) return;

            evento.preventDefault();
            evento.stopImmediatePropagation();

            if (editando) {
                alert("Já existe OUTRO lote cadastrado com a mesma cultivar, fazenda, peneira e talhão.");
            } else {
                alert("Este lote já está cadastrado com a mesma cultivar, fazenda, peneira e talhão.");
            }
        }, true);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", instalar);
    } else {
        instalar();
    }
})();

// ===============================
// SeedControl v3.8
// editar.js
// ===============================

const id = Number(
    new URLSearchParams(
        window.location.search
    ).get("id")
);

const registro = obterLotePorId(id);


// ===============================
// VALIDAR LOTE
// ===============================

if (!registro) {

    alert("Lote não encontrado.");

    window.location.href =
        "estoque.html";

} else {

    // ===============================
    // ELEMENTOS
    // ===============================

    const campoCultivar =
        document.getElementById("cultivar");

    const campoPeneira =
        document.getElementById("peneira");

    const campoLote =
        document.getElementById("lote");

    const campoBags =
        document.getElementById("bags");

    const campoUmidade =
        document.getElementById("umidade");

    const campoTemperatura =
        document.getElementById("temperatura");

    const campoPMS =
        document.getElementById("pms");

    const campoFazenda =
        document.getElementById("fazenda");

    const campoTalhao =
        document.getElementById("talhao");

    const campoSecagem =
        document.getElementById("secagem");

    const campoMetodoPeso =
        document.getElementById("metodoPeso");

    const campoKgsMedia =
        document.getElementById("kgsMediaCalculado");

    const campoSacas60kg =
        document.getElementById("sacas60kgCalculado");

    const textoMetodoPeso =
        document.getElementById("textoMetodoPeso");

    const btnSalvar =
        document.getElementById("salvar");


    // ===============================
    // FORMATAÇÃO
    // ===============================

    function formatarNumeroEdicao(
        valor,
        casas = 2
    ) {

        const numero =
            Number(valor);

        if (!Number.isFinite(numero)) {
            return "0";
        }

        return numero.toLocaleString(
            "pt-BR",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: casas
            }
        );

    }


    // ===============================
    // PREENCHER DADOS
    // ===============================

    if (campoCultivar) {
        campoCultivar.value =
            registro.cultivar || "";
    }

    if (campoPeneira) {
        campoPeneira.value =
            registro.peneira || "";
    }

    if (campoLote) {
        campoLote.value =
            registro.lote ?? "";
    }

    if (campoBags) {
        campoBags.value =
            registro.bags ?? "";
    }

    if (campoUmidade) {
        campoUmidade.value =
            registro.umidade ?? "";
    }

    if (campoTemperatura) {
        campoTemperatura.value =
            registro.temperatura ?? "";
    }

    if (campoPMS) {
        campoPMS.value =
            registro.pms ?? "";
    }

    if (campoFazenda) {
        campoFazenda.value =
            registro.fazenda || "";
    }

    if (campoTalhao) {
        campoTalhao.value =
            registro.talhao || "";
    }


    // ===============================
    // SECAGEM
    // ===============================

    if (campoSecagem) {

        campoSecagem.value =
            normalizarSecagem(
                registro.secagem
            );

    }


    // ===============================
    // MÉTODO DO PESO
    // ===============================

    const metodoOriginal =
        normalizarMetodoPeso(
            registro.metodoPeso
        );

    if (campoMetodoPeso) {

        campoMetodoPeso.value =
            metodoOriginal;

    }


    // ===============================
    // ATUALIZAR CÁLCULO AUTOMÁTICO
    // ===============================

    function atualizarCalculoEdicao() {

        const bags =
            campoBags
                ? Number(campoBags.value) || 0
                : Number(registro.bags) || 0;

        const pms =
            campoPMS
                ? Number(campoPMS.value) || 0
                : Number(registro.pms) || 0;

        const metodo =
            campoMetodoPeso
                ? campoMetodoPeso.value
                : metodoOriginal;


        // Cálculo centralizado no database.js
        const calculo =
            calcularPesoESacasLote(
                bags,
                pms,
                metodo
            );


        if (campoKgsMedia) {

            campoKgsMedia.textContent =
                formatarNumeroEdicao(
                    calculo.kgsMedia,
                    2
                );

        }


        if (campoSacas60kg) {

            campoSacas60kg.textContent =
                formatarNumeroEdicao(
                    calculo.sacas60kg,
                    2
                );

        }


        if (textoMetodoPeso) {

            if (
                calculo.metodoPeso ===
                "comercial"
            ) {

                textoMetodoPeso.innerHTML =
                    "🌱 Peso calculado automaticamente pelo <strong>PMS</strong>, no padrão comercial.";

            } else {

                textoMetodoPeso.innerHTML =
                    "📦 Peso calculado automaticamente pelo método estimado.";

            }

        }

    }


    // ===============================
    // RECALCULAR EM TEMPO REAL
    // ===============================

    if (campoBags) {

        campoBags.addEventListener(
            "input",
            atualizarCalculoEdicao
        );

    }

    if (campoPMS) {

        campoPMS.addEventListener(
            "input",
            atualizarCalculoEdicao
        );

    }

    if (campoMetodoPeso) {

        campoMetodoPeso.addEventListener(
            "change",
            atualizarCalculoEdicao
        );

    }


    atualizarCalculoEdicao();


    // ===============================
    // SALVAR ALTERAÇÕES
    // ===============================

    if (btnSalvar) {

        btnSalvar.addEventListener(
            "click",
            function () {

                const novoLote = {

                    cultivar:
                        campoCultivar
                            ? campoCultivar.value.trim()
                            : "",

                    peneira:
                        campoPeneira
                            ? campoPeneira.value.trim()
                            : "",

                    lote:
                        campoLote
                            ? Number(campoLote.value)
                            : 0,

                    bags:
                        campoBags
                            ? Number(campoBags.value)
                            : 0,

                    umidade:
                        campoUmidade
                            ? Number(campoUmidade.value) || 0
                            : 0,

                    temperatura:
                        campoTemperatura
                            ? Number(campoTemperatura.value) || 0
                            : 0,

                    pms:
                        campoPMS
                            ? Number(campoPMS.value) || 0
                            : 0,

                    fazenda:
                        campoFazenda
                            ? campoFazenda.value.trim()
                            : "",

                    talhao:
                        campoTalhao
                            ? campoTalhao.value.trim()
                            : "",

                    secagem:
                        campoSecagem
                            ? campoSecagem.value
                            : normalizarSecagem(
                                registro.secagem
                            ),

                    // Se a tela possuir o seletor,
                    // usa a escolha atual.
                    // Se não possuir, preserva
                    // exatamente o método do lote.
                    metodoPeso:
                        campoMetodoPeso
                            ? campoMetodoPeso.value
                            : metodoOriginal

                };


                // ===============================
                // ATUALIZAR PELO DATABASE
                // ===============================

                const resultado =
                    atualizarLote(
                        id,
                        novoLote
                    );


                if (!resultado.ok) {

                    alert(
                        resultado.mensagem
                    );

                    return;

                }


                alert(
                    resultado.mensagem
                );


                window.location.href =
                    "cultivar.html?cultivar=" +
                    encodeURIComponent(
                        novoLote.cultivar
                    );

            }
        );

    }

}