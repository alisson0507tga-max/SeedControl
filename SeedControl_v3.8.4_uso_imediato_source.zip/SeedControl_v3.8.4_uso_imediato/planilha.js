// ESTOQUE_ZERO_VERMELHO_E_SACAS_SEM_PONTO_V1
// seedcontrol-planilha-fiel-soja2026-v3830
// ==========================================
// SeedControl v3.8
// planilha.js
// ==========================================

let ouvintesPlanilhaRegistrados = false;
let framePlanilha = null;

let promessaXLSX = null;
let promessaPDF = null;


// ==========================================
// ELEMENTOS
// ==========================================

const corpoPlanilha =
    document.getElementById(
        "corpoPlanilha"
    );

const pesquisaPlanilha =
    document.getElementById(
        "pesquisaPlanilha"
    );

const filtroPlanilhaCultivar =
    document.getElementById(
        "filtroPlanilhaCultivar"
    );

const filtroPlanilhaFazenda =
    document.getElementById(
        "filtroPlanilhaFazenda"
    );

const planilhaTotalBags =
    document.getElementById(
        "planilhaTotalBags"
    );

const planilhaTotalKg =
    document.getElementById(
        "planilhaTotalKg"
    );

const planilhaTotalSacas =
    document.getElementById(
        "planilhaTotalSacas"
    );

const planilhaTotalLotes =
    document.getElementById(
        "planilhaTotalLotes"
    );

const totalBagsRodape =
    document.getElementById(
        "totalBagsRodape"
    );

const totalKgRodape =
    document.getElementById(
        "totalKgRodape"
    );

const totalSacasRodape =
    document.getElementById(
        "totalSacasRodape"
    );

const btnExportarExcel =
    document.getElementById(
        "exportarPlanilhaExcel"
    );

const btnExportarPDF =
    document.getElementById(
        "exportarPlanilhaPDF"
    );


// ==========================================
// SEGURANÇA HTML
// ==========================================

function escaparHtmlPlanilha(valor) {

    return String(valor ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

}


// ==========================================
// FORMATAÇÃO
// ==========================================

function formatarNumeroPlanilha(
    valor,
    casas = 2
) {

    const numero =
        Number(valor);


    if (!Number.isFinite(numero)) {

        return "0";

    }


    return numero.toLocaleString(
        "pt-BR",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: casas
        }
    ).replace(/[.]$/, "");

}


// ==========================================
// SECAGEM
// ==========================================

function obterSituacaoSecagemPlanilha(
    valor
) {

    return normalizarSecagem(
        valor
    );

}


function obterTextoSecagemPlanilha(
    valor
) {

    const situacao =
        obterSituacaoSecagemPlanilha(
            valor
        );


    if (
        situacao === "secou"
    ) {

        return "✅";

    }


    return "❌";

}


function obterDescricaoSecagemPlanilha(
    valor
) {

    const situacao =
        obterSituacaoSecagemPlanilha(
            valor
        );


    if (
        situacao === "secou"
    ) {

        return "Secou";

    }


    return "Não precisou secar";

}


// ==========================================
// MÉTODO DO PESO
// ==========================================

function obterTextoMetodoPlanilha(
    valor
) {

    const metodo =
        normalizarMetodoPeso(
            valor
        );


    if (
        metodo === "comercial"
    ) {

        return "Comercial (PMS)";

    }


    return "Estimado";

}


// ==========================================
// PESO POR BAG
// ==========================================

function obterPesoBagPlanilha(
    item
) {

    return Number(
        item &&
        item.pesoBagKg
    ) || 0;

}


function obterTextoPesoBagPlanilha(
    item
) {

    return (
        formatarNumeroPlanilha(
            obterPesoBagPlanilha(
                item
            ),
            2
        ) +
        " kg/Bag"
    );

}


function obterTextoMetodoComPesoPlanilha(
    item
) {

    return (
        obterTextoMetodoPlanilha(
            item.metodoPeso
        ) +
        " — " +
        obterTextoPesoBagPlanilha(
            item
        )
    );

}


// ==========================================
// ESTOQUE BASE
// ==========================================

// Lotes comerciais pertencem exclusivamente à Entrada Comercial.
function ehLoteComercialSeparacao(item) {
    const metodo = String(item && item.metodoPeso || "")
        .trim()
        .toLowerCase();
    return metodo === "comercial" ||
        metodo === "pms" ||
        metodo.includes("comercial") ||
        metodo.includes("pms");
}

function obterEstoquePlanilha() {

    const estoque =
        carregarEstoque();


    return (Array.isArray(estoque)
        ? estoque
        : []
    ).filter(
        item => !ehLoteComercialSeparacao(item)
    );

}


// ==========================================
// ATUALIZAR FILTROS
// ==========================================

function atualizarFiltrosPlanilha(
    estoque
) {

    const base =
        Array.isArray(estoque)
            ? estoque
            : [];


    const cultivarAtual =
        filtroPlanilhaCultivar
            ? filtroPlanilhaCultivar.value
            : "";


    const fazendaAtual =
        filtroPlanilhaFazenda
            ? filtroPlanilhaFazenda.value
            : "";


    const cultivares = [

        ...new Set(

            base
                .map(
                    item =>
                        String(
                            item &&
                            item.cultivar ||
                            ""
                        ).trim()
                )
                .filter(Boolean)

        )

    ].sort(
        (a, b) =>
            a.localeCompare(
                b,
                "pt-BR",
                {
                    sensitivity:
                        "base"
                }
            )
    );


    const fazendas = [

        ...new Set(

            base
                .map(
                    item =>
                        String(
                            item &&
                            item.fazenda ||
                            ""
                        ).trim()
                )
                .filter(Boolean)

        )

    ].sort(
        (a, b) =>
            a.localeCompare(
                b,
                "pt-BR",
                {
                    sensitivity:
                        "base"
                }
            )
    );


    // ======================================
    // CULTIVAR
    // ======================================

    if (filtroPlanilhaCultivar) {

        filtroPlanilhaCultivar.innerHTML =
            `<option value="">Todas</option>`;


        cultivares.forEach(
            cultivar => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    cultivar;


                option.textContent =
                    cultivar;


                filtroPlanilhaCultivar.appendChild(
                    option
                );

            }
        );


        if (
            cultivares.includes(
                cultivarAtual
            )
        ) {

            filtroPlanilhaCultivar.value =
                cultivarAtual;

        }

    }


    // ======================================
    // FAZENDA
    // ======================================

    if (filtroPlanilhaFazenda) {

        filtroPlanilhaFazenda.innerHTML =
            `<option value="">Todas</option>`;


        fazendas.forEach(
            fazenda => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    fazenda;


                option.textContent =
                    fazenda;


                filtroPlanilhaFazenda.appendChild(
                    option
                );

            }
        );


        if (
            fazendas.includes(
                fazendaAtual
            )
        ) {

            filtroPlanilhaFazenda.value =
                fazendaAtual;

        }

    }

}


// ==========================================
// FILTRAR REGISTROS
// ==========================================

function obterRegistrosPlanilha(
    estoque
) {

    const termo =
        normalizarTexto(
            pesquisaPlanilha
                ? pesquisaPlanilha.value
                : ""
        );


    const cultivarSelecionada =
        normalizarTexto(
            filtroPlanilhaCultivar
                ? filtroPlanilhaCultivar.value
                : ""
        );


    const fazendaSelecionada =
        normalizarTexto(
            filtroPlanilhaFazenda
                ? filtroPlanilhaFazenda.value
                : ""
        );


    return (
        Array.isArray(estoque)
            ? estoque
            : []
    ).filter(
        item => {

            if (!item) {

                return false;

            }


            if (
                cultivarSelecionada &&
                normalizarTexto(
                    item.cultivar
                ) !== cultivarSelecionada
            ) {

                return false;

            }


            if (
                fazendaSelecionada &&
                normalizarTexto(
                    item.fazenda
                ) !== fazendaSelecionada
            ) {

                return false;

            }


            if (!termo) {

                return true;

            }


            const campos = [

                item.cultivar,
                item.peneira,
                item.lote,
                item.fazenda,
                item.talhao,
                item.bags,
                item.pms,
                item.pesoBagKg,
                item.kgsMedia,

                obterDescricaoSecagemPlanilha(
                    item.secagem
                ),

                obterTextoSecagemPlanilha(
                    item.secagem
                ),

                obterTextoMetodoPlanilha(
                    item.metodoPeso
                ),

                obterTextoPesoBagPlanilha(
                    item
                )

            ];


            return campos.some(
                campo =>
                    normalizarTexto(
                        campo
                    ).includes(
                        termo
                    )
            );

        }
    );

}


// ==========================================
// RESUMO
// ==========================================

function atualizarResumoPlanilha(
    registros
) {

    const resumo =
        resumirEstoque(
            registros
        );


    if (planilhaTotalBags) {

        planilhaTotalBags.textContent =
            formatarNumeroPlanilha(
                resumo.totalBags,
                2
            );

    }


    if (planilhaTotalKg) {

        planilhaTotalKg.textContent =
            formatarNumeroPlanilha(
                resumo.totalKgsMedia,
                2
            );

    }


    if (planilhaTotalSacas) {

        planilhaTotalSacas.textContent =
            formatarNumeroPlanilha(
                resumo.totalSacas60kg,
                2
            );

    }


    if (planilhaTotalLotes) {

        planilhaTotalLotes.textContent =
            resumo.totalLotesDistintos;

    }


    if (totalBagsRodape) {

        totalBagsRodape.textContent =
            formatarNumeroPlanilha(
                resumo.totalBags,
                2
            );

    }


    if (totalKgRodape) {

        totalKgRodape.textContent =
            formatarNumeroPlanilha(
                resumo.totalKgsMedia,
                2
            );

    }


    if (totalSacasRodape) {

        totalSacasRodape.textContent =
            formatarNumeroPlanilha(
                resumo.totalSacas60kg,
                2
            );

    }


    return resumo;

}


// ==========================================
// RENDERIZAR TABELA
// ==========================================

function renderizarTabelaPlanilha() {

    framePlanilha = null;


    if (!corpoPlanilha) {

        return;

    }


    const estoque =
        obterEstoquePlanilha();


    atualizarFiltrosPlanilha(
        estoque
    );


    const registros =
        obterRegistrosPlanilha(
            estoque
        );


    const resumo =
        atualizarResumoPlanilha(
            registros
        );


    window.__seedPlanilha = {

        registros:
            registros,

        resumo:
            resumo,

        total:
            registros.length

    };


    if (
        registros.length === 0
    ) {

        corpoPlanilha.innerHTML = `

<tr>

<td
    colspan="13"
    class="planilha-carregando"
>

Nenhum lote encontrado.

</td>

</tr>

`;

        return;

    }


    corpoPlanilha.innerHTML =
        registros.map(
            item => {

                const secagem =
                    obterTextoSecagemPlanilha(
                        item.secagem
                    );


                const metodo =
                    obterTextoMetodoPlanilha(
                        item.metodoPeso
                    );


                const pesoBag =
                    obterTextoPesoBagPlanilha(
                        item
                    );


                const linhaZerada = (Number(item.bags) || 0) === 0;
                return `

<tr class="${linhaZerada ? "planilha-estoque-zero" : ""}">

<td>
${escaparHtmlPlanilha(
    item.cultivar || "-"
)}
</td>


<td>
${escaparHtmlPlanilha(
    item.peneira || "-"
)}
</td>


<td>
${escaparHtmlPlanilha(
    item.lote ?? "-"
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.bags,
    2
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.kgsMedia,
    2
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.sacas60kg,
    2
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.umidade,
    2
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.temperatura,
    2
)}
</td>


<td>
${formatarNumeroPlanilha(
    item.pms,
    2
)}
</td>


<td>
${escaparHtmlPlanilha(
    item.fazenda || "-"
)}
</td>


<td>
${escaparHtmlPlanilha(
    item.talhao || "-"
)}
</td>


<td
    style="
        font-size:18px;
        text-align:center;
    "
>
${secagem}
</td>


<td>

<strong>
${escaparHtmlPlanilha(
    metodo
)}
</strong>

<br>

<span
    style="
        font-size:12px;
        white-space:nowrap;
    "
>

⚖️ ${escaparHtmlPlanilha(
    pesoBag
)}

</span>

</td>

</tr>

`;

            }
        ).join("");

}


// ==========================================
// AGENDAR ATUALIZAÇÃO
// ==========================================

function agendarPlanilha() {

    if (framePlanilha) {

        cancelAnimationFrame(
            framePlanilha
        );

    }


    framePlanilha =
        requestAnimationFrame(
            renderizarTabelaPlanilha
        );

}


// ==========================================
// CARREGAR SCRIPT
// ==========================================

function carregarScriptPlanilha(
    url,
    teste
) {

    return new Promise(
        function (
            resolve,
            reject
        ) {

            if (
                typeof teste === "function" &&
                teste()
            ) {

                resolve();

                return;

            }


            const existente =
                document.querySelector(
                    `script[src="${url}"]`
                );


            if (existente) {

                existente.addEventListener(
                    "load",
                    function () {

                        resolve();

                    },
                    {
                        once: true
                    }
                );


                existente.addEventListener(
                    "error",
                    function () {

                        reject(
                            new Error(
                                "Falha ao carregar biblioteca."
                            )
                        );

                    },
                    {
                        once: true
                    }
                );


                return;

            }


            const script =
                document.createElement(
                    "script"
                );


            script.src =
                url;


            script.async =
                true;


            script.onload =
                function () {

                    resolve();

                };


            script.onerror =
                function () {

                    reject(
                        new Error(
                            "Falha ao carregar biblioteca."
                        )
                    );

                };


            document.head.appendChild(
                script
            );

        }
    );

}


// ==========================================
// EXCEL
// ==========================================

function carregarBibliotecaExcel() {

    if (
        typeof XLSX !== "undefined"
    ) {

        return Promise.resolve();

    }


    if (!promessaXLSX) {

        promessaXLSX =
            carregarScriptPlanilha(

                "vendor/xlsx-js-style.bundle.js",

                function () {

                    return (
                        typeof XLSX !==
                        "undefined"
                    );

                }

            ).catch(
                function (erro) {

                    promessaXLSX =
                        null;

                    throw erro;

                }
            );

    }


    return promessaXLSX;

}


// ==========================================
// PDF
// ==========================================

function carregarBibliotecaPDF() {

    if (
        window.jspdf &&
        window.jspdf.jsPDF &&
        typeof window.jspdf.jsPDF.API.autoTable ===
            "function"
    ) {

        return Promise.resolve();

    }


    if (!promessaPDF) {

        promessaPDF =
            carregarScriptPlanilha(

                "vendor/jspdf.umd.min.js",

                function () {

                    return !!(
                        window.jspdf &&
                        window.jspdf.jsPDF
                    );

                }

            )
                .then(
                    function () {

                        return carregarScriptPlanilha(

                            "vendor/jspdf.plugin.autotable.min.js",

                            function () {

                                return !!(
                                    window.jspdf &&
                                    window.jspdf.jsPDF &&
                                    typeof window.jspdf
                                        .jsPDF
                                        .API
                                        .autoTable ===
                                        "function"
                                );

                            }

                        );

                    }
                )
                .catch(
                    function (erro) {

                        promessaPDF =
                            null;

                        throw erro;

                    }
                );

    }


    return promessaPDF;

}


// ==========================================
// REGISTROS ATUAIS
// ==========================================

function obterRegistrosAtuaisPlanilha() {

    if (
        window.__seedPlanilha &&
        Array.isArray(
            window.__seedPlanilha.registros
        )
    ) {

        return window.__seedPlanilha.registros;

    }


    const estoque =
        obterEstoquePlanilha();


    return obterRegistrosPlanilha(
        estoque
    );

}


// ==========================================
// DADOS PARA EXPORTAÇÃO
// ==========================================

function montarLinhasExportacao(
    registros
) {

    return registros.map(
        item => [

            item.cultivar || "",

            item.peneira || "",

            item.lote ?? "",

            Number(item.bags) || 0,

            Number(item.kgsMedia) || 0,

            Number(item.sacas60kg) || 0,

            Number(item.umidade) || 0,

            Number(item.temperatura) || 0,

            Number(item.pms) || 0,

            item.fazenda || "",

            item.talhao || "",

            obterTextoSecagemPlanilha(
                item.secagem
            ),

            obterTextoMetodoComPesoPlanilha(
                item
            )

        ]
    );

}


// ==========================================
// ESTILOS EXCEL
// ==========================================

function criarBordaExcel() {

    const lado = {

        style:
            "thin",

        color: {

            rgb:
                "B9C5C8"

        }

    };


    return {

        top:
            lado,

        bottom:
            lado,

        left:
            lado,

        right:
            lado

    };

}



// seedcontrol-planilha-exportacao-nativa-v384

function seedPlanilhaPlataformaNativa() {
    const capacitor = window.Capacitor;
    return Boolean(
        capacitor &&
        typeof capacitor.isNativePlatform === "function" &&
        capacitor.isNativePlatform()
    );
}

function seedPlanilhaArrayParaBase64(dados) {
    const bytes = dados instanceof Uint8Array
        ? dados
        : new Uint8Array(dados);

    let binario = "";
    const tamanhoBloco = 0x8000;

    for (let inicio = 0; inicio < bytes.length; inicio += tamanhoBloco) {
        const bloco = bytes.subarray(
            inicio,
            Math.min(inicio + tamanhoBloco, bytes.length)
        );
        binario += String.fromCharCode.apply(null, bloco);
    }

    return btoa(binario);
}

async function seedPlanilhaSalvarECompartilhar(nomeArquivo, dadosBinarios) {
    const capacitor = window.Capacitor;
    const filesystem =
        capacitor && capacitor.Plugins && capacitor.Plugins.Filesystem;
    const share =
        capacitor && capacitor.Plugins && capacitor.Plugins.Share;

    if (!filesystem) {
        throw new Error("Plugin Filesystem não está disponível no APK.");
    }

    if (!share) {
        throw new Error("Plugin de compartilhamento não está disponível no APK.");
    }

    const base64 = seedPlanilhaArrayParaBase64(dadosBinarios);

    const salvo = await filesystem.writeFile({
        path: "SeedControl/Planilhas/" + nomeArquivo,
        data: base64,
        directory: "DOCUMENTS",
        recursive: true
    });

    if (!salvo || !salvo.uri) {
        throw new Error("O Android não confirmou o salvamento do arquivo.");
    }

    const temporario = await filesystem.writeFile({
        path: "SeedControlShare/" + nomeArquivo,
        data: base64,
        directory: "CACHE",
        recursive: true
    });

    if (!temporario || !temporario.uri) {
        throw new Error("Não foi possível preparar o arquivo para compartilhar.");
    }

    await share.share({
        title: nomeArquivo,
        text: "Planilha gerada pelo SeedControl",
        url: temporario.uri,
        dialogTitle: "Compartilhar planilha"
    });

    return salvo;
}

// ==========================================
// EXPORTAR EXCEL
// ==========================================


async function exportarPlanilhaExcel() {

    const registros =
        obterRegistrosAtuaisPlanilha();

    if (!registros.length) {
        alert("Não há lotes para exportar.");
        return;
    }

    const textoOriginal =
        btnExportarExcel
            ? btnExportarExcel.textContent
            : "";

    try {

        if (btnExportarExcel) {
            btnExportarExcel.disabled = true;
            btnExportarExcel.textContent = "⏳ Preparando Excel...";
        }

        await carregarBibliotecaExcel();

        const resumo =
            resumirEstoque(registros);

        const cabecalhos = [
            "CULTIVAR",
            "PENEIRA",
            "LOTES",
            "QUANTIDADE BAGS ",
            "Kgs(MÉDIA)",
            "SACAS(60kgs)",
            "UMIDADE %",
            "TEMPERATURA °C",
            "PMS ( g )",
            "FAZENDA ",
            "TALHÃO",
            "SECAGEM"
        ];

        const linhas =
            registros.map(item => [
                item.cultivar || "",
                item.peneira || "",
                String(item.lote == null ? "" : item.lote),
                Number(item.bags) || 0,
                Number(item.kgsMedia) || 0,
                Number(item.sacas60kg) || 0,
                Number(item.umidade) || 0,
                Number(item.temperatura) || 0,
                Number(item.pms) || 0,
                item.fazenda || "",
                item.talhao || "",
                obterTextoSecagemPlanilha(item.secagem)
            ]);

        const dados = [
            ["CONTROLE DE SEMENTES DE SOJA"],
            cabecalhos,
            ...linhas,
            [
                "",
                "",
                "",
                Number(resumo.totalBags) || 0,
                Number(resumo.totalKgsMedia) || 0,
                Number(resumo.totalSacas60kg) || 0,
                "",
                "",
                "",
                "",
                "",
                ""
            ]
        ];

        const worksheet =
            XLSX.utils.aoa_to_sheet(dados);

        worksheet["!merges"] = [{
            s: { r: 0, c: 0 },
            e: { r: 0, c: 11 }
        }];

        worksheet["!cols"] = [
            { wch: 24 },
            { wch: 10 },
            { wch: 8 },
            { wch: 16 },
            { wch: 14 },
            { wch: 15 },
            { wch: 12 },
            { wch: 16 },
            { wch: 12 },
            { wch: 19 },
            { wch: 11 },
            { wch: 10 }
        ];

        const totalLinhas = registros.length + 3;
        worksheet["!rows"] = [];
        worksheet["!rows"][0] = { hpt: 26 };
        worksheet["!rows"][1] = { hpt: 22 };
        for (let i = 2; i < totalLinhas; i++) {
            worksheet["!rows"][i] = { hpt: 19 };
        }

        const COR_TITULO = "4DD0E1";
        const COR_AZUL_CLARO = "E0F7FA";
        const COR_BRANCO = "FFFFFF";
        const COR_TEXTO = "111111";
        const COR_BORDA = "CFD8DC";

        function bordaFiel() {
            const lado = {
                style: "thin",
                color: { rgb: COR_BORDA }
            };
            return {
                top: lado,
                bottom: lado,
                left: lado,
                right: lado
            };
        }

        function garantirCelula(linha, coluna) {
            const endereco =
                XLSX.utils.encode_cell({
                    r: linha,
                    c: coluna
                });

            if (!worksheet[endereco]) {
                worksheet[endereco] = {
                    t: "s",
                    v: ""
                };
            }

            return worksheet[endereco];
        }

        for (let coluna = 0; coluna < 12; coluna++) {
            const celula = garantirCelula(0, coluna);
            celula.s = {
                fill: {
                    patternType: "solid",
                    fgColor: { rgb: COR_TITULO }
                },
                font: {
                    name: "Oswald",
                    bold: true,
                    sz: 14,
                    color: { rgb: "000000" }
                },
                alignment: {
                    horizontal: "center",
                    vertical: "center"
                },
                border: bordaFiel()
            };
        }

        for (let coluna = 0; coluna < 12; coluna++) {
            const celula = garantirCelula(1, coluna);
            celula.s = {
                fill: {
                    patternType: "solid",
                    fgColor: { rgb: COR_AZUL_CLARO }
                },
                font: {
                    name: "Oswald",
                    bold: true,
                    sz: 10,
                    color: { rgb: "000000" }
                },
                alignment: {
                    horizontal: "center",
                    vertical: "center",
                    wrapText: true
                },
                border: bordaFiel()
            };
        }

        registros.forEach(function (_, indice) {
            const linha = indice + 2;
            const corLinha =
                (Number(registros[indice].bags) || 0) === 0
                    ? "F4CCCC"
                    : (indice % 2 === 0 ? COR_BRANCO : COR_AZUL_CLARO);

            for (let coluna = 0; coluna < 12; coluna++) {
                const celula = garantirCelula(linha, coluna);

                celula.s = {
                    fill: {
                        patternType: "solid",
                        fgColor: { rgb: corLinha }
                    },
                    font: {
                        name: "Oswald",
                        bold: true,
                        sz: coluna === 11 ? 12 : 9,
                        color: { rgb: COR_TEXTO }
                    },
                    alignment: {
                        horizontal: "center",
                        vertical: "center",
                        wrapText: false
                    },
                    border: bordaFiel()
                };

                if (coluna === 2 || coluna === 3 || coluna === 4) {
                    celula.z = "0";
                }

                if (coluna === 5) {
                    celula.z = "0.##";
                }

                if (coluna === 6 || coluna === 7) {
                    celula.z = "0.0";
                }

                if (coluna === 8) {
                    celula.z = "0.00";
                }
            }
        });

        const linhaTotal = registros.length + 2;

        for (let coluna = 0; coluna < 12; coluna++) {
            const celula = garantirCelula(linhaTotal, coluna);

            celula.s = {
                fill: {
                    patternType: "solid",
                    fgColor: { rgb: COR_BRANCO }
                },
                font: {
                    name: "Oswald",
                    bold: coluna >= 3 && coluna <= 5,
                    sz: 10,
                    color: { rgb: COR_TEXTO }
                },
                alignment: {
                    horizontal: "center",
                    vertical: "center"
                },
                border: bordaFiel()
            };
        }

        garantirCelula(linhaTotal, 3).z = "0";
        garantirCelula(linhaTotal, 4).z = "0";
        garantirCelula(linhaTotal, 5).z = "0.#";

        delete worksheet["!autofilter"];

        const workbook =
            XLSX.utils.book_new();

        XLSX.utils.book_append_sheet(
            workbook,
            worksheet,
            "Controle de Sementes"
        );

        const hoje = new Date();
        const dataNome =
            hoje.getFullYear() +
            "-" +
            String(hoje.getMonth() + 1).padStart(2, "0") +
            "-" +
            String(hoje.getDate()).padStart(2, "0");

        const nomeArquivoExcel =
            "SeedControl_Controle_Sementes_" +
            dataNome +
            ".xlsx";

        if (
            typeof seedPlanilhaPlataformaNativa === "function" &&
            seedPlanilhaPlataformaNativa()
        ) {
            const dadosExcel =
                XLSX.write(
                    workbook,
                    {
                        bookType: "xlsx",
                        type: "array"
                    }
                );

            await seedPlanilhaSalvarECompartilhar(
                nomeArquivoExcel,
                dadosExcel
            );
        } else {
            XLSX.writeFile(
                workbook,
                nomeArquivoExcel
            );
        }

    } catch (erro) {

        console.error(
            "Erro ao exportar Excel fiel:",
            erro
        );

        alert(
            "Não foi possível exportar o Excel. " +
            (erro && erro.message
                ? erro.message
                : "Erro desconhecido.")
        );

    } finally {

        if (btnExportarExcel) {
            btnExportarExcel.disabled = false;
            btnExportarExcel.textContent =
                textoOriginal ||
                "📗 Exportar Excel";
        }
    }
}


// ==========================================
// EXPORTAR PDF
// ==========================================

async function exportarPlanilhaPDF() {

    const registros =
        obterRegistrosAtuaisPlanilha();


    if (!registros.length) {

        alert(
            "Não há lotes para exportar."
        );

        return;

    }


    const textoOriginal =
        btnExportarPDF
            ? btnExportarPDF.textContent
            : "";


    try {

        if (btnExportarPDF) {

            btnExportarPDF.disabled =
                true;


            btnExportarPDF.textContent =
                "⏳ Preparando PDF...";

        }


        await carregarBibliotecaPDF();


        const {
            jsPDF
        } =
            window.jspdf;


        const pdf =
            new jsPDF({

                orientation:
                    "landscape",

                unit:
                    "mm",

                format:
                    "a3"

            });


        const resumo =
            resumirEstoque(
                registros
            );


        const larguraPagina =
            pdf.internal.pageSize
                .getWidth();


        pdf.setFillColor(
            73,
            197,
            213
        );


        pdf.rect(
            10,
            10,
            larguraPagina - 20,
            12,
            "F"
        );


        pdf.setTextColor(
            0,
            0,
            0
        );


        pdf.setFont(
            "helvetica",
            "bold"
        );


        pdf.setFontSize(
            16
        );


        pdf.text(

            "CONTROLE DE SEMENTES DE SOJA",

            larguraPagina / 2,

            18,

            {
                align:
                    "center"
            }

        );


        pdf.setFont(
            "helvetica",
            "normal"
        );


        pdf.setFontSize(
            8
        );


        pdf.text(

            "Gerado pelo SeedControl em " +
            new Date()
                .toLocaleString(
                    "pt-BR"
                ),

            10,

            28

        );


        const cabecalho = [[

            "CULTIVAR",

            "PENEIRA",

            "LOTES",

            "QUANTIDADE\nBAGS",

            "Kgs\n(MÉDIA)",

            "SACAS\n(60Kgs)",

            "UMIDADE\n%",

            "TEMPERATURA\n°C",

            "PMS\n(g)",

            "FAZENDA",

            "TALHÃO",

            "SECAGEM",

            "MÉTODO /\nPESO BAG"

        ]];


        const linhas =
            registros.map(
                item => [

                    item.cultivar || "-",

                    item.peneira || "-",

                    String(
                        item.lote ?? "-"
                    ),

                    formatarNumeroPlanilha(
                        item.bags,
                        2
                    ),

                    formatarNumeroPlanilha(
                        item.kgsMedia,
                        2
                    ),

                    formatarNumeroPlanilha(
                        item.sacas60kg,
                        2
                    ),

                    formatarNumeroPlanilha(
                        item.umidade,
                        2
                    ),

                    formatarNumeroPlanilha(
                        item.temperatura,
                        2
                    ),

                    formatarNumeroPlanilha(
                        item.pms,
                        2
                    ),

                    item.fazenda || "-",

                    item.talhao || "-",

                    obterTextoSecagemPlanilha(
                        item.secagem
                    ),

                    obterTextoMetodoComPesoPlanilha(
                        item
                    )

                ]
            );


        const rodape = [[

            "",

            "",

            "",

            formatarNumeroPlanilha(
                resumo.totalBags,
                2
            ),

            formatarNumeroPlanilha(
                resumo.totalKgsMedia,
                2
            ),

            formatarNumeroPlanilha(
                resumo.totalSacas60kg,
                2
            ),

            "",

            "",

            "",

            "",

            "",

            "",

            ""

        ]];


        pdf.autoTable({

            startY:
                32,

            head:
                cabecalho,

            body:
                linhas,

            foot:
                rodape,

            theme:
                "grid",

            styles: {

                fontSize:
                    7,

                textColor: [
                    0,
                    0,
                    0
                ],

                lineColor: [
                    185,
                    197,
                    200
                ],

                lineWidth:
                    .15,

                cellPadding:
                    1.5,

                valign:
                    "middle",

                halign:
                    "center",

                overflow:
                    "linebreak"

            },

            headStyles: {

                fillColor: [
                    217,
                    242,
                    245
                ],

                textColor: [
                    0,
                    0,
                    0
                ],

                fontStyle:
                    "bold",

                halign:
                    "center"

            },

            alternateRowStyles: {

                fillColor: [
                    217,
                    242,
                    245
                ]

            },

            footStyles: {

                fillColor: [
                    255,
                    255,
                    255
                ],

                textColor: [
                    0,
                    0,
                    0
                ],

                fontStyle:
                    "bold",

                halign:
                    "center"

            },

            didParseCell: function (data) {
                if (data.section === "body" && registros[data.row.index] && (Number(registros[data.row.index].bags) || 0) === 0) {
                    data.cell.styles.fillColor = [244, 204, 204];
                    data.cell.styles.textColor = [156, 0, 6];
                }
            },
            columnStyles: {

                0: {
                    cellWidth: 44,
                    fontStyle: "bold"
                },

                1: {
                    cellWidth: 19
                },

                2: {
                    cellWidth: 18
                },

                3: {
                    cellWidth: 27
                },

                4: {
                    cellWidth: 26
                },

                5: {
                    cellWidth: 27
                },

                6: {
                    cellWidth: 22
                },

                7: {
                    cellWidth: 29
                },

                8: {
                    cellWidth: 21
                },

                9: {
                    cellWidth: 40,
                    fontStyle: "bold"
                },

                10: {
                    cellWidth: 23
                },

                11: {
                    cellWidth: 22
                },

                12: {
                    cellWidth: 42
                }

            },

            margin: {

                left:
                    10,

                right:
                    10

            }

        });


        const totalPaginas =
            pdf.getNumberOfPages();


        for (
            let pagina = 1;
            pagina <= totalPaginas;
            pagina++
        ) {

            pdf.setPage(
                pagina
            );


            pdf.setTextColor(
                0,
                0,
                0
            );


            pdf.setFontSize(
                8
            );


            pdf.text(

                "Página " +
                pagina +
                " de " +
                totalPaginas,

                pdf.internal.pageSize
                    .getWidth() -
                    35,

                pdf.internal.pageSize
                    .getHeight() -
                    7

            );

        }


        const nomeArquivoPDF =
            "SeedControl_Controle_Sementes.pdf";

        if (seedPlanilhaPlataformaNativa()) {

            const dadosPDF =
                pdf.output("arraybuffer");

            await seedPlanilhaSalvarECompartilhar(
                nomeArquivoPDF,
                dadosPDF
            );

        } else {

            pdf.save(
                nomeArquivoPDF
            );

        }


    } catch (erro) {

        console.error(
            "Erro ao exportar PDF:",
            erro
        );


        alert(
            "Não foi possível exportar o PDF. " +
            (erro && erro.message
                ? erro.message
                : "Erro desconhecido.")
        );


    } finally {

        if (btnExportarPDF) {

            btnExportarPDF.disabled =
                false;


            btnExportarPDF.textContent =
                textoOriginal ||
                "📄 Exportar PDF";

        }

    }

}


// ==========================================
// OUVINTES
// ==========================================

function registrarOuvintesPlanilha() {

    if (
        ouvintesPlanilhaRegistrados
    ) {

        return;

    }


    ouvintesPlanilhaRegistrados =
        true;


    if (pesquisaPlanilha) {

        pesquisaPlanilha.addEventListener(
            "input",
            agendarPlanilha
        );

    }


    if (filtroPlanilhaCultivar) {

        filtroPlanilhaCultivar.addEventListener(
            "change",
            renderizarTabelaPlanilha
        );

    }


    if (filtroPlanilhaFazenda) {

        filtroPlanilhaFazenda.addEventListener(
            "change",
            renderizarTabelaPlanilha
        );

    }


    if (btnExportarExcel) {

        btnExportarExcel.addEventListener(
            "click",
            exportarPlanilhaExcel
        );

    }


    if (btnExportarPDF) {

        btnExportarPDF.addEventListener(
            "click",
            exportarPlanilhaPDF
        );

    }


    window.addEventListener(
        "seedcontrol:atualizado",
        renderizarTabelaPlanilha
    );


    window.addEventListener(
        "storage",
        renderizarTabelaPlanilha
    );


    window.addEventListener(
        "focus",
        renderizarTabelaPlanilha
    );


    document.addEventListener(
        "visibilitychange",
        function () {

            if (!document.hidden) {

                renderizarTabelaPlanilha();

            }

        }
    );

}


// ==========================================
// INICIAR
// ==========================================

function iniciarPlanilha() {

    renderizarTabelaPlanilha();

    registrarOuvintesPlanilha();

}


// ==========================================
// INICIALIZAÇÃO
// ==========================================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        iniciarPlanilha
    );

} else {

    iniciarPlanilha();

}